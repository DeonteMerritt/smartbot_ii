#!/usr/bin/env python3
"""Move neck_yaw_joint by a small angle and return it to zero.

Simulation only. The script exits if hardware_mode is not simulation.
It does not test walking, balance, or physical motors.
"""

import sys

import rclpy
from rclpy.action import ActionClient
from rclpy.node import Node
from control_msgs.action import FollowJointTrajectory
from trajectory_msgs.msg import JointTrajectoryPoint
from builtin_interfaces.msg import Duration


class SafeNeckTrajectory(Node):
    def __init__(self):
        super().__init__("smartbot_safe_neck_trajectory")
        self.declare_parameter("hardware_mode", "simulation")
        self.declare_parameter("joint_name", "neck_yaw_joint")
        self.declare_parameter("amplitude_rad", 0.15)
        self.declare_parameter("duration_sec", 2.0)
        self.declare_parameter(
            "controller_name", "smartbot_joint_trajectory_controller"
        )
        mode = self.get_parameter("hardware_mode").get_parameter_value().string_value
        if mode != "simulation":
            self.get_logger().error(
                "Refusing to send a joint trajectory because hardware_mode "
                f"is '{mode}'. This script runs only in simulation."
            )
            raise SystemExit(2)
        amplitude = (
            self.get_parameter("amplitude_rad").get_parameter_value().double_value
        )
        if abs(amplitude) > 0.20:
            self.get_logger().error(
                "Refusing amplitude above 0.20 rad. This is a small neck test."
            )
            raise SystemExit(2)
        self._joint = self.get_parameter("joint_name").get_parameter_value().string_value
        self._amplitude = amplitude
        self._duration = int(
            self.get_parameter("duration_sec").get_parameter_value().double_value
        )
        controller = (
            self.get_parameter("controller_name").get_parameter_value().string_value
        )
        self._client = ActionClient(
            self,
            FollowJointTrajectory,
            f"/{controller}/follow_joint_trajectory",
        )

    def _goal(self, position):
        goal = FollowJointTrajectory.Goal()
        goal.trajectory.joint_names = [self._joint]
        point = JointTrajectoryPoint()
        point.positions = [float(position)]
        point.time_from_start = Duration(sec=self._duration, nanosec=0)
        goal.trajectory.points = [point]
        goal.goal_time_tolerance = Duration(sec=1, nanosec=0)
        return goal

    def send_and_wait(self, position):
        if not self._client.wait_for_server(timeout_sec=15.0):
            self.get_logger().error(
                "FollowJointTrajectory server is not available. "
                "Start control.launch.py or simulation.launch.py first."
            )
            return False
        self.get_logger().info(
            f"Sending {self._joint} to {position:.3f} rad over {self._duration} s. "
            "Simulation only."
        )
        future = self._client.send_goal_async(self._goal(position))
        rclpy.spin_until_future_complete(self, future)
        handle = future.result()
        if handle is None or not handle.accepted:
            self.get_logger().error("Trajectory goal was rejected.")
            return False
        result_future = handle.get_result_async()
        rclpy.spin_until_future_complete(self, result_future)
        result = result_future.result()
        if result is None:
            self.get_logger().error("Trajectory result was empty.")
            return False
        status = result.status
        self.get_logger().info(f"Trajectory finished with status {status}.")
        return status == 4  # action_msgs/GoalStatus STATUS_SUCCEEDED


def main(args=None):
    rclpy.init(args=args)
    node = SafeNeckTrajectory()
    try:
        outbound = node.send_and_wait(node._amplitude)
        returning = node.send_and_wait(0.0) if outbound else False
    finally:
        node.destroy_node()
        rclpy.shutdown()
    if not (outbound and returning):
        sys.exit(1)


if __name__ == "__main__":
    main()
