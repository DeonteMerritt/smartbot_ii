"""Bring up SmartBot II on its own SystemInterface.

The hardware plugin is smartbot_ii_control/SmartBotIIHardware.
bus_transport defaults to mock, so write() only packs a fixed frame.
UART and SPI devices stay closed. This launch does not enable motor power.
"""

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, LogInfo
from launch.conditions import IfCondition
from launch.substitutions import (
    Command,
    FindExecutable,
    LaunchConfiguration,
    PathJoinSubstitution,
)
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    description_share = FindPackageShare("smartbot_ii_description")
    control_share = FindPackageShare("smartbot_ii_control")
    xacro_file = PathJoinSubstitution(
        [description_share, "urdf", "smartbot_ii.urdf.xacro"]
    )
    controllers = PathJoinSubstitution(
        [control_share, "config", "ros2_controllers.yaml"]
    )
    rviz_config = PathJoinSubstitution(
        [description_share, "rviz", "smartbot_ii.rviz"]
    )
    robot_description = Command(
        [
            FindExecutable(name="xacro"),
            " ",
            xacro_file,
            " use_ros2_control:=true",
            " use_gazebo:=false",
            " hardware_plugin:=smartbot_ii_control/SmartBotIIHardware",
            " export_effort_state:=false",
            " fix_pelvis_to_world:=false",
            " bus_transport:=",
            LaunchConfiguration("bus_transport"),
            " allow_unvalidated_bus:=",
            LaunchConfiguration("allow_unvalidated_bus"),
            " physical_hardware_ack:=",
            LaunchConfiguration("physical_hardware_ack"),
            " rt_trace:=",
            LaunchConfiguration("rt_trace"),
            " uart_device:=",
            LaunchConfiguration("uart_device"),
            " uart_baud:=",
            LaunchConfiguration("uart_baud"),
            " spi_device:=",
            LaunchConfiguration("spi_device"),
            " spi_speed_hz:=",
            LaunchConfiguration("spi_speed_hz"),
            " spi_mode:=",
            LaunchConfiguration("spi_mode"),
            " use_meshes:=",
            LaunchConfiguration("use_meshes"),
            " use_collision_meshes:=",
            LaunchConfiguration("use_collision_meshes"),
        ]
    )

    return LaunchDescription(
        [
            DeclareLaunchArgument("rviz", default_value="true"),
            DeclareLaunchArgument("use_meshes", default_value="false"),
            DeclareLaunchArgument("use_collision_meshes", default_value="false"),
            DeclareLaunchArgument(
                "bus_transport",
                default_value="mock",
                description="mock packs frames. uart and spi stay closed unless unlocked.",
            ),
            DeclareLaunchArgument("allow_unvalidated_bus", default_value="false"),
            DeclareLaunchArgument("physical_hardware_ack", default_value=""),
            DeclareLaunchArgument("rt_trace", default_value="false"),
            DeclareLaunchArgument("uart_device", default_value="/dev/serial0"),
            DeclareLaunchArgument("uart_baud", default_value="115200"),
            DeclareLaunchArgument("spi_device", default_value="/dev/spidev0.0"),
            DeclareLaunchArgument("spi_speed_hz", default_value="1000000"),
            DeclareLaunchArgument("spi_mode", default_value="0"),
            LogInfo(
                msg=(
                    "SmartBot II SystemInterface is starting. "
                    "The shipped transport is mock: position commands are packed into "
                    "joint_id and target_rad frames and are not written to pins. "
                    "This does not enable physical motors and it is not an emergency stop."
                )
            ),
            Node(
                package="robot_state_publisher",
                executable="robot_state_publisher",
                output="screen",
                parameters=[
                    {"robot_description": robot_description, "use_sim_time": False}
                ],
            ),
            Node(
                package="controller_manager",
                executable="ros2_control_node",
                output="screen",
                parameters=[controllers, {"use_sim_time": False}],
            ),
            Node(
                package="controller_manager",
                executable="spawner",
                output="screen",
                arguments=[
                    "joint_state_broadcaster",
                    "--controller-manager-timeout",
                    "60",
                    "--param-file",
                    controllers,
                ],
            ),
            Node(
                package="controller_manager",
                executable="spawner",
                output="screen",
                arguments=[
                    "smartbot_joint_trajectory_controller",
                    "--controller-manager-timeout",
                    "60",
                    "--param-file",
                    controllers,
                ],
            ),
            Node(
                package="rviz2",
                executable="rviz2",
                name="rviz2",
                arguments=["-d", rviz_config],
                condition=IfCondition(LaunchConfiguration("rviz")),
                output="screen",
            ),
        ]
    )
