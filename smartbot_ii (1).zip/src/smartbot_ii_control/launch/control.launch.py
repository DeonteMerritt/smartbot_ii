"""Mock ros2_control bringup for SmartBot II.

The hardware plugin is fixed to mock_components/GenericSystem.
This launch file does not load a physical motor driver.
"""

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, LogInfo
from launch.conditions import IfCondition
from launch.substitutions import (
    Command,
    FindExecutable,
    LaunchConfiguration,
    PathJoinSubstitution,
)
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    description_share = FindPackageShare("smartbot_ii_description")
    control_share = FindPackageShare("smartbot_ii_control")
    xacro_file = PathJoinSubstitution(
        [description_share, "urdf", "smartbot_ii.urdf.xacro"]
    )
    controllers = PathJoinSubstitution(
        [control_share, "config", "ros2_controllers.yaml"]
    )
    rviz_config = PathJoinSubstitution(
        [description_share, "rviz", "smartbot_ii.rviz"]
    )
    robot_description = Command(
        [
            FindExecutable(name="xacro"),
            " ",
            xacro_file,
            " use_ros2_control:=true",
            " use_gazebo:=false",
            " hardware_plugin:=mock_components/GenericSystem",
            " fix_pelvis_to_world:=false",
            " use_meshes:=",
            LaunchConfiguration("use_meshes"),
            " use_collision_meshes:=",
            LaunchConfiguration("use_collision_meshes"),
        ]
    )

    return LaunchDescription(
        [
            DeclareLaunchArgument("rviz", default_value="true"),
            DeclareLaunchArgument("use_meshes", default_value="false"),
            DeclareLaunchArgument("use_collision_meshes", default_value="false"),
            LogInfo(
                msg=(
                    "SmartBot II mock ros2_control is running. "
                    "Commands move the simulated joint state only. "
                    "No physical motor driver is loaded."
                )
            ),
            Node(
                package="robot_state_publisher",
                executable="robot_state_publisher",
                output="screen",
                parameters=[
                    {"robot_description": robot_description, "use_sim_time": False}
                ],
            ),
            Node(
                package="controller_manager",
                executable="ros2_control_node",
                output="screen",
                parameters=[controllers, {"use_sim_time": False}],
            ),
            Node(
                package="controller_manager",
                executable="spawner",
                output="screen",
                arguments=[
                    "joint_state_broadcaster",
                    "--controller-manager-timeout",
                    "60",
                    "--param-file",
                    controllers,
                ],
            ),
            Node(
                package="controller_manager",
                executable="spawner",
                output="screen",
                arguments=[
                    "smartbot_joint_trajectory_controller",
                    "--controller-manager-timeout",
                    "60",
                    "--param-file",
                    controllers,
                ],
            ),
            Node(
                package="rviz2",
                executable="rviz2",
                name="rviz2",
                arguments=["-d", rviz_config],
                condition=IfCondition(LaunchConfiguration("rviz")),
                output="screen",
            ),
        ]
    )
