// Host test for the UART/SPI frame codec. It does not link against ROS.

#include "smartbot_ii_control/joint_target_codec.hpp"

#include <chrono>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <iostream>

namespace
{

int failures = 0;

void expect(bool condition, const char * message)
{
  if (!condition) {
    std::cerr << message << '\n';
    ++failures;
  }
}

}  // namespace

int main()
{
  using smartbot_ii_control::kActuatedJointCount;
  using smartbot_ii_control::kActuatedJoints;
  using smartbot_ii_control::BusFrame;
  using smartbot_ii_control::frame_checksum_ok;
  using smartbot_ii_control::pack_position_commands;

  expect(kActuatedJointCount == 22, "joint count must stay 22");
  expect(std::strcmp(kActuatedJoints[0], "neck_yaw_joint") == 0, "joint 0 is neck yaw");
  expect(
    std::strcmp(kActuatedJoints[21], "right_ankle_roll_joint") == 0,
    "joint 21 is right ankle roll");
  expect(sizeof(smartbot_ii_control::JointTargetPacket) == 5, "packet is 5 bytes");
  expect(sizeof(BusFrame) == 114, "frame is 114 bytes");

  std::array<double, kActuatedJointCount> commands{};
  for (std::size_t i = 0; i < kActuatedJointCount; ++i) {
    commands[i] = 0.01 * static_cast<double>(i) - 0.1;
  }
  BusFrame frame{};
  expect(pack_position_commands(commands.data(), commands.size(), frame), "pack succeeds");
  expect(frame_checksum_ok(frame), "checksum matches");
  for (std::size_t i = 0; i < kActuatedJointCount; ++i) {
    expect(frame.joints[i].joint_id == static_cast<uint8_t>(i), "joint id is the array index");
    const float expected = static_cast<float>(commands[i]);
    expect(frame.joints[i].target_rad == expected, "target matches the float command");
    float decoded = 0.0f;
    std::memcpy(&decoded, &frame.joints[i].target_rad, sizeof(float));
    expect(decoded == expected, "float bytes are native little-endian");
  }

  const BusFrame original = frame;
  commands[3] = std::nan("");
  expect(!pack_position_commands(commands.data(), commands.size(), frame), "NaN is rejected");
  expect(std::memcmp(&frame, &original, sizeof(frame)) == 0, "failed pack leaves the frame");
  expect(!pack_position_commands(commands.data(), 3, frame), "short arrays are rejected");
  expect(!pack_position_commands(nullptr, kActuatedJointCount, frame), "null is rejected");

  commands[3] = 0.0;
  const auto started = std::chrono::steady_clock::now();
  constexpr int kIterations = 1000;
  for (int i = 0; i < kIterations; ++i) {
    commands[0] = 0.001 * static_cast<double>(i);
    if (!pack_position_commands(commands.data(), commands.size(), frame)) {
      expect(false, "timed pack failed");
      break;
    }
  }
  const auto elapsed = std::chrono::steady_clock::now() - started;
  const auto usec =
    std::chrono::duration_cast<std::chrono::microseconds>(elapsed).count();
  // 1000 packs in 100 ms is 100 us each, fifty times under the 1 ms cycle budget.
  expect(usec < 100000, "pack loop is slower than the sub-millisecond budget");

  if (failures != 0) {
    std::cerr << failures << " codec checks failed\n";
    return EXIT_FAILURE;
  }
  std::cout << "joint target codec checks passed in " << usec << " us\n";
  return EXIT_SUCCESS;
}
