// Copyright 2026 SmartBot II Maintainers
// Licensed under the Apache License, Version 2.0.

#include "smartbot_ii_control/smartbot_ii_hardware.hpp"

#include <algorithm>
#include <cerrno>
#include <chrono>
#include <cmath>
#include <cstring>
#include <string>

#include <fcntl.h>
#include <linux/spi/spidev.h>
#include <sys/ioctl.h>
#include <termios.h>
#include <unistd.h>

#include "hardware_interface/types/hardware_interface_type_values.hpp"
#include "pluginlib/class_list_macros.hpp"
#include "smartbot_ii_control/rt_logging.hpp"

namespace smartbot_ii_control
{
namespace
{

const rclcpp::Logger kLogger = rclcpp::get_logger("SmartBotIIHardware");

bool parse_bool(const std::string & text, bool & value)
{
  if (text == "true" || text == "True" || text == "1") {
    value = true;
    return true;
  }
  if (text == "false" || text == "False" || text == "0" || text.empty()) {
    value = false;
    return true;
  }
  return false;
}

const std::string & param_or(
  const std::unordered_map<std::string, std::string> & params,
  const std::string & key,
  const std::string & fallback)
{
  const auto it = params.find(key);
  if (it == params.end()) {
    return fallback;
  }
  return it->second;
}

bool has_interface(
  const std::vector<hardware_interface::InterfaceInfo> & interfaces,
  const std::string & name)
{
  return std::any_of(
    interfaces.begin(), interfaces.end(),
    [&name](const hardware_interface::InterfaceInfo & iface) { return iface.name == name; });
}

speed_t baud_to_speed(int baud, bool & known)
{
  known = true;
  switch (baud) {
    case 9600:
      return B9600;
    case 19200:
      return B19200;
    case 38400:
      return B38400;
    case 57600:
      return B57600;
    case 115200:
      return B115200;
    case 230400:
      return B230400;
#ifdef B460800
    case 460800:
      return B460800;
#endif
#ifdef B921600
    case 921600:
      return B921600;
#endif
    default:
      known = false;
      return B115200;
  }
}

}  // namespace

SmartBotIIHardware::SmartBotIIHardware()
: logger_(kLogger)
{
}

SmartBotIIHardware::~SmartBotIIHardware()
{
  active_ = false;
  stop_bus_thread();
  close_bus();
}

hardware_interface::CallbackReturn SmartBotIIHardware::on_init(
  const hardware_interface::HardwareInfo & info)
{
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wdeprecated-declarations"
  if (
    hardware_interface::SystemInterface::on_init(info) !=
    hardware_interface::CallbackReturn::SUCCESS)
  {
    SMARTBOT_II_LOG_ERROR(logger_, "SystemInterface::on_init failed for SmartBot II.");
    return hardware_interface::CallbackReturn::ERROR;
  }
#pragma GCC diagnostic pop

  if (info_.is_async) {
    SMARTBOT_II_LOG_ERROR(
      logger_,
      "SmartBot II hardware rejects is_async. read() and write() run on the "
      "controller manager thread so the 250 Hz cycle stays allocation-free.");
    return hardware_interface::CallbackReturn::ERROR;
  }
  if (!info_.sensors.empty() || !info_.gpios.empty()) {
    SMARTBOT_II_LOG_ERROR(
      logger_, "SmartBot II hardware accepts 22 joints only. Sensors and GPIOs are not modeled.");
    return hardware_interface::CallbackReturn::ERROR;
  }
  if (info_.joints.size() != kActuatedJointCount) {
    SMARTBOT_II_LOG_ERROR(
      logger_, "Expected %zu joints and found %zu.", kActuatedJointCount, info_.joints.size());
    return hardware_interface::CallbackReturn::ERROR;
  }

  std::array<bool, kActuatedJointCount> seen{};
  seen.fill(false);
  for (const auto & joint : info_.joints) {
    const auto found = std::find_if(
      kActuatedJoints.begin(), kActuatedJoints.end(),
      [&joint](const char * name) { return joint.name == name; });
    if (found == kActuatedJoints.end()) {
      SMARTBOT_II_LOG_ERROR(logger_, "Unknown joint '%s'.", joint.name.c_str());
      return hardware_interface::CallbackReturn::ERROR;
    }
    const auto index = static_cast<std::size_t>(std::distance(kActuatedJoints.begin(), found));
    if (seen[index]) {
      SMARTBOT_II_LOG_ERROR(logger_, "Duplicate joint '%s'.", joint.name.c_str());
      return hardware_interface::CallbackReturn::ERROR;
    }
    seen[index] = true;

    if (joint.command_interfaces.size() != 1 || joint.command_interfaces[0].name != "position") {
      SMARTBOT_II_LOG_ERROR(
        logger_, "Joint '%s' must export exactly one command interface: position.",
        joint.name.c_str());
      return hardware_interface::CallbackReturn::ERROR;
    }
    if (
      joint.state_interfaces.size() != 2 ||
      !has_interface(joint.state_interfaces, "position") ||
      !has_interface(joint.state_interfaces, "velocity"))
    {
      SMARTBOT_II_LOG_ERROR(
        logger_,
        "Joint '%s' must export state interfaces position and velocity, and no others. "
        "Set export_effort_state:=false when loading smartbot_ii_control/SmartBotIIHardware.",
        joint.name.c_str());
      return hardware_interface::CallbackReturn::ERROR;
    }

    const auto & command = joint.command_interfaces[0];
    std::string min_text = command.min.empty() ? param_or(command.parameters, "min", "") : command.min;
    std::string max_text = command.max.empty() ? param_or(command.parameters, "max", "") : command.max;
    try {
      position_min_[index] = std::stod(min_text);
      position_max_[index] = std::stod(max_text);
    } catch (const std::exception &) {
      SMARTBOT_II_LOG_ERROR(
        logger_, "Joint '%s' is missing numeric position min and max.", joint.name.c_str());
      return hardware_interface::CallbackReturn::ERROR;
    }
    if (
      !std::isfinite(position_min_[index]) || !std::isfinite(position_max_[index]) ||
      position_min_[index] > position_max_[index])
    {
      SMARTBOT_II_LOG_ERROR(logger_, "Joint '%s' has an invalid position range.", joint.name.c_str());
      return hardware_interface::CallbackReturn::ERROR;
    }
  }
  for (std::size_t i = 0; i < kActuatedJointCount; ++i) {
    if (!seen[i]) {
      SMARTBOT_II_LOG_ERROR(logger_, "Missing joint '%s'.", kActuatedJoints[i]);
      return hardware_interface::CallbackReturn::ERROR;
    }
  }

  const std::string velocity_text =
    param_or(info_.hardware_parameters, "mock_max_velocity_rad_s", "0.5");
  try {
    mock_max_velocity_rad_s_ = std::stod(velocity_text);
  } catch (const std::exception &) {
    SMARTBOT_II_LOG_ERROR(logger_, "mock_max_velocity_rad_s is not a number.");
    return hardware_interface::CallbackReturn::ERROR;
  }
  if (!std::isfinite(mock_max_velocity_rad_s_) || mock_max_velocity_rad_s_ <= 0.0) {
    SMARTBOT_II_LOG_ERROR(logger_, "mock_max_velocity_rad_s must be positive and finite.");
    return hardware_interface::CallbackReturn::ERROR;
  }

  if (!load_transport_locked()) {
    return hardware_interface::CallbackReturn::ERROR;
  }

  hw_commands_position_.fill(0.0);
  hw_states_position_.fill(0.0);
  hw_states_velocity_.fill(0.0);
  latched_command_.fill(0.0);
  SMARTBOT_II_LOG_INFO(
    logger_,
    "SmartBot II hardware initialized for %zu joints. Transport is mock unless "
    "UART or SPI was explicitly unlocked. This plugin does not claim that the "
    "robot can walk or that a physical motor is safe to enable.",
    kActuatedJointCount);
  return hardware_interface::CallbackReturn::SUCCESS;
}

bool SmartBotIIHardware::load_transport_locked()
{
  const std::string transport_text = param_or(info_.hardware_parameters, "transport", "mock");
  if (transport_text == "mock") {
    transport_ = Transport::Mock;
  } else if (transport_text == "uart") {
    transport_ = Transport::Uart;
  } else if (transport_text == "spi") {
    transport_ = Transport::Spi;
  } else {
    SMARTBOT_II_LOG_ERROR(
      logger_, "Unknown transport '%s'. Use mock, uart, or spi.", transport_text.c_str());
    return false;
  }

  bool allow = false;
  if (!parse_bool(param_or(info_.hardware_parameters, "allow_unvalidated_bus", "false"), allow)) {
    SMARTBOT_II_LOG_ERROR(logger_, "allow_unvalidated_bus must be true or false.");
    return false;
  }
  bool trace = false;
  if (!parse_bool(param_or(info_.hardware_parameters, "rt_trace", "false"), trace)) {
    SMARTBOT_II_LOG_ERROR(logger_, "rt_trace must be true or false.");
    return false;
  }
  rt_trace_ = trace;

  const std::string ack = param_or(info_.hardware_parameters, "physical_hardware_ack", "");
  bus_unlocked_ = allow && ack == kPhysicalAckToken && transport_ != Transport::Mock;
  if (transport_ != Transport::Mock && !bus_unlocked_) {
    SMARTBOT_II_LOG_ERROR(
      logger_,
      "Refusing transport '%s'. UART and SPI stay closed until transport, "
      "allow_unvalidated_bus=true, and physical_hardware_ack='%s' are all set "
      "in the URDF. Unlocking opens a device. It does not add an emergency stop "
      "or validate the motors.",
      transport_text.c_str(), kPhysicalAckToken);
    return false;
  }

  uart_device_ = param_or(info_.hardware_parameters, "uart_device", "/dev/serial0");
  spi_device_ = param_or(info_.hardware_parameters, "spi_device", "/dev/spidev0.0");
  try {
    uart_baud_ = std::stoi(param_or(info_.hardware_parameters, "uart_baud", "115200"));
    spi_speed_hz_ =
      static_cast<uint32_t>(std::stoul(param_or(info_.hardware_parameters, "spi_speed_hz", "1000000")));
    spi_mode_ = static_cast<uint8_t>(std::stoi(param_or(info_.hardware_parameters, "spi_mode", "0")));
  } catch (const std::exception &) {
    SMARTBOT_II_LOG_ERROR(logger_, "UART baud or SPI speed/mode is not numeric.");
    return false;
  }
  if (spi_mode_ > 3) {
    SMARTBOT_II_LOG_ERROR(logger_, "SPI mode must be 0, 1, 2, or 3.");
    return false;
  }
  return true;
}

hardware_interface::CallbackReturn SmartBotIIHardware::on_configure(
  const rclcpp_lifecycle::State & previous_state)
{
  (void)previous_state;
  std::string error;
  if (!open_bus(error)) {
    SMARTBOT_II_LOG_ERROR(logger_, "Bus configure failed: %s", error.c_str());
    close_bus();
    return hardware_interface::CallbackReturn::ERROR;
  }
  if (transport_ == Transport::Mock) {
    SMARTBOT_II_LOG_INFO(
      logger_,
      "Configured mock transport. write() packs joint_id and target_rad into a "
      "%zu byte frame and does not open UART or SPI. Pi 5 UART pins are GPIO14 TX "
      "and GPIO15 RX. SPI0 pins are GPIO10 MOSI, GPIO9 MISO, GPIO11 SCLK, GPIO8 CE0.",
      sizeof(BusFrame));
  } else {
    SMARTBOT_II_LOG_WARN(
      logger_,
      "Configured an unvalidated %s device. Frames will be written as raw bytes. "
      "This is not a motor driver and it will not drop power on deactivate.",
      transport_ == Transport::Uart ? "UART" : "SPI");
  }
  return hardware_interface::CallbackReturn::SUCCESS;
}

bool SmartBotIIHardware::open_bus(std::string & error)
{
  close_bus();
  if (transport_ == Transport::Mock) {
    return true;
  }

  const char * device =
    transport_ == Transport::Uart ? uart_device_.c_str() : spi_device_.c_str();
  bus_fd_ = ::open(device, O_RDWR | O_NOCTTY | O_NONBLOCK | O_CLOEXEC);
  if (bus_fd_ < 0) {
    error = std::string("open ") + device + " failed: " + std::strerror(errno);
    return false;
  }

  if (transport_ == Transport::Uart) {
    bool known = false;
    const speed_t speed = baud_to_speed(uart_baud_, known);
    if (!known) {
      error = "uart_baud is not a supported termios rate";
      return false;
    }
    termios tty{};
    if (tcgetattr(bus_fd_, &tty) != 0) {
      error = std::string("tcgetattr failed: ") + std::strerror(errno);
      return false;
    }
    cfmakeraw(&tty);
    cfsetispeed(&tty, speed);
    cfsetospeed(&tty, speed);
    tty.c_cflag |= (CLOCAL | CREAD | CS8);
    tty.c_cflag &= ~PARENB;
    tty.c_cflag &= ~CSTOPB;
#ifdef CRTSCTS
    tty.c_cflag &= ~CRTSCTS;
#endif
    if (tcsetattr(bus_fd_, TCSANOW, &tty) != 0) {
      error = std::string("tcsetattr failed: ") + std::strerror(errno);
      return false;
    }
    return true;
  }

  const uint8_t mode = spi_mode_;
  const uint8_t bits = 8;
  if (
    ioctl(bus_fd_, SPI_IOC_WR_MODE, &mode) < 0 ||
    ioctl(bus_fd_, SPI_IOC_WR_BITS_PER_WORD, &bits) < 0 ||
    ioctl(bus_fd_, SPI_IOC_WR_MAX_SPEED_HZ, &spi_speed_hz_) < 0)
  {
    error = std::string("SPI setup failed: ") + std::strerror(errno);
    return false;
  }
  return true;
}

void SmartBotIIHardware::close_bus() noexcept
{
  if (bus_fd_ >= 0) {
    ::close(bus_fd_);
    bus_fd_ = -1;
  }
}

hardware_interface::CallbackReturn SmartBotIIHardware::on_cleanup(
  const rclcpp_lifecycle::State & previous_state)
{
  (void)previous_state;
  stop_bus_thread();
  close_bus();
  active_ = false;
  SMARTBOT_II_LOG_INFO(logger_, "SmartBot II hardware cleaned up. The bus device is closed.");
  return hardware_interface::CallbackReturn::SUCCESS;
}

hardware_interface::CallbackReturn SmartBotIIHardware::on_activate(
  const rclcpp_lifecycle::State & previous_state)
{
  (void)previous_state;
  hold_positions();
  rt_fault_logged_ = false;
  overrun_logged_ = false;
  cycle_count_ = 0;
  active_ = true;
  start_bus_thread();
  SMARTBOT_II_LOG_INFO(
    logger_,
    "SmartBot II hardware active. Position commands are packed for joint ids 0..%zu. "
    "Activation does not enable physical motor power.",
    kActuatedJointCount - 1);
  return hardware_interface::CallbackReturn::SUCCESS;
}

hardware_interface::CallbackReturn SmartBotIIHardware::on_deactivate(
  const rclcpp_lifecycle::State & previous_state)
{
  (void)previous_state;
  active_ = false;
  hold_positions();
  BusFrame hold{};
  if (pack_position_commands(latched_command_.data(), latched_command_.size(), hold)) {
    publish_frame(hold);
  }
  stop_bus_thread();
  SMARTBOT_II_LOG_INFO(
    logger_,
    "SmartBot II hardware inactive. The last position command is held in the frame. "
    "Deactivate does not cut motor power. Use a hardware emergency stop for that.");
  return hardware_interface::CallbackReturn::SUCCESS;
}

hardware_interface::CallbackReturn SmartBotIIHardware::on_shutdown(
  const rclcpp_lifecycle::State & previous_state)
{
  (void)previous_state;
  active_ = false;
  stop_bus_thread();
  close_bus();
  SMARTBOT_II_LOG_INFO(logger_, "SmartBot II hardware shut down.");
  return hardware_interface::CallbackReturn::SUCCESS;
}

hardware_interface::CallbackReturn SmartBotIIHardware::on_error(
  const rclcpp_lifecycle::State & previous_state)
{
  (void)previous_state;
  active_ = false;
  stop_bus_thread();
  close_bus();
  SMARTBOT_II_LOG_ERROR(
    logger_, "SmartBot II hardware entered the error state. The bus device was closed.");
  return hardware_interface::CallbackReturn::SUCCESS;
}

void SmartBotIIHardware::hold_positions() noexcept
{
  for (std::size_t i = 0; i < kActuatedJointCount; ++i) {
    hw_commands_position_[i] = hw_states_position_[i];
    latched_command_[i] = hw_states_position_[i];
    hw_states_velocity_[i] = 0.0;
  }
}

void SmartBotIIHardware::start_bus_thread()
{
  stop_bus_thread();
  if (!bus_unlocked_ || bus_fd_ < 0) {
    return;
  }
  bus_running_.store(true, std::memory_order_release);
  bus_thread_ = std::thread([this]() { bus_loop(); });
}

void SmartBotIIHardware::stop_bus_thread()
{
  bus_running_.store(false, std::memory_order_release);
  if (bus_thread_.joinable()) {
    bus_thread_.join();
  }
}

void SmartBotIIHardware::publish_frame(const BusFrame & frame) noexcept
{
  const uint32_t seq = frame_sequence_.load(std::memory_order_relaxed);
  frame_sequence_.store(seq + 1u, std::memory_order_relaxed);
  frame_slots_[(seq / 2u) & 1u] = frame;
  frame_sequence_.store(seq + 2u, std::memory_order_release);
}

bool SmartBotIIHardware::copy_latest_frame(BusFrame & out) const noexcept
{
  for (int attempt = 0; attempt < 3; ++attempt) {
    const uint32_t first = frame_sequence_.load(std::memory_order_acquire);
    if ((first & 1u) != 0u || first == 0u) {
      continue;
    }
    out = frame_slots_[((first / 2u) - 1u) & 1u];
    const uint32_t second = frame_sequence_.load(std::memory_order_acquire);
    if (first == second) {
      return true;
    }
  }
  return false;
}

void SmartBotIIHardware::bus_loop()
{
  uint32_t last_sequence = 0;
  bool error_logged = false;
  while (bus_running_.load(std::memory_order_acquire)) {
    BusFrame frame{};
    if (!copy_latest_frame(frame) || !frame_checksum_ok(frame)) {
      std::this_thread::sleep_for(std::chrono::microseconds(200));
      continue;
    }
    const uint32_t sequence = frame_sequence_.load(std::memory_order_acquire);
    if (sequence == last_sequence) {
      std::this_thread::sleep_for(std::chrono::microseconds(200));
      continue;
    }
    bool ok = false;
    if (transport_ == Transport::Uart) {
      const ssize_t wrote = ::write(bus_fd_, &frame, sizeof(frame));
      ok = wrote == static_cast<ssize_t>(sizeof(frame));
    } else if (transport_ == Transport::Spi) {
      spi_ioc_transfer transfer{};
      transfer.tx_buf = reinterpret_cast<unsigned long>(&frame);
      transfer.len = sizeof(frame);
      transfer.speed_hz = spi_speed_hz_;
      transfer.bits_per_word = 8;
      ok = ioctl(bus_fd_, SPI_IOC_MESSAGE(1), &transfer) >= 0;
    }
    if (!ok && !error_logged) {
      SMARTBOT_II_LOG_ERROR(
        logger_, "Bus write failed: %s. Further bus errors are not logged every cycle.",
        std::strerror(errno));
      error_logged = true;
    }
    if (ok) {
      last_sequence = sequence;
      error_logged = false;
    }
    std::this_thread::sleep_for(std::chrono::microseconds(200));
  }
}

std::vector<hardware_interface::StateInterface> SmartBotIIHardware::export_state_interfaces()
{
  std::vector<hardware_interface::StateInterface> interfaces;
  interfaces.reserve(kActuatedJointCount * 2);
  for (std::size_t i = 0; i < kActuatedJointCount; ++i) {
    interfaces.emplace_back(
      kActuatedJoints[i], hardware_interface::HW_IF_POSITION, &hw_states_position_[i]);
    interfaces.emplace_back(
      kActuatedJoints[i], hardware_interface::HW_IF_VELOCITY, &hw_states_velocity_[i]);
  }
  return interfaces;
}

std::vector<hardware_interface::CommandInterface> SmartBotIIHardware::export_command_interfaces()
{
  std::vector<hardware_interface::CommandInterface> interfaces;
  interfaces.reserve(kActuatedJointCount);
  for (std::size_t i = 0; i < kActuatedJointCount; ++i) {
    interfaces.emplace_back(
      kActuatedJoints[i], hardware_interface::HW_IF_POSITION, &hw_commands_position_[i]);
  }
  return interfaces;
}

hardware_interface::return_type SmartBotIIHardware::read(
  const rclcpp::Time & time, const rclcpp::Duration & period)
{
  (void)time;
  if (!active_) {
    return hardware_interface::return_type::OK;
  }

  double dt = period.seconds();
  if (!std::isfinite(dt) || dt < 0.0) {
    dt = 0.0;
  } else if (dt > 0.02) {
    // A stalled cycle must not integrate a large step. 0.02 s is five 250 Hz ticks.
    dt = 0.02;
  }
  const double max_step = mock_max_velocity_rad_s_ * dt;

  for (std::size_t i = 0; i < kActuatedJointCount; ++i) {
    const double previous = hw_states_position_[i];
    double target = latched_command_[i];
    if (target < position_min_[i]) {
      target = position_min_[i];
    } else if (target > position_max_[i]) {
      target = position_max_[i];
    }
    double step = target - previous;
    if (step > max_step) {
      step = max_step;
    } else if (step < -max_step) {
      step = -max_step;
    }
    double next = previous + step;
    if (next < position_min_[i]) {
      next = position_min_[i];
    } else if (next > position_max_[i]) {
      next = position_max_[i];
    }
    hw_states_position_[i] = next;
    hw_states_velocity_[i] = dt > 0.0 ? (next - previous) / dt : 0.0;
  }
  return hardware_interface::return_type::OK;
}

void SmartBotIIHardware::log_once_rt_fault(const char * message)
{
  if (rt_fault_logged_) {
    return;
  }
  rt_fault_logged_ = true;
  SMARTBOT_II_LOG_ERROR(logger_, "%s", message);
}

hardware_interface::return_type SmartBotIIHardware::write(
  const rclcpp::Time & time, const rclcpp::Duration & period)
{
  (void)time;
  (void)period;
  if (!active_) {
    return hardware_interface::return_type::OK;
  }

  const auto started = std::chrono::steady_clock::now();
  std::array<double, kActuatedJointCount> clamped{};
  for (std::size_t i = 0; i < kActuatedJointCount; ++i) {
    const double command = hw_commands_position_[i];
    if (!std::isfinite(command)) {
      log_once_rt_fault("Rejecting a non-finite position command. The previous frame is held.");
      return hardware_interface::return_type::ERROR;
    }
    double limited = command;
    if (limited < position_min_[i]) {
      limited = position_min_[i];
    } else if (limited > position_max_[i]) {
      limited = position_max_[i];
    }
    clamped[i] = limited;
    latched_command_[i] = limited;
  }

  BusFrame frame{};
  if (!pack_position_commands(clamped.data(), clamped.size(), frame)) {
    log_once_rt_fault("Position frame pack failed. The previous frame is held.");
    return hardware_interface::return_type::ERROR;
  }
  publish_frame(frame);

  const auto elapsed = std::chrono::steady_clock::now() - started;
  if (
    !overrun_logged_ &&
    static_cast<uint64_t>(std::chrono::duration_cast<std::chrono::nanoseconds>(elapsed).count()) >
    SMARTBOT_II_RT_BUDGET_NS)
  {
    overrun_logged_ = true;
    SMARTBOT_II_LOG_ERROR(
      logger_, "write() exceeded the 1 ms budget. Further overruns are not logged every cycle.");
  }

  ++cycle_count_;
  if (rt_trace_ && (cycle_count_ % SMARTBOT_II_RT_TRACE_STRIDE) == 0u) {
    SMARTBOT_II_LOG_INFO(
      logger_, "RT trace cycle %u joint 0 target %.4f rad. Mock transport does not drive pins.",
      cycle_count_, frame.joints[0].target_rad);
  }
  return hardware_interface::return_type::OK;
}

}  // namespace smartbot_ii_control

PLUGINLIB_EXPORT_CLASS(
  smartbot_ii_control::SmartBotIIHardware, hardware_interface::SystemInterface)
