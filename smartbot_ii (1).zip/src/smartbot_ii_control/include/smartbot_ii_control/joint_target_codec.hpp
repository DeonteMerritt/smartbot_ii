// Copyright 2026 SmartBot II Maintainers
// Licensed under the Apache License, Version 2.0.

#ifndef SMARTBOT_II_CONTROL__JOINT_TARGET_CODEC_HPP_
#define SMARTBOT_II_CONTROL__JOINT_TARGET_CODEC_HPP_

#include <array>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstring>

// Joint order matches seldun_smartbot_bridge.validator.ACTUATED_JOINTS.
// joint_id on the wire is the index in this array. Do not reorder it.

namespace smartbot_ii_control
{

inline constexpr std::size_t kActuatedJointCount = 22;

inline constexpr std::array<const char *, kActuatedJointCount> kActuatedJoints = {{
  "neck_yaw_joint",
  "neck_pitch_joint",
  "left_shoulder_pitch_joint",
  "left_shoulder_roll_joint",
  "left_elbow_joint",
  "left_wrist_joint",
  "right_shoulder_pitch_joint",
  "right_shoulder_roll_joint",
  "right_elbow_joint",
  "right_wrist_joint",
  "left_hip_yaw_joint",
  "left_hip_roll_joint",
  "left_hip_pitch_joint",
  "left_knee_joint",
  "left_ankle_pitch_joint",
  "left_ankle_roll_joint",
  "right_hip_yaw_joint",
  "right_hip_roll_joint",
  "right_hip_pitch_joint",
  "right_knee_joint",
  "right_ankle_pitch_joint",
  "right_ankle_roll_joint",
}};

// Same gate as the Seldun bridge. Setting this string does not validate motors.
inline constexpr const char * kPhysicalAckToken = "ENABLE_UNVALIDATED_PHYSICAL_HARDWARE";

// Raspberry Pi 5 is little-endian. The float in JointTargetPacket is IEEE-754
// binary32 in native little-endian byte order, which is the Pi 5 wire order.
#if defined(__BYTE_ORDER__) && defined(__ORDER_LITTLE_ENDIAN__)
static_assert(__BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__, "JointTargetPacket requires little-endian");
#endif

inline constexpr uint8_t kFrameSync0 = 0xA5;
inline constexpr uint8_t kFrameSync1 = 0x5A;

// One commanded joint. 5 bytes, no padding: uint8_t joint_id, float target_rad.
#pragma pack(push, 1)
struct JointTargetPacket
{
  uint8_t joint_id;
  float target_rad;
};
#pragma pack(pop)

static_assert(sizeof(JointTargetPacket) == 5, "packet must be joint_id plus float32");
static_assert(offsetof(JointTargetPacket, target_rad) == 1, "float must follow joint_id");

// Fixed frame for a UART burst or one SPI transfer.
// 3 byte header + 22 packets + 1 XOR checksum = 114 bytes.
#pragma pack(push, 1)
struct BusFrame
{
  uint8_t sync0;
  uint8_t sync1;
  uint8_t joint_count;
  JointTargetPacket joints[kActuatedJointCount];
  uint8_t checksum;
};
#pragma pack(pop)

static_assert(sizeof(BusFrame) == 114, "bus frame size is part of the wire contract");

inline uint8_t frame_checksum(const BusFrame & frame) noexcept
{
  const auto * bytes = reinterpret_cast<const uint8_t *>(&frame);
  uint8_t sum = 0;
  for (std::size_t i = 0; i + 1 < sizeof(BusFrame); ++i) {
    sum = static_cast<uint8_t>(sum ^ bytes[i]);
  }
  return sum;
}

inline bool frame_checksum_ok(const BusFrame & frame) noexcept
{
  return frame.sync0 == kFrameSync0 && frame.sync1 == kFrameSync1 &&
         frame.joint_count == static_cast<uint8_t>(kActuatedJointCount) &&
         frame.checksum == frame_checksum(frame);
}

// Pack 22 finite joint positions. No heap use. On failure the output is unchanged.
inline bool pack_position_commands(
  const double * commands, std::size_t count, BusFrame & frame) noexcept
{
  if (commands == nullptr || count != kActuatedJointCount) {
    return false;
  }

  BusFrame packed{};
  packed.sync0 = kFrameSync0;
  packed.sync1 = kFrameSync1;
  packed.joint_count = static_cast<uint8_t>(kActuatedJointCount);
  for (std::size_t i = 0; i < kActuatedJointCount; ++i) {
    const double command = commands[i];
    if (!std::isfinite(command)) {
      return false;
    }
    const float target = static_cast<float>(command);
    if (!std::isfinite(target)) {
      return false;
    }
    packed.joints[i].joint_id = static_cast<uint8_t>(i);
    packed.joints[i].target_rad = target;
  }
  packed.checksum = frame_checksum(packed);
  frame = packed;
  return true;
}

}  // namespace smartbot_ii_control

#endif  // SMARTBOT_II_CONTROL__JOINT_TARGET_CODEC_HPP_
