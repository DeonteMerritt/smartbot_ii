// Copyright 2026 SmartBot II Maintainers
// Licensed under the Apache License, Version 2.0.

#ifndef SMARTBOT_II_CONTROL__SMARTBOT_II_HARDWARE_HPP_
#define SMARTBOT_II_CONTROL__SMARTBOT_II_HARDWARE_HPP_

#include <array>
#include <atomic>
#include <cstdint>
#include <string>
#include <thread>

#include "hardware_interface/handle.hpp"
#include "hardware_interface/hardware_info.hpp"
#include "hardware_interface/system_interface.hpp"
#include "hardware_interface/types/hardware_interface_return_values.hpp"
#include "rclcpp/logger.hpp"
#include "rclcpp/macros.hpp"
#include "rclcpp_lifecycle/state.hpp"
#include "smartbot_ii_control/joint_target_codec.hpp"

namespace smartbot_ii_control
{

// ros2_control system for the 22 SmartBot II actuated joints.
//
// State interfaces: position, velocity.
// Command interface: position.
//
// write() copies the position commands into a fixed BusFrame
// (uint8_t joint_id, float target_rad) and publishes that frame.
// The default transport is "mock": the frame is packed and nothing is
// written to a pin. UART and SPI open a device only when the URDF sets
// transport, allow_unvalidated_bus, and physical_hardware_ack together.
// That unlock still does not add a hardware emergency stop, a current
// limit, or a walking controller. Deactivate holds the last position.
// It does not remove motor power.
//
// read() and write() do not allocate. The bus thread, when enabled, is
// started in on_activate and joined in on_deactivate.
class SmartBotIIHardware : public hardware_interface::SystemInterface
{
public:
  RCLCPP_SHARED_PTR_DEFINITIONS(SmartBotIIHardware)

  hardware_interface::CallbackReturn on_init(
    const hardware_interface::HardwareInfo & info) override;

  hardware_interface::CallbackReturn on_configure(
    const rclcpp_lifecycle::State & previous_state) override;

  hardware_interface::CallbackReturn on_cleanup(
    const rclcpp_lifecycle::State & previous_state) override;

  hardware_interface::CallbackReturn on_activate(
    const rclcpp_lifecycle::State & previous_state) override;

  hardware_interface::CallbackReturn on_deactivate(
    const rclcpp_lifecycle::State & previous_state) override;

  hardware_interface::CallbackReturn on_shutdown(
    const rclcpp_lifecycle::State & previous_state) override;

  hardware_interface::CallbackReturn on_error(
    const rclcpp_lifecycle::State & previous_state) override;

  std::vector<hardware_interface::StateInterface> export_state_interfaces() override;

  std::vector<hardware_interface::CommandInterface> export_command_interfaces() override;

  hardware_interface::return_type read(
    const rclcpp::Time & time, const rclcpp::Duration & period) override;

  hardware_interface::return_type write(
    const rclcpp::Time & time, const rclcpp::Duration & period) override;

  SmartBotIIHardware();
  ~SmartBotIIHardware() override;

private:
  enum class Transport
  {
    Mock,
    Uart,
    Spi
  };

  bool load_transport_locked();
  bool open_bus(std::string & error);
  void close_bus() noexcept;
  void start_bus_thread();
  void stop_bus_thread();
  void bus_loop();
  void publish_frame(const BusFrame & frame) noexcept;
  bool copy_latest_frame(BusFrame & out) const noexcept;
  void hold_positions() noexcept;
  void log_once_rt_fault(const char * message);

  rclcpp::Logger logger_;

  std::array<double, kActuatedJointCount> hw_commands_position_{};
  std::array<double, kActuatedJointCount> hw_states_position_{};
  std::array<double, kActuatedJointCount> hw_states_velocity_{};
  std::array<double, kActuatedJointCount> latched_command_{};
  std::array<double, kActuatedJointCount> position_min_{};
  std::array<double, kActuatedJointCount> position_max_{};

  double mock_max_velocity_rad_s_{0.5};
  bool rt_trace_{false};
  bool active_{false};
  Transport transport_{Transport::Mock};
  bool bus_unlocked_{false};

  std::string uart_device_{"/dev/serial0"};
  int uart_baud_{115200};
  std::string spi_device_{"/dev/spidev0.0"};
  uint32_t spi_speed_hz_{1000000};
  uint8_t spi_mode_{0};

  int bus_fd_{-1};
  std::thread bus_thread_;
  std::atomic<bool> bus_running_{false};

  BusFrame frame_slots_[2]{};
  std::atomic<uint32_t> frame_sequence_{0};
  uint32_t cycle_count_{0};
  bool rt_fault_logged_{false};
  bool overrun_logged_{false};
};

}  // namespace smartbot_ii_control

#endif  // SMARTBOT_II_CONTROL__SMARTBOT_II_HARDWARE_HPP_
