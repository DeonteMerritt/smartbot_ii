// Copyright 2026 SmartBot II Maintainers
// Licensed under the Apache License, Version 2.0.

#ifndef SMARTBOT_II_CONTROL__RT_LOGGING_HPP_
#define SMARTBOT_II_CONTROL__RT_LOGGING_HPP_

#include "rclcpp/logging.hpp"

// Lifecycle and fault logs. Do not call these on every 250 Hz tick.
// RCLCPP_* can take a lock and format a string. The nominal read/write path
// stays silent unless rt_trace was enabled at configure time.

#define SMARTBOT_II_LOG_INFO(logger, ...) RCLCPP_INFO((logger), __VA_ARGS__)
#define SMARTBOT_II_LOG_ERROR(logger, ...) RCLCPP_ERROR((logger), __VA_ARGS__)
#define SMARTBOT_II_LOG_WARN(logger, ...) RCLCPP_WARN((logger), __VA_ARGS__)

// One trace line per second when the controller manager runs at 250 Hz.
#define SMARTBOT_II_RT_TRACE_STRIDE 250u

// Nominal read/write budget. The controller manager update_rate is 250 Hz.
#define SMARTBOT_II_RT_BUDGET_NS 1000000u

#endif  // SMARTBOT_II_CONTROL__RT_LOGGING_HPP_
