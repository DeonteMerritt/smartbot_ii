"""Spawn SmartBot II in Gazebo Sim.

The pelvis is welded to a fixed frame by default so joint motion does not
require a balance controller. Releasing that weld does not make the robot walk.
The hardware plugin is gz_ros2_control/GazeboSimSystem.
"""

from launch import LaunchDescription
from launch.actions import (
    DeclareLaunchArgument,
    IncludeLaunchDescription,
    LogInfo,
    OpaqueFunction,
    RegisterEventHandler,
)
from launch.conditions import IfCondition
from launch.event_handlers import OnProcessExit
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import (
    Command,
    FindExecutable,
    LaunchConfiguration,
    PathJoinSubstitution,
)
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare

# Must match pelvis_height_above_ground in smartbot_ii.constants.xacro.
FREE_STANDING_SPAWN_Z = 0.92


def _spawn_and_controllers(context):
    raw_z = LaunchConfiguration("spawn_z").perform(context)
    fixed = LaunchConfiguration("fix_pelvis_to_world").perform(context)
    if raw_z == "auto":
        spawn_z = "0.0" if fixed == "true" else str(FREE_STANDING_SPAWN_Z)
    else:
        spawn_z = raw_z

    controllers = PathJoinSubstitution(
        [FindPackageShare("smartbot_ii_control"), "config", "ros2_controllers.yaml"]
    )
    use_sim_time = LaunchConfiguration("use_sim_time")
    spawn = Node(
        package="ros_gz_sim",
        executable="create",
        output="screen",
        parameters=[{"use_sim_time": use_sim_time}],
        arguments=[
            "-topic",
            "robot_description",
            "-name",
            "smartbot_ii",
            "-allow_renaming",
            "true",
            "-x",
            "0",
            "-y",
            "0",
            "-z",
            spawn_z,
        ],
    )
    joint_state_broadcaster = Node(
        package="controller_manager",
        executable="spawner",
        output="screen",
        parameters=[{"use_sim_time": use_sim_time}],
        arguments=[
            "joint_state_broadcaster",
            "--controller-manager-timeout",
            "60",
            "--param-file",
            controllers,
        ],
    )
    trajectory_controller = Node(
        package="controller_manager",
        executable="spawner",
        output="screen",
        parameters=[{"use_sim_time": use_sim_time}],
        arguments=[
            "smartbot_joint_trajectory_controller",
            "--controller-manager-timeout",
            "60",
            "--param-file",
            controllers,
        ],
    )
    return [
        spawn,
        RegisterEventHandler(
            event_handler=OnProcessExit(
                target_action=spawn,
                on_exit=[joint_state_broadcaster],
            )
        ),
        RegisterEventHandler(
            event_handler=OnProcessExit(
                target_action=joint_state_broadcaster,
                on_exit=[trajectory_controller],
            )
        ),
    ]


def generate_launch_description():
    description_share = FindPackageShare("smartbot_ii_description")
    gazebo_share = FindPackageShare("smartbot_ii_gazebo")
    control_share = FindPackageShare("smartbot_ii_control")
    xacro_file = PathJoinSubstitution(
        [description_share, "urdf", "smartbot_ii.urdf.xacro"]
    )
    controllers = PathJoinSubstitution(
        [control_share, "config", "ros2_controllers.yaml"]
    )
    world = PathJoinSubstitution(
        [gazebo_share, "worlds", "smartbot_ii_test.sdf"]
    )
    rviz_config = PathJoinSubstitution(
        [description_share, "rviz", "smartbot_ii.rviz"]
    )
    robot_description = Command(
        [
            FindExecutable(name="xacro"),
            " ",
            xacro_file,
            " use_ros2_control:=true",
            " use_gazebo:=true",
            " hardware_plugin:=gz_ros2_control/GazeboSimSystem",
            " fix_pelvis_to_world:=",
            LaunchConfiguration("fix_pelvis_to_world"),
            " controllers_file:=",
            controllers,
            " use_meshes:=",
            LaunchConfiguration("use_meshes"),
            " use_collision_meshes:=",
            LaunchConfiguration("use_collision_meshes"),
        ]
    )
    use_sim_time = LaunchConfiguration("use_sim_time")

    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            PathJoinSubstitution(
                [FindPackageShare("ros_gz_sim"), "launch", "gz_sim.launch.py"]
            )
        ),
        launch_arguments=[("gz_args", ["-r -v 3 ", world])],
    )
    bridge = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            PathJoinSubstitution(
                [
                    FindPackageShare("seldun_smartbot_bridge"),
                    "launch",
                    "seldun_bridge.launch.py",
                ]
            )
        ),
        condition=IfCondition(LaunchConfiguration("start_seldun_bridge")),
        launch_arguments={"use_sim_time": use_sim_time}.items(),
    )

    return LaunchDescription(
        [
            DeclareLaunchArgument(
                "fix_pelvis_to_world",
                default_value="true",
                description=(
                    "Weld the pelvis so joint tests do not fall. "
                    "false spawns a free robot with no balance controller."
                ),
            ),
            DeclareLaunchArgument(
                "spawn_z",
                default_value="auto",
                description=(
                    "Pelvis spawn height in meters. auto uses 0 when the pelvis "
                    "is welded and FREE_STANDING_SPAWN_Z when it is not."
                ),
            ),
            DeclareLaunchArgument("use_sim_time", default_value="true"),
            DeclareLaunchArgument("rviz", default_value="true"),
            DeclareLaunchArgument("use_meshes", default_value="false"),
            DeclareLaunchArgument("use_collision_meshes", default_value="false"),
            DeclareLaunchArgument(
                "start_seldun_bridge",
                default_value="false",
                description="Also start the Seldun command bridge in simulation mode.",
            ),
            LogInfo(
                msg=(
                    "SmartBot II Gazebo launch is simulation only. "
                    "A welded pelvis is not balance. A free pelvis will fall. "
                    "This launch does not walk and does not command physical motors."
                )
            ),
            gazebo,
            Node(
                package="ros_gz_bridge",
                executable="parameter_bridge",
                output="screen",
                parameters=[{"use_sim_time": use_sim_time}],
                arguments=["/clock@rosgraph_msgs/msg/Clock[gz.msgs.Clock"],
            ),
            Node(
                package="robot_state_publisher",
                executable="robot_state_publisher",
                output="screen",
                parameters=[
                    {
                        "robot_description": robot_description,
                        "use_sim_time": use_sim_time,
                    }
                ],
            ),
            Node(
                package="rviz2",
                executable="rviz2",
                name="rviz2",
                arguments=["-d", rviz_config],
                condition=IfCondition(LaunchConfiguration("rviz")),
                parameters=[{"use_sim_time": use_sim_time}],
                output="screen",
            ),
            OpaqueFunction(function=_spawn_and_controllers),
            bridge,
        ]
    )
