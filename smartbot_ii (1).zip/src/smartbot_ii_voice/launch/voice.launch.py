"""Start the SmartBot voice node. Speech does not move the robot."""

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, LogInfo
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    params = PathJoinSubstitution(
        [FindPackageShare("smartbot_ii_voice"), "config", "voice_params.yaml"]
    )
    return LaunchDescription(
        [
            DeclareLaunchArgument(
                "env_file",
                default_value="",
                description="Path to a .env file with ELEVENLABS_API_KEY and VOICE_ID.",
            ),
            LogInfo(
                msg=(
                    "smartbot_voice_node listens on /smartbot/speech_request. "
                    "It streams speech only. It does not command joints."
                )
            ),
            Node(
                package="smartbot_ii_voice",
                executable="smartbot_voice_node",
                name="smartbot_voice_node",
                output="screen",
                parameters=[
                    params,
                    {"env_file": LaunchConfiguration("env_file")},
                ],
            ),
        ]
    )
