"""Speech streaming tests. No ROS graph and no ElevenLabs network call."""

import ast
import asyncio
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from smartbot_ii_voice.speech import (  # noqa: E402
    DEFAULT_MODEL_ID,
    OUTPUT_FORMAT,
    SPEECH_REQUEST_TOPIC,
    SpeechEngine,
    SpeechWorker,
    StreamingSpeaker,
    VoiceSettings,
    load_voice_settings,
)


class _ChunkStream:
    def __init__(self, chunks, pause_after_first: asyncio.Event | None = None, error=None) -> None:
        self._chunks = list(chunks)
        self._pause = pause_after_first
        self._error = error
        self._yielded = 0

    def __aiter__(self):
        return self

    async def __anext__(self):
        if self._error is not None and self._yielded == 0 and not self._chunks:
            raise self._error
        if not self._chunks:
            raise StopAsyncIteration
        if self._pause is not None and self._yielded == 1:
            if isinstance(self._pause, threading.Event):
                await asyncio.to_thread(self._pause.wait)
            else:
                await self._pause.wait()
        item = self._chunks.pop(0)
        self._yielded += 1
        if isinstance(item, BaseException):
            raise item
        return item


class _Client:
    def __init__(self, stream: _ChunkStream) -> None:
        self.text_to_speech = self
        self._stream = stream
        self.calls = []

    def stream(self, **kwargs):
        self.calls.append(kwargs)
        return self._stream


class _Recording:
    def __init__(self) -> None:
        self.chunks = []
        self.first = threading.Event()

    def start(self) -> None:
        return None

    def submit(self, chunk: bytes) -> None:
        self.chunks.append(chunk)
        self.first.set()

    def finish(self) -> None:
        return None

    def abort(self) -> None:
        return None


def _client_factory(stream):
    client = _Client(stream)

    def factory(_settings):
        return client

    factory.client = client
    return factory


class SpeechStreamTest(unittest.TestCase):
    def test_env_file_supplies_key_and_voice_without_touching_the_process(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / ".env"
            path.write_text(
                "ELEVENLABS_API_KEY=test-key\nVOICE_ID=voice-22\n"
                "ELEVENLABS_MODEL_ID=eleven_flash_v2.5\n",
                encoding="utf-8",
            )
            settings = load_voice_settings(str(path), environ={})
        self.assertEqual(settings.api_key, "test-key")
        self.assertEqual(settings.voice_id, "voice-22")
        self.assertEqual(settings.model_id, DEFAULT_MODEL_ID)
        self.assertFalse(settings.env_file_missing)

    def test_missing_env_file_is_flagged(self):
        settings = load_voice_settings("/tmp/smartbot-voice-missing.env", environ={})
        self.assertTrue(settings.env_file_missing)
        self.assertEqual(settings.api_key, "")

    def test_missing_credentials_do_not_call_the_client(self):
        warnings = []
        factory = _client_factory(_ChunkStream([b"nope"]))
        engine = SpeechEngine(
            VoiceSettings(api_key="", voice_id=""),
            warnings.append,
            client_factory=factory,
            speaker_factory=_Recording,
        )
        self.assertFalse(asyncio.run(engine.speak("hello")))
        self.assertEqual(factory.client.calls, [])
        self.assertTrue(any("ELEVENLABS_API_KEY" in message for message in warnings))

    def test_first_chunk_is_played_before_the_rest_of_the_sentence(self):
        release = asyncio.Event()
        stream = _ChunkStream([b"first-mp3", b"rest-mp3"], pause_after_first=release)
        factory = _client_factory(stream)
        speaker = _Recording()
        engine = SpeechEngine(
            VoiceSettings(api_key="secret-key", voice_id="voice-22", timeout_sec=2.0),
            lambda _message: None,
            client_factory=factory,
            speaker_factory=lambda: speaker,
        )

        async def run():
            task = asyncio.create_task(engine.speak("The arm is clear."))
            self.assertTrue(await asyncio.to_thread(speaker.first.wait, 1.0))
            self.assertEqual(speaker.chunks, [b"first-mp3"])
            self.assertFalse(task.done())
            release.set()
            self.assertTrue(await task)

        asyncio.run(run())
        call = factory.client.calls[0]
        self.assertEqual(call["voice_id"], "voice-22")
        self.assertEqual(call["model_id"], DEFAULT_MODEL_ID)
        self.assertEqual(call["output_format"], OUTPUT_FORMAT)
        self.assertEqual(call["optimize_streaming_latency"], 3)
        self.assertEqual(speaker.chunks, [b"first-mp3", b"rest-mp3"])

    def test_generation_timeout_warns_and_returns(self):
        warnings = []
        stream = _ChunkStream([b"partial", TimeoutError("read timed out")])
        engine = SpeechEngine(
            VoiceSettings(api_key="secret-key", voice_id="voice-22", timeout_sec=1.0),
            warnings.append,
            client_factory=_client_factory(stream),
            speaker_factory=_Recording,
        )
        self.assertFalse(asyncio.run(engine.speak("status")))
        self.assertTrue(any("timed out" in message for message in warnings))
        self.assertFalse(any("secret-key" in message for message in warnings))

    def test_network_drop_warns_without_the_api_key(self):
        warnings = []
        stream = _ChunkStream([ConnectionError("connection reset; secret-key")])
        engine = SpeechEngine(
            VoiceSettings(api_key="secret-key", voice_id="voice-22"),
            warnings.append,
            client_factory=_client_factory(stream),
            speaker_factory=_Recording,
        )
        self.assertFalse(asyncio.run(engine.speak("status")))
        self.assertTrue(any("network drop" in message for message in warnings))
        self.assertFalse(any("secret-key" in message for message in warnings))
        self.assertTrue(any("[redacted]" in message for message in warnings))

    def test_submit_returns_before_the_stream_finishes(self):
        release = threading.Event()
        stream = _ChunkStream([b"a", b"b"], pause_after_first=release)
        speaker = _Recording()
        worker = SpeechWorker(
            VoiceSettings(api_key="k", voice_id="v", timeout_sec=2.0),
            lambda _message: None,
            client_factory=_client_factory(stream),
            speaker_factory=lambda: speaker,
        )
        worker.start()
        try:
            started = time.monotonic()
            worker.submit("hello from the bus")
            self.assertLess(time.monotonic() - started, 0.2)
            self.assertTrue(speaker.first.wait(1.0))
            release.set()
        finally:
            worker.stop()

    def test_mp3_playback_starts_before_the_rest_of_the_file_is_submitted(self):
        ffmpeg = shutil.which("ffmpeg")
        if ffmpeg is None:
            self.skipTest("ffmpeg is not installed")
        with tempfile.TemporaryDirectory() as directory:
            mp3_path = Path(directory) / "tone.mp3"
            generated = subprocess.run(
                [
                    ffmpeg,
                    "-hide_banner",
                    "-loglevel",
                    "error",
                    "-f",
                    "lavfi",
                    "-i",
                    "sine=frequency=440:duration=2",
                    "-ar",
                    "22050",
                    "-ac",
                    "1",
                    "-b:a",
                    "32k",
                    "-write_xing",
                    "0",
                    "-id3v2_version",
                    "0",
                    "-f",
                    "mp3",
                    str(mp3_path),
                ],
                check=False,
                capture_output=True,
            )
            if generated.returncode != 0:
                self.skipTest(generated.stderr.decode("utf-8", errors="replace"))
            mp3 = mp3_path.read_bytes()
        self.assertGreater(len(mp3), 5000)
        prefix, rest = mp3[:2500], mp3[2500:]
        played = bytearray()
        started = threading.Event()

        class _Capture:
            def write(self, pcm: bytes) -> None:
                played.extend(pcm)
                started.set()

            def close(self) -> None:
                return None

        speaker = StreamingSpeaker(lambda _message: None, output_opener=lambda: _Capture())
        speaker.start()
        try:
            speaker.submit(prefix)
            self.assertTrue(started.wait(3.0), "PCM was not produced from the first MP3 bytes")
            self.assertGreater(len(played), 0)
            speaker.submit(rest)
        finally:
            speaker.finish()
        self.assertGreater(len(played), 1000)

    def test_voice_node_subscribes_and_warns_through_the_ros_logger(self):
        path = Path(__file__).resolve().parents[1] / "smartbot_ii_voice" / "voice_node.py"
        tree = ast.parse(path.read_text(encoding="utf-8"))
        init_names = []
        callback_calls = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
                if node.func.attr == "__init__" and node.args:
                    init_names.append(ast.literal_eval(node.args[0]) if isinstance(node.args[0], ast.Constant) else "")
            if isinstance(node, ast.FunctionDef) and node.name == "_on_speech_request":
                for child in ast.walk(node):
                    if isinstance(child, ast.Call) and isinstance(child.func, ast.Attribute):
                        callback_calls.append(child.func.attr)
        self.assertIn("smartbot_voice_node", init_names)
        text = path.read_text(encoding="utf-8")
        self.assertIn(SPEECH_REQUEST_TOPIC, text)
        self.assertIn("std_msgs.msg import String", text)
        self.assertIn("get_logger().warn", text)
        self.assertIn("submit", callback_calls)
        self.assertNotIn("speak", callback_calls)


if __name__ == "__main__":
    unittest.main()
