"""ROS 2 node that speaks text from /smartbot/speech_request.

Warnings use the node logger at WARN severity. That is the rclpy counterpart
of RCLCPP_WARN. A network drop or a generation timeout is logged and the node
keeps listening. This node does not command joints.
"""

from __future__ import annotations

import rclpy
from rclpy.node import Node
from std_msgs.msg import String

from smartbot_ii_voice.speech import (
    OUTPUT_FORMAT,
    SPEECH_REQUEST_TOPIC,
    SpeechWorker,
    load_voice_settings,
    normalize_model_id,
)


class SmartbotVoiceNode(Node):
    def __init__(self) -> None:
        super().__init__("smartbot_voice_node")
        self.declare_parameter("speech_request_topic", SPEECH_REQUEST_TOPIC)
        self.declare_parameter("env_file", "")
        self.declare_parameter("generation_timeout_sec", 15.0)
        self.declare_parameter("model_id", "eleven_flash_v2_5")
        self.declare_parameter("optimize_streaming_latency", 3)

        env_file = self.get_parameter("env_file").get_parameter_value().string_value
        settings = load_voice_settings(env_file or None)
        settings.model_id = normalize_model_id(
            self.get_parameter("model_id").get_parameter_value().string_value
        )
        settings.timeout_sec = (
            self.get_parameter("generation_timeout_sec").get_parameter_value().double_value
        )
        if settings.timeout_sec <= 0.0:
            settings.timeout_sec = 15.0
        settings.optimize_streaming_latency = int(
            self.get_parameter("optimize_streaming_latency").get_parameter_value().integer_value
        )
        if settings.env_file_missing:
            self.get_logger().warn(
                f"env_file '{env_file}' was not found. "
                "ELEVENLABS_API_KEY and VOICE_ID were read from the process environment only."
            )
        if not settings.api_key or not settings.voice_id:
            self.get_logger().warn(
                "ELEVENLABS_API_KEY or VOICE_ID is missing. "
                "Copy config/voice.env.example to a file outside the repo and pass env_file. "
                "Speech requests will be ignored."
            )

        self._worker = SpeechWorker(settings, self.get_logger().warn)
        self._worker.start()
        topic = (
            self.get_parameter("speech_request_topic").get_parameter_value().string_value
            or SPEECH_REQUEST_TOPIC
        )
        self.create_subscription(String, topic, self._on_speech_request, 10)
        self.get_logger().info(
            f"Listening on {topic}. Model {settings.model_id}, format {OUTPUT_FORMAT}. "
            "Playback starts while the sentence is still streaming. Joints are not commanded."
        )

    def _on_speech_request(self, msg: String) -> None:
        text = msg.data.strip()
        if not text:
            self.get_logger().warn("Ignored an empty /smartbot/speech_request.")
            return
        self._worker.submit(text)

    def destroy_node(self):
        self._worker.stop()
        return super().destroy_node()


def main(args=None) -> None:
    rclpy.init(args=args)
    node = SmartbotVoiceNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()
