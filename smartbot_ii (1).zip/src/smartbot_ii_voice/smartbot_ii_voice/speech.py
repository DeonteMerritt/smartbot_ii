"""Stream ElevenLabs speech and play it as the bytes arrive.

This module does not import ROS. The voice node turns warnings into
logger.warn, which is the rclpy WARN severity.
"""

from __future__ import annotations

import asyncio
import inspect
import shutil
import subprocess
import threading
import time
from collections.abc import AsyncIterator, Callable, Mapping
from dataclasses import dataclass
from pathlib import Path

from dotenv import dotenv_values

# Flash v2.5. The API id uses an underscore. "eleven_flash_v2.5" is accepted
# as an alias. "eleven_v4_turbo" is not a current ElevenLabs model id.
DEFAULT_MODEL_ID = "eleven_flash_v2_5"
OUTPUT_FORMAT = "mp3_22050_32"
SAMPLE_RATE = 22050
SPEECH_REQUEST_TOPIC = "/smartbot/speech_request"
QUEUE_DEPTH = 4
_MODEL_ALIASES = {
    "eleven_flash_v2.5": DEFAULT_MODEL_ID,
    "eleven_flash_v2_5": DEFAULT_MODEL_ID,
}
_BUFFER_LIMIT = 256 * 1024


@dataclass
class VoiceSettings:
    api_key: str
    voice_id: str
    model_id: str = DEFAULT_MODEL_ID
    output_format: str = OUTPUT_FORMAT
    timeout_sec: float = 15.0
    optimize_streaming_latency: int = 3
    env_file: str = ""
    env_file_missing: bool = False


def normalize_model_id(model_id: str) -> str:
    cleaned = model_id.strip()
    if not cleaned:
        return DEFAULT_MODEL_ID
    return _MODEL_ALIASES.get(cleaned, cleaned)


def load_voice_settings(
    env_file: str | None = None,
    environ: Mapping[str, str] | None = None,
) -> VoiceSettings:
    """Load the key and voice id from the environment, then from a .env file."""
    source = environ if environ is not None else __import__("os").environ
    path, missing = _resolve_env_file(env_file, source)
    file_values: dict[str, str] = {}
    if path:
        file_values = {
            key: value
            for key, value in dotenv_values(path).items()
            if value is not None and value != ""
        }

    def pick(name: str) -> str:
        current = str(source.get(name, "")).strip()
        if current:
            return current
        return str(file_values.get(name, "")).strip()

    timeout_text = pick("ELEVENLABS_TIMEOUT_SEC")
    try:
        timeout_sec = float(timeout_text) if timeout_text else 15.0
    except ValueError:
        timeout_sec = 15.0
    if timeout_sec <= 0.0:
        timeout_sec = 15.0
    latency_text = pick("ELEVENLABS_LATENCY")
    try:
        latency = int(latency_text) if latency_text else 3
    except ValueError:
        latency = 3
    latency = min(4, max(0, latency))
    return VoiceSettings(
        api_key=pick("ELEVENLABS_API_KEY"),
        voice_id=pick("VOICE_ID"),
        model_id=normalize_model_id(pick("ELEVENLABS_MODEL_ID")),
        timeout_sec=timeout_sec,
        optimize_streaming_latency=latency,
        env_file=path or (env_file or ""),
        env_file_missing=missing,
    )


def _resolve_env_file(
    env_file: str | None, source: Mapping[str, str]
) -> tuple[str | None, bool]:
    if env_file:
        candidate = Path(env_file)
        if candidate.is_file():
            return str(candidate), False
        return None, True
    named = str(source.get("SMARTBOT_VOICE_ENV", "")).strip()
    candidates = []
    if named:
        candidates.append(Path(named))
    candidates.extend((Path.cwd() / "voice.env", Path.cwd() / ".env"))
    for candidate in candidates:
        if candidate.is_file():
            return str(candidate), False
    return None, False


def default_client_factory(settings: VoiceSettings):
    from elevenlabs.client import AsyncElevenLabs

    return AsyncElevenLabs(api_key=settings.api_key, timeout=settings.timeout_sec)


class _PushSource:
    """Byte queue that a decoder can block on until the network sends more."""

    def __init__(self) -> None:
        self._buf = bytearray()
        self._cond = threading.Condition()
        self._eof = False
        self.aborted = False

    def push(self, data: bytes) -> None:
        if not data:
            return
        with self._cond:
            while len(self._buf) > _BUFFER_LIMIT and not self.aborted and not self._eof:
                self._cond.wait(timeout=0.05)
            if self.aborted or self._eof:
                return
            self._buf.extend(data)
            self._cond.notify_all()

    def close(self) -> None:
        with self._cond:
            self._eof = True
            self._cond.notify_all()

    def abort(self) -> None:
        with self._cond:
            self.aborted = True
            self._eof = True
            self._buf.clear()
            self._cond.notify_all()

    def read(self, num_bytes: int) -> bytes:
        with self._cond:
            while not self._buf and not self._eof:
                self._cond.wait(timeout=0.1)
            if not self._buf:
                return b""
            take = min(num_bytes, len(self._buf))
            out = bytes(self._buf[:take])
            del self._buf[:take]
            self._cond.notify_all()
            return out


def _streamable_source_type():
    import miniaudio

    class _Source(miniaudio.StreamableSource):
        def __init__(self) -> None:
            self._buf = bytearray()
            self._cond = threading.Condition()
            self._eof = False
            self.aborted = False

        def push(self, data: bytes) -> None:
            if not data:
                return
            with self._cond:
                while len(self._buf) > _BUFFER_LIMIT and not self.aborted and not self._eof:
                    self._cond.wait(timeout=0.05)
                if self.aborted or self._eof:
                    return
                self._buf.extend(data)
                self._cond.notify_all()

        def close(self) -> None:
            with self._cond:
                self._eof = True
                self._cond.notify_all()

        def abort(self) -> None:
            with self._cond:
                self.aborted = True
                self._eof = True
                self._buf.clear()
                self._cond.notify_all()

        def read(self, num_bytes: int) -> bytes:
            with self._cond:
                while not self._buf and not self._eof:
                    self._cond.wait(timeout=0.1)
                if not self._buf:
                    return b""
                # Return bytes already on hand. Waiting for num_bytes would
                # hold the first MP3 frames until the whole sentence arrived.
                take = min(num_bytes, len(self._buf))
                out = bytes(self._buf[:take])
                del self._buf[:take]
                self._cond.notify_all()
                return out

    return _Source


class _NullOutput:
    def write(self, pcm: bytes) -> None:
        del pcm

    def close(self) -> None:
        return None


class _SoundDeviceOutput:
    def __init__(self, stream) -> None:
        self._stream = stream

    def write(self, pcm: bytes) -> None:
        self._stream.write(pcm)

    def close(self) -> None:
        self._stream.stop()
        self._stream.close()


class _PyAudioOutput:
    def __init__(self, audio, stream) -> None:
        self._audio = audio
        self._stream = stream

    def write(self, pcm: bytes) -> None:
        self._stream.write(pcm)

    def close(self) -> None:
        self._stream.stop_stream()
        self._stream.close()
        self._audio.terminate()


_output_warned = False


def open_local_output(on_warn: Callable[[str], None]):
    """Open sounddevice, then pyaudio. A missing device does not raise."""
    global _output_warned
    try:
        import sounddevice as sd

        stream = sd.RawOutputStream(
            samplerate=SAMPLE_RATE,
            channels=1,
            dtype="int16",
            latency="low",
        )
        stream.start()
        return _SoundDeviceOutput(stream)
    except Exception as exc:  # noqa: BLE001 - fall through to pyaudio
        sounddevice_error = exc
    try:
        import pyaudio

        audio = pyaudio.PyAudio()
        stream = audio.open(
            format=pyaudio.paInt16,
            channels=1,
            rate=SAMPLE_RATE,
            output=True,
        )
        return _PyAudioOutput(audio, stream)
    except Exception as exc:  # noqa: BLE001 - keep the node alive without a speaker
        if not _output_warned:
            _output_warned = True
            on_warn(
                "Local audio output is unavailable. "
                f"sounddevice: {sounddevice_error}. pyaudio: {exc}. "
                "Speech bytes will be discarded."
            )
        return _NullOutput()


class StreamingSpeaker:
    """Decode MP3 chunks and write PCM as soon as a frame is ready.

    ffmpeg is the decoder. sounddevice or pyaudio only receives PCM.
    A short MP3 prefix is enough for ffmpeg to emit samples, so speech
    starts before the rest of the sentence arrives.
    """

    def __init__(
        self,
        on_warn: Callable[[str], None],
        output_opener: Callable[[], object] | None = None,
    ) -> None:
        self._on_warn = on_warn
        self._output_opener = output_opener
        self._source = None
        self._proc: subprocess.Popen | None = None
        self._thread: threading.Thread | None = None
        self._started = False
        self._aborted = False

    def start(self) -> None:
        if self._started:
            return
        self._started = True
        ffmpeg = shutil.which("ffmpeg")
        if ffmpeg:
            try:
                self._proc = subprocess.Popen(
                    [
                        ffmpeg,
                        "-hide_banner",
                        "-loglevel",
                        "error",
                        "-fflags",
                        "nobuffer",
                        "-flags",
                        "low_delay",
                        "-probesize",
                        "32",
                        "-analyzeduration",
                        "0",
                        "-f",
                        "mp3",
                        "-i",
                        "pipe:0",
                        "-f",
                        "s16le",
                        "-ar",
                        str(SAMPLE_RATE),
                        "-ac",
                        "1",
                        "pipe:1",
                    ],
                    stdin=subprocess.PIPE,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.DEVNULL,
                    bufsize=0,
                )
            except OSError as exc:
                self._on_warn(f"ffmpeg did not start ({exc}). Falling back to miniaudio.")
                self._proc = None
        if self._proc is not None:
            self._thread = threading.Thread(
                target=self._play_ffmpeg_stdout, name="smartbot_voice_play", daemon=True
            )
            self._thread.start()
            return
        try:
            source_type = _streamable_source_type()
        except ImportError as exc:
            self._on_warn(f"No MP3 decoder is available ({exc}). Speech audio was not played.")
            self._source = _PushSource()
            self._thread = threading.Thread(
                target=self._drain, name="smartbot_voice_play", daemon=True
            )
            self._thread.start()
            return
        self._source = source_type()
        self._thread = threading.Thread(
            target=self._decode_and_play, name="smartbot_voice_play", daemon=True
        )
        self._thread.start()

    def submit(self, mp3_chunk: bytes) -> None:
        if not mp3_chunk:
            return
        if not self._started:
            self.start()
        if self._proc is not None and self._proc.stdin is not None:
            try:
                self._proc.stdin.write(mp3_chunk)
                self._proc.stdin.flush()
            except (BrokenPipeError, ValueError, OSError) as exc:
                if not self._aborted:
                    self._on_warn(f"Speech playback failed: {exc}")
            return
        if self._source is not None:
            self._source.push(mp3_chunk)

    def finish(self) -> None:
        if self._proc is not None and self._proc.stdin is not None:
            try:
                self._proc.stdin.close()
            except OSError:
                pass
        if self._source is not None:
            self._source.close()
        if self._thread is not None:
            self._thread.join(timeout=5.0)
            self._thread = None
        if self._proc is not None:
            try:
                self._proc.wait(timeout=1.0)
            except subprocess.TimeoutExpired:
                self._proc.kill()
            self._proc = None

    def abort(self) -> None:
        self._aborted = True
        if self._proc is not None:
            self._proc.kill()
        if self._source is not None and hasattr(self._source, "abort"):
            self._source.abort()
        if self._thread is not None:
            self._thread.join(timeout=1.0)
            self._thread = None

    def _open_output(self):
        if self._output_opener is not None:
            return self._output_opener()
        return open_local_output(self._on_warn)

    def _play_ffmpeg_stdout(self) -> None:
        output = None
        try:
            output = self._open_output()
            assert self._proc is not None and self._proc.stdout is not None
            while not self._aborted:
                pcm = self._proc.stdout.read(4096)
                if not pcm:
                    break
                output.write(pcm)
        except Exception as exc:  # noqa: BLE001 - playback must not kill the node
            if not self._aborted:
                self._on_warn(f"Speech playback failed: {exc}")
        finally:
            if output is not None:
                output.close()

    def _drain(self) -> None:
        assert self._source is not None
        while self._source.read(4096):
            continue

    def _decode_and_play(self) -> None:
        import miniaudio

        output = None
        try:
            output = self._open_output()
            stream = miniaudio.stream_any(
                self._source,
                source_format=miniaudio.FileFormat.MP3,
                output_format=miniaudio.SampleFormat.SIGNED16,
                nchannels=1,
                sample_rate=SAMPLE_RATE,
                frames_to_read=1152,
            )
            for block in stream:
                if self._aborted or getattr(self._source, "aborted", False):
                    break
                pcm = block.tobytes() if hasattr(block, "tobytes") else bytes(block)
                if pcm and output is not None:
                    output.write(pcm)
        except Exception as exc:  # noqa: BLE001 - playback must not kill the node
            if not self._aborted:
                self._on_warn(f"Speech playback failed: {exc}")
        finally:
            if output is not None:
                output.close()


def _redact(message: str, secret: str) -> str:
    if secret and secret in message:
        return message.replace(secret, "[redacted]")
    return message


def _is_timeout(exc: BaseException) -> bool:
    name = type(exc).__name__.lower()
    return isinstance(exc, TimeoutError) or "timeout" in name


def _is_network(exc: BaseException) -> bool:
    name = type(exc).__name__.lower()
    if isinstance(exc, (ConnectionError, TimeoutError)):
        return True
    tokens = ("connect", "network", "protocol", "readerror", "remote", "timeout")
    return any(token in name for token in tokens)


async def _iterate_chunks(stream) -> AsyncIterator[bytes]:
    if inspect.isawaitable(stream):
        stream = await stream
    if hasattr(stream, "__aiter__"):
        async for chunk in stream:
            data = _chunk_bytes(chunk)
            if data:
                yield data
        return
    for chunk in stream:
        data = _chunk_bytes(chunk)
        if data:
            yield data
        await asyncio.sleep(0)


def _chunk_bytes(chunk) -> bytes:
    if isinstance(chunk, bytes):
        return chunk
    if isinstance(chunk, bytearray):
        return bytes(chunk)
    return b""


_END = object()


async def _pull_chunk(iterator: AsyncIterator[bytes]):
    try:
        return await iterator.__anext__()
    except StopAsyncIteration:
        return _END


async def _next_chunk(iterator: AsyncIterator[bytes], timeout_sec: float, stop_event: threading.Event) -> bytes:
    task = asyncio.ensure_future(_pull_chunk(iterator))
    started = time.monotonic()
    try:
        while True:
            if stop_event.is_set():
                task.cancel()
                raise asyncio.CancelledError
            remaining = timeout_sec - (time.monotonic() - started)
            if remaining <= 0.0:
                task.cancel()
                raise TimeoutError("generation timeout waiting for the next audio chunk")
            done, _pending = await asyncio.wait({task}, timeout=min(0.1, remaining))
            if task in done:
                item = task.result()
                if item is _END:
                    raise StopAsyncIteration
                return item
    finally:
        if not task.done():
            task.cancel()


class SpeechEngine:
    """One utterance at a time. The first MP3 chunk is handed to the speaker immediately."""

    def __init__(
        self,
        settings: VoiceSettings,
        on_warn: Callable[[str], None],
        client_factory: Callable[[VoiceSettings], object] | None = None,
        speaker_factory: Callable[[], StreamingSpeaker] | None = None,
    ) -> None:
        self.settings = settings
        self._on_warn = on_warn
        self._client_factory = client_factory or default_client_factory
        self._speaker_factory = speaker_factory or (lambda: StreamingSpeaker(on_warn))
        self._stop = threading.Event()
        self._active: StreamingSpeaker | None = None

    def request_stop(self) -> None:
        self._stop.set()
        if self._active is not None:
            self._active.abort()

    async def speak(self, text: str) -> bool:
        utterance = text.strip()
        if not utterance:
            self._on_warn("Ignored an empty speech request.")
            return False
        if not self.settings.api_key or not self.settings.voice_id:
            self._on_warn(
                "Speech skipped. Set ELEVENLABS_API_KEY and VOICE_ID in the environment "
                "or in the env file. No request was sent."
            )
            return False
        if self._stop.is_set():
            return False
        speaker = self._speaker_factory()
        self._active = speaker
        try:
            client = self._client_factory(self.settings)
            stream = client.text_to_speech.stream(
                voice_id=self.settings.voice_id,
                text=utterance,
                model_id=self.settings.model_id,
                output_format=self.settings.output_format,
                optimize_streaming_latency=self.settings.optimize_streaming_latency,
            )
            speaker.start()
            iterator = _iterate_chunks(stream).__aiter__()
            got_audio = False
            while True:
                try:
                    chunk = await _next_chunk(iterator, self.settings.timeout_sec, self._stop)
                except StopAsyncIteration:
                    break
                except asyncio.CancelledError:
                    return False
                speaker.submit(chunk)
                got_audio = True
            return got_audio
        except Exception as exc:  # noqa: BLE001 - stay up and log the anomaly
            detail = _redact(str(exc), self.settings.api_key)
            if _is_timeout(exc):
                self._on_warn(f"Speech generation timed out: {detail}")
            elif _is_network(exc):
                self._on_warn(f"Speech network drop: {detail}")
            else:
                self._on_warn(f"Speech generation failed: {detail}")
            return False
        finally:
            self._active = None
            speaker.finish()


class SpeechWorker:
    """Background asyncio loop. submit() returns without waiting for audio."""

    def __init__(
        self,
        settings: VoiceSettings,
        on_warn: Callable[[str], None],
        client_factory: Callable[[VoiceSettings], object] | None = None,
        speaker_factory: Callable[[], StreamingSpeaker] | None = None,
    ) -> None:
        self._on_warn = on_warn
        self._engine = SpeechEngine(settings, on_warn, client_factory, speaker_factory)
        self._loop = asyncio.new_event_loop()
        self._queue: asyncio.Queue | None = None
        self._ready = threading.Event()
        self._thread = threading.Thread(target=self._run, name="smartbot_voice", daemon=True)

    def start(self) -> None:
        if self._thread.is_alive():
            return
        self._thread.start()
        self._ready.wait(timeout=2.0)

    def submit(self, text: str) -> None:
        if not self._ready.is_set():
            self._on_warn("Speech worker is not running. Dropped a request.")
            return

        def _put() -> None:
            assert self._queue is not None
            if self._queue.full():
                self._on_warn("Speech queue is full. Dropped a request.")
                return
            self._queue.put_nowait(text)

        self._loop.call_soon_threadsafe(_put)

    def stop(self) -> None:
        self._engine.request_stop()
        if self._ready.is_set() and not self._loop.is_closed():
            self._loop.call_soon_threadsafe(self._enqueue_stop)
        if self._thread.is_alive():
            self._thread.join(timeout=2.0)

    def _enqueue_stop(self) -> None:
        if self._queue is not None:
            self._queue.put_nowait(None)

    def _run(self) -> None:
        asyncio.set_event_loop(self._loop)
        self._queue = asyncio.Queue(maxsize=QUEUE_DEPTH)
        self._ready.set()
        try:
            self._loop.run_until_complete(self._serve())
        finally:
            self._loop.close()

    async def _serve(self) -> None:
        assert self._queue is not None
        while True:
            text = await self._queue.get()
            if text is None:
                return
            try:
                await self._engine.speak(text)
            except Exception as exc:  # noqa: BLE001 - one utterance must not stop the worker
                self._on_warn(f"Speech worker anomaly: {_redact(str(exc), self._engine.settings.api_key)}")
