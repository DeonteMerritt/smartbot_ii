# Visual meshes

Put one DAE file here for each link. The file name is the link name plus `.dae`.

Example: `left_upper_arm_link.dae`

The mesh must be authored in that link's coordinate frame. The frame origin is the proximal joint, not the center of the primitive. Axis directions are commented on the link in `urdf/smartbot_ii.macros.xacro` and `urdf/smartbot_ii.urdf.xacro`. +X is forward, +Y is left, and +Z is up. Arms and legs extend along -Z in the zero pose. The neck extends along +Z. The foot toe points along +X.

Scale is `1 1 1` meters. Do not export in millimeters unless you change the mesh scale in the Xacro.

Until these files exist, launch with `use_meshes:=false`. The primitive geometry remains the visual.

Link names:

- pelvis_link
- torso_link
- neck_link
- head_link
- left_shoulder_link
- left_upper_arm_link
- left_forearm_link
- left_wrist_link
- left_hand_link
- right_shoulder_link
- right_upper_arm_link
- right_forearm_link
- right_wrist_link
- right_hand_link
- left_hip_link
- left_hip_roll_link
- left_thigh_link
- left_lower_leg_link
- left_ankle_link
- left_foot_link
- right_hip_link
- right_hip_roll_link
- right_thigh_link
- right_lower_leg_link
- right_ankle_link
- right_foot_link
