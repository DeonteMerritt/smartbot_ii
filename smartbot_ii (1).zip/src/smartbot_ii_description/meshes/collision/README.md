# Collision meshes

Put one STL file here for each link. The file name is the link name plus `.stl`.

Example: `left_thigh_link.stl`

Use the same link frame as the visual mesh: origin at the proximal joint, +X forward, +Y left, +Z up, units in meters. Prefer a coarse convex or simple mesh. A detailed visual DAE is a poor collision mesh.

Until these files exist, launch with `use_collision_meshes:=false`. The primitive collision geometry remains active.

The link list is the same as `meshes/visual/README.md`.
