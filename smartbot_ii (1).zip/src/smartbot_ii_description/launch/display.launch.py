"""RViz preview of SmartBot II. This does not start controllers or Gazebo."""

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, LogInfo
from launch.conditions import IfCondition, UnlessCondition
from launch.substitutions import (
    Command,
    FindExecutable,
    LaunchConfiguration,
    PathJoinSubstitution,
)
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    description_share = FindPackageShare("smartbot_ii_description")
    xacro_file = PathJoinSubstitution(
        [description_share, "urdf", "smartbot_ii.urdf.xacro"]
    )
    rviz_config = PathJoinSubstitution(
        [description_share, "rviz", "smartbot_ii.rviz"]
    )
    robot_description = Command(
        [
            FindExecutable(name="xacro"),
            " ",
            xacro_file,
            " use_ros2_control:=false",
            " use_gazebo:=false",
            " fix_pelvis_to_world:=false",
            " use_meshes:=",
            LaunchConfiguration("use_meshes"),
            " use_collision_meshes:=",
            LaunchConfiguration("use_collision_meshes"),
        ]
    )
    description_parameter = {"robot_description": robot_description}

    return LaunchDescription(
        [
            DeclareLaunchArgument(
                "gui",
                default_value="true",
                description="Start joint_state_publisher_gui instead of joint_state_publisher.",
            ),
            DeclareLaunchArgument(
                "rviz",
                default_value="true",
                description="Start RViz2 with the SmartBot II display.",
            ),
            DeclareLaunchArgument(
                "use_meshes",
                default_value="false",
                description="Use DAE visuals. Keep false until meshes are installed.",
            ),
            DeclareLaunchArgument(
                "use_collision_meshes",
                default_value="false",
                description="Use STL collisions. Keep false until meshes are installed.",
            ),
            LogInfo(
                msg=(
                    "SmartBot II RViz display is a kinematic preview. "
                    "It does not validate walking, balance, or physical motors."
                )
            ),
            Node(
                package="robot_state_publisher",
                executable="robot_state_publisher",
                output="screen",
                parameters=[description_parameter, {"use_sim_time": False}],
            ),
            Node(
                package="joint_state_publisher_gui",
                executable="joint_state_publisher_gui",
                condition=IfCondition(LaunchConfiguration("gui")),
                parameters=[description_parameter],
            ),
            Node(
                package="joint_state_publisher",
                executable="joint_state_publisher",
                condition=UnlessCondition(LaunchConfiguration("gui")),
                parameters=[description_parameter],
            ),
            Node(
                package="rviz2",
                executable="rviz2",
                name="rviz2",
                arguments=["-d", rviz_config],
                condition=IfCondition(LaunchConfiguration("rviz")),
                output="screen",
            ),
        ]
    )
