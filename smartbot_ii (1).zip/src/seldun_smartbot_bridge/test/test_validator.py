"""Unit tests for Seldun command validation. No ROS dependency."""

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from seldun_smartbot_bridge.validator import (  # noqa: E402
    PHYSICAL_ACK_TOKEN,
    JointLimit,
    SafetyPolicy,
    SeldunCommandData,
    assess_hardware_mode,
    command_from_mapping,
    load_policy,
    select_joint_transport,
    twist_timeout_expired,
    validate_command,
)

SRC = Path(__file__).resolve().parents[2]
SAFETY = SRC / "smartbot_ii_description" / "config" / "safety_limits.yaml"


def _policy() -> SafetyPolicy:
    neck = JointLimit("neck_yaw_joint", -0.9, 0.9, 1.0, 4.0)
    knee = JointLimit("left_knee_joint", 0.0, 1.8, 1.0, 32.0)
    return SafetyPolicy(
        joints={neck.name: neck, knee.name: knee},
        max_position_delta_rad=0.35,
        max_trajectory_duration_sec=10.0,
        command_timeout_sec=1.0,
        cmd_vel_linear_x_max=0.15,
        cmd_vel_linear_y_max=0.05,
        cmd_vel_linear_z_max=0.0,
        cmd_vel_angular_x_max=0.0,
        cmd_vel_angular_y_max=0.0,
        cmd_vel_angular_z_max=0.30,
        physical_ack_token=PHYSICAL_ACK_TOKEN,
    )


def _sim():
    return assess_hardware_mode("simulation", False, "")


def _trajectory(**overrides) -> SeldunCommandData:
    data = dict(
        command_id="cmd-1",
        command_type="joint_trajectory",
        joint_names=["neck_yaw_joint"],
        positions=[0.15],
        velocities=[0.1],
        efforts=[0.5],
        time_from_start_sec=2.0,
    )
    data.update(overrides)
    return SeldunCommandData(**data)


class ValidatorTest(unittest.TestCase):
    def test_safe_neck_command_is_accepted_from_zero(self):
        result = validate_command(
            _trajectory(), _policy(), hardware=_sim(), software_estop_latched=False, measured_positions=None
        )
        self.assertTrue(result.accepted)
        self.assertEqual(result.error_code, "OK")

    def test_unknown_joint_is_rejected(self):
        result = validate_command(
            _trajectory(joint_names=["not_a_joint"], positions=[0.1], velocities=[], efforts=[]),
            _policy(),
            hardware=_sim(),
            software_estop_latched=False,
            measured_positions=None,
        )
        self.assertFalse(result.accepted)
        self.assertEqual(result.error_code, "UNKNOWN_JOINT")
        self.assertIn("not_a_joint", result.message)

    def test_position_limit_is_rejected(self):
        result = validate_command(
            _trajectory(positions=[1.2], velocities=[], efforts=[]),
            _policy(),
            hardware=_sim(),
            software_estop_latched=False,
            measured_positions=None,
        )
        self.assertEqual(result.error_code, "POSITION_LIMIT")
        self.assertIn("neck_yaw_joint", result.message)

    def test_position_on_the_limit_is_accepted_when_delta_allows(self):
        policy = _policy()
        wide = SafetyPolicy(**{**policy.__dict__, "max_position_delta_rad": 1.0})
        result = validate_command(
            _trajectory(positions=[0.9], velocities=[], efforts=[]),
            wide,
            hardware=_sim(),
            software_estop_latched=False,
            measured_positions=None,
        )
        self.assertTrue(result.accepted)

    def test_velocity_limit_is_rejected(self):
        result = validate_command(
            _trajectory(velocities=[5.0]),
            _policy(),
            hardware=_sim(),
            software_estop_latched=False,
            measured_positions=None,
        )
        self.assertEqual(result.error_code, "VELOCITY_LIMIT")

    def test_effort_limit_is_rejected(self):
        result = validate_command(
            _trajectory(efforts=[20.0]),
            _policy(),
            hardware=_sim(),
            software_estop_latched=False,
            measured_positions=None,
        )
        self.assertEqual(result.error_code, "EFFORT_LIMIT")

    def test_negative_velocity_inside_cap_is_accepted(self):
        result = validate_command(
            _trajectory(positions=[-0.1], velocities=[-0.2]),
            _policy(),
            hardware=_sim(),
            software_estop_latched=False,
            measured_positions=None,
        )
        self.assertTrue(result.accepted)

    def test_length_mismatch_is_rejected(self):
        result = validate_command(
            _trajectory(positions=[0.1, 0.2], velocities=[], efforts=[]),
            _policy(),
            hardware=_sim(),
            software_estop_latched=False,
            measured_positions=None,
        )
        self.assertEqual(result.error_code, "LENGTH_MISMATCH")

    def test_duplicate_joint_is_rejected(self):
        result = validate_command(
            _trajectory(
                joint_names=["neck_yaw_joint", "neck_yaw_joint"],
                positions=[0.1, 0.1],
                velocities=[],
                efforts=[],
            ),
            _policy(),
            hardware=_sim(),
            software_estop_latched=False,
            measured_positions=None,
        )
        self.assertEqual(result.error_code, "DUPLICATE_JOINT")

    def test_non_finite_mapping_is_rejected(self):
        parsed = command_from_mapping(
            {
                "command_id": "bad",
                "command_type": "joint_trajectory",
                "joint_names": ["neck_yaw_joint"],
                "positions": [float("nan")],
                "time_from_start_sec": 1.0,
            }
        )
        self.assertFalse(parsed.accepted)
        self.assertEqual(parsed.error_code, "NON_FINITE_VALUE")

    def test_empty_command_id_is_rejected(self):
        result = validate_command(
            _trajectory(command_id="  "),
            _policy(),
            hardware=_sim(),
            software_estop_latched=False,
            measured_positions=None,
        )
        self.assertEqual(result.error_code, "EMPTY_COMMAND_ID")

    def test_unknown_command_type_is_rejected(self):
        result = validate_command(
            _trajectory(command_type="walk"),
            _policy(),
            hardware=_sim(),
            software_estop_latched=False,
            measured_positions=None,
        )
        self.assertEqual(result.error_code, "UNKNOWN_COMMAND_TYPE")

    def test_position_delta_from_zero_is_rejected(self):
        result = validate_command(
            _trajectory(positions=[0.5], velocities=[], efforts=[]),
            _policy(),
            hardware=_sim(),
            software_estop_latched=False,
            measured_positions=None,
        )
        self.assertEqual(result.error_code, "POSITION_DELTA")

    def test_position_delta_uses_measured_state(self):
        result = validate_command(
            _trajectory(positions=[0.5], velocities=[], efforts=[]),
            _policy(),
            hardware=_sim(),
            software_estop_latched=False,
            measured_positions={"neck_yaw_joint": 0.4},
        )
        self.assertTrue(result.accepted)

    def test_missing_measured_joint_is_rejected(self):
        result = validate_command(
            _trajectory(),
            _policy(),
            hardware=_sim(),
            software_estop_latched=False,
            measured_positions={"left_knee_joint": 0.2},
        )
        self.assertEqual(result.error_code, "MISSING_JOINT_STATE")

    def test_knee_hyperextension_is_rejected(self):
        result = validate_command(
            _trajectory(
                joint_names=["left_knee_joint"],
                positions=[-0.1],
                velocities=[],
                efforts=[],
            ),
            _policy(),
            hardware=_sim(),
            software_estop_latched=False,
            measured_positions=None,
        )
        self.assertEqual(result.error_code, "POSITION_LIMIT")

    def test_time_rules(self):
        zero_time = validate_command(
            _trajectory(time_from_start_sec=0.0, velocities=[], efforts=[]),
            _policy(),
            hardware=_sim(),
            software_estop_latched=False,
            measured_positions=None,
        )
        self.assertEqual(zero_time.error_code, "TIME_NON_POSITIVE")
        long_time = validate_command(
            _trajectory(time_from_start_sec=30.0, velocities=[], efforts=[]),
            _policy(),
            hardware=_sim(),
            software_estop_latched=False,
            measured_positions=None,
        )
        self.assertEqual(long_time.error_code, "TIME_LIMIT")

    def test_mixed_twist_on_trajectory_is_rejected(self):
        result = validate_command(
            _trajectory(linear_x=0.1),
            _policy(),
            hardware=_sim(),
            software_estop_latched=False,
            measured_positions=None,
        )
        self.assertEqual(result.error_code, "MALFORMED")

    def test_cmd_vel_caps_and_vertical_rejection(self):
        ok = validate_command(
            SeldunCommandData("vel-1", "cmd_vel", linear_x=0.1, angular_z=0.2),
            _policy(),
            hardware=_sim(),
            software_estop_latched=False,
            measured_positions=None,
        )
        self.assertTrue(ok.accepted)
        self.assertIn("will not walk", ok.message)
        bad = validate_command(
            SeldunCommandData("vel-2", "cmd_vel", linear_z=0.01),
            _policy(),
            hardware=_sim(),
            software_estop_latched=False,
            measured_positions=None,
        )
        self.assertEqual(bad.error_code, "CMD_VEL_LIMIT")

    def test_cmd_vel_with_joints_is_rejected(self):
        result = validate_command(
            SeldunCommandData(
                "vel-3",
                "cmd_vel",
                joint_names=["neck_yaw_joint"],
                linear_x=0.05,
            ),
            _policy(),
            hardware=_sim(),
            software_estop_latched=False,
            measured_positions=None,
        )
        self.assertEqual(result.error_code, "MALFORMED")

    def test_estop_rejects_motion_until_reset(self):
        stopped = validate_command(
            _trajectory(),
            _policy(),
            hardware=_sim(),
            software_estop_latched=True,
            measured_positions=None,
        )
        self.assertEqual(stopped.error_code, "SOFTWARE_ESTOP")
        stop = validate_command(
            SeldunCommandData("stop-1", "stop"),
            _policy(),
            hardware=_sim(),
            software_estop_latched=False,
            measured_positions=None,
        )
        self.assertTrue(stop.accepted)
        self.assertIn("not a hardware emergency stop", stop.message)
        reset = validate_command(
            SeldunCommandData("reset-1", "reset_stop"),
            _policy(),
            hardware=_sim(),
            software_estop_latched=True,
            measured_positions=None,
        )
        self.assertTrue(reset.accepted)

    def test_simulation_is_the_default_unlocked_mode(self):
        assessment = assess_hardware_mode("simulation", False, "")
        self.assertEqual(assessment.mode, "simulation")
        self.assertTrue(assessment.motion_allowed)

    def test_physical_mode_is_locked_without_explicit_ack(self):
        missing = assess_hardware_mode("physical", False, "")
        self.assertFalse(missing.motion_allowed)
        self.assertEqual(missing.error_code, "PHYSICAL_MODE_LOCKED")
        wrong = assess_hardware_mode("physical", True, "yes")
        self.assertFalse(wrong.motion_allowed)
        unlocked = assess_hardware_mode("physical", True, PHYSICAL_ACK_TOKEN)
        self.assertTrue(unlocked.motion_allowed)
        self.assertIn("NOT validated", unlocked.message)

    def test_physical_lock_rejects_motion_and_reset_but_accepts_stop(self):
        locked = assess_hardware_mode("physical", False, "")
        motion = validate_command(
            _trajectory(),
            _policy(),
            hardware=locked,
            software_estop_latched=False,
            measured_positions=None,
        )
        self.assertEqual(motion.error_code, "PHYSICAL_MODE_LOCKED")
        reset = validate_command(
            SeldunCommandData("reset-locked", "reset_stop"),
            _policy(),
            hardware=locked,
            software_estop_latched=True,
            measured_positions=None,
        )
        self.assertEqual(reset.error_code, "PHYSICAL_MODE_LOCKED")
        stop = validate_command(
            SeldunCommandData("stop-locked", "stop"),
            _policy(),
            hardware=locked,
            software_estop_latched=False,
            measured_positions=None,
        )
        self.assertTrue(stop.accepted)

    def test_unknown_hardware_mode_is_rejected(self):
        assessment = assess_hardware_mode("Physical", False, "")
        self.assertEqual(assessment.error_code, "HARDWARE_MODE_REJECTED")
        self.assertFalse(assessment.motion_allowed)

    def test_transport_selection_does_not_send_both(self):
        code, _message, transport = select_joint_transport("action", True)
        self.assertEqual((code, transport), ("OK", "action"))
        code, message, transport = select_joint_transport("action", False)
        self.assertEqual(code, "CONTROLLER_UNAVAILABLE")
        self.assertEqual(transport, "")
        self.assertIn("No joint command was sent", message)
        code, _message, transport = select_joint_transport("topic", False)
        self.assertEqual(transport, "topic")
        code, _message, transport = select_joint_transport("both", True)
        self.assertEqual(code, "MALFORMED")

    def test_cmd_vel_timeout_helper(self):
        self.assertFalse(twist_timeout_expired(None, 10.0, 1.0, True))
        self.assertFalse(twist_timeout_expired(9.5, 10.0, 1.0, True))
        self.assertTrue(twist_timeout_expired(8.0, 10.0, 1.0, True))
        self.assertFalse(twist_timeout_expired(8.0, 10.0, 1.0, False))

    def test_shipped_safety_file_loads_and_accepts_the_documented_neck_test(self):
        policy = load_policy(SAFETY)
        self.assertEqual(policy.physical_ack_token, PHYSICAL_ACK_TOKEN)
        result = validate_command(
            _trajectory(),
            policy,
            hardware=_sim(),
            software_estop_latched=False,
            measured_positions=None,
        )
        self.assertTrue(result.accepted, result.message)
        unknown = validate_command(
            _trajectory(joint_names=["not_a_joint"], positions=[0.1], velocities=[], efforts=[]),
            policy,
            hardware=_sim(),
            software_estop_latched=False,
            measured_positions=None,
        )
        self.assertEqual(unknown.error_code, "UNKNOWN_JOINT")


if __name__ == "__main__":
    unittest.main()
