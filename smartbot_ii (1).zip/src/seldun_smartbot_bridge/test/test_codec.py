"""Unit tests for Seldun message translation. No ROS dependency."""

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from seldun_smartbot_bridge.codec import (  # noqa: E402
    build_follow_joint_trajectory_goal,
    build_joint_trajectory,
    build_twist,
    split_duration,
    zero_twist,
)
from seldun_smartbot_bridge.validator import SeldunCommandData  # noqa: E402


class CodecTest(unittest.TestCase):
    def test_duration_split(self):
        self.assertEqual(split_duration(2.0), (2, 0))
        self.assertEqual(split_duration(2.5), (2, 500_000_000))
        with self.assertRaises(ValueError):
            split_duration(-0.1)

    def test_trajectory_omits_empty_optional_arrays(self):
        cmd = SeldunCommandData(
            "id",
            "joint_trajectory",
            joint_names=["neck_yaw_joint"],
            positions=[0.15],
            time_from_start_sec=2.0,
        )
        trajectory = build_joint_trajectory(cmd)
        point = trajectory["points"][0]
        self.assertEqual(trajectory["joint_names"], ["neck_yaw_joint"])
        self.assertEqual(point["positions"], [0.15])
        self.assertNotIn("velocities", point)
        self.assertNotIn("effort", point)
        self.assertEqual(point["time_from_start_sec"], 2)

    def test_trajectory_maps_efforts_to_the_ros_field_name(self):
        cmd = SeldunCommandData(
            "id",
            "joint_trajectory",
            joint_names=["neck_yaw_joint"],
            positions=[0.1],
            velocities=[0.2],
            efforts=[0.3],
            time_from_start_sec=1.25,
        )
        point = build_joint_trajectory(cmd)["points"][0]
        self.assertEqual(point["velocities"], [0.2])
        self.assertEqual(point["effort"], [0.3])
        self.assertEqual(point["time_from_start_nanosec"], 250_000_000)

    def test_action_goal_wraps_the_same_trajectory(self):
        cmd = SeldunCommandData(
            "id",
            "joint_trajectory",
            joint_names=["neck_yaw_joint"],
            positions=[0.15],
            time_from_start_sec=2.0,
        )
        goal = build_follow_joint_trajectory_goal(cmd)
        self.assertEqual(goal["trajectory"]["joint_names"], ["neck_yaw_joint"])
        self.assertEqual(goal["goal_time_tolerance_sec"], 1)

    def test_twist_and_zero(self):
        cmd = SeldunCommandData("id", "cmd_vel", linear_x=0.1, angular_z=-0.2)
        twist = build_twist(cmd)
        self.assertEqual(twist["linear"]["x"], 0.1)
        self.assertEqual(twist["angular"]["z"], -0.2)
        self.assertEqual(zero_twist()["linear"], {"x": 0.0, "y": 0.0, "z": 0.0})


if __name__ == "__main__":
    unittest.main()
