"""Limb-bus parser tests. No ROS dependency and no socket is opened."""

import ast
import math
import struct
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from seldun_smartbot_bridge.bus_telemetry import (  # noqa: E402
    FLAG_ENCODER,
    FLAG_HEARTBEAT,
    FLAG_OVERCURRENT,
    FLAG_OVERTEMPERATURE,
    STATUS_ID_BASE,
    BusFrame,
    LimbBusReceiver,
    encode_serial_record,
    measured_from_positions,
    parse_status_frame,
    status_id,
)
from seldun_smartbot_bridge.validator import ACTUATED_JOINTS  # noqa: E402


def _status(node_id: int, position: float, velocity: float, temperature: int, flags: int) -> BusFrame:
    data = struct.pack("<f", position)
    data += struct.pack("<h", int(round(velocity / 0.001)))
    data += struct.pack("<b", temperature)
    data += bytes((flags & 0xFF,))
    return BusFrame(status_id(node_id), data)


def _legacy(node_id: int, position: float, code: int) -> BusFrame:
    return BusFrame(status_id(node_id), struct.pack("<f", position) + bytes((code, 0)))


class _Bridge:
    def __init__(self) -> None:
        self._measured = None
        self._software_estop = False
        self.alerts: list[tuple[str, tuple[str, ...]]] = []

    def apply_measured_positions(self, positions: dict[str, float]) -> None:
        self._measured = measured_from_positions(positions)

    def latch_hardware_alert(self, joint_name: str, alert_names: tuple[str, ...], sample) -> None:
        del sample
        self._software_estop = True
        self.alerts.append((joint_name, alert_names))


class BusTelemetryTest(unittest.TestCase):
    def test_dlc8_decodes_position_velocity_and_temperature(self):
        sample = parse_status_frame(_status(1, 0.25, -1.5, 42, 0))
        self.assertIsNotNone(sample)
        assert sample is not None
        self.assertEqual(sample.joint_name, "neck_yaw_joint")
        self.assertEqual(sample.node_id, 1)
        self.assertAlmostEqual(sample.position_rad, 0.25, places=5)
        self.assertAlmostEqual(sample.velocity_rad_s, -1.5, places=3)
        self.assertEqual(sample.temperature_c, 42.0)
        self.assertEqual(sample.alert_names, ())

    def test_node_22_is_the_last_actuated_joint(self):
        sample = parse_status_frame(_status(22, -0.1, 0.0, -128, 0))
        assert sample is not None
        self.assertEqual(sample.joint_name, "right_ankle_roll_joint")
        self.assertIsNone(sample.temperature_c)

    def test_unknown_id_and_non_finite_position_are_ignored(self):
        self.assertIsNone(parse_status_frame(BusFrame(0x201, struct.pack("<f", 0.1))))
        self.assertIsNone(parse_status_frame(BusFrame(STATUS_ID_BASE, b"\x00" * 8)))
        self.assertIsNone(parse_status_frame(BusFrame(STATUS_ID_BASE + 23, b"\x00" * 8)))
        self.assertIsNone(parse_status_frame(_status(1, math.nan, 0.0, 20, 0)))

    def test_legacy_dlc6_maps_encoder_and_ignores_disarmed(self):
        encoder = parse_status_frame(_legacy(2, 0.4, 3))
        assert encoder is not None
        self.assertEqual(encoder.joint_name, "neck_pitch_joint")
        self.assertIsNone(encoder.velocity_rad_s)
        self.assertEqual(encoder.alert_names, ("encoder",))
        disarmed = parse_status_frame(_legacy(2, 0.4, 5))
        assert disarmed is not None
        self.assertEqual(disarmed.alert_names, ())
        healthy = parse_status_frame(_legacy(2, 0.4, 0))
        assert healthy is not None
        self.assertEqual(healthy.alert_names, ())

    def test_measured_dictionary_requires_the_22_joint_names(self):
        positions = {name: float(index) * 0.01 for index, name in enumerate(ACTUATED_JOINTS)}
        measured = measured_from_positions(positions)
        self.assertEqual(tuple(measured), ACTUATED_JOINTS)
        with self.assertRaises(ValueError):
            measured_from_positions({name: 0.0 for name in ACTUATED_JOINTS[:-1]})
        extra = dict(positions)
        extra["not_a_joint"] = 0.0
        with self.assertRaises(ValueError):
            measured_from_positions(extra)
        bad = dict(positions)
        bad["neck_yaw_joint"] = math.nan
        with self.assertRaises(ValueError):
            measured_from_positions(bad)

    def test_complete_set_feeds_the_bridge_and_a_partial_set_does_not(self):
        bridge = _Bridge()
        receiver = LimbBusReceiver(transport="mock", bridge=bridge)
        receiver.inject_frame(_status(1, 0.2, 0.0, 30, 0))
        self.assertIsNone(bridge._measured)
        self.assertTrue(math.isnan(receiver.position_vector()[1]))
        self.assertAlmostEqual(receiver.velocity_vector()[0], 0.0, places=3)
        for index, name in enumerate(ACTUATED_JOINTS):
            del name
            receiver.inject_frame(_status(index + 1, 0.01 * index, 0.0, 25, 0))
        self.assertIsNotNone(bridge._measured)
        assert bridge._measured is not None
        self.assertEqual(tuple(bridge._measured), ACTUATED_JOINTS)
        self.assertAlmostEqual(bridge._measured["neck_yaw_joint"], 0.0)
        self.assertAlmostEqual(bridge._measured["right_ankle_roll_joint"], 0.21)
        receiver.stop()

    def test_fault_flags_alert_once_until_the_latch_is_rearmed(self):
        cases = (
            (FLAG_ENCODER, ("encoder",)),
            (FLAG_OVERCURRENT, ("overcurrent",)),
            (FLAG_OVERTEMPERATURE, ("overtemperature",)),
            (FLAG_HEARTBEAT, ("heartbeat_timeout",)),
        )
        for flags, names in cases:
            bridge = _Bridge()
            receiver = LimbBusReceiver(transport="mock", bridge=bridge)
            frame = _status(3, 0.5, 0.1, 40, flags)
            receiver.inject_frame(frame)
            receiver.inject_frame(frame)
            self.assertEqual(bridge.alerts, [("left_shoulder_pitch_joint", names)])
            self.assertTrue(bridge._software_estop)
            receiver.rearm_fault_latch()
            receiver.inject_frame(frame)
            self.assertEqual(len(bridge.alerts), 2)
            receiver.stop()

    def test_temperature_at_the_threshold_alerts_without_the_flag_bit(self):
        bridge = _Bridge()
        receiver = LimbBusReceiver(transport="mock", bridge=bridge)
        frame = _status(5, 0.0, 0.0, 80, 0)
        receiver.inject_frame(frame)
        receiver.inject_frame(frame)
        self.assertEqual(bridge.alerts, [("left_elbow_joint", ("overtemperature",))])
        receiver.stop()

    def test_serial_record_round_trip(self):
        bridge = _Bridge()
        receiver = LimbBusReceiver(transport="mock", bridge=bridge)
        frame = _status(22, 0.33, 0.25, 18, FLAG_ENCODER)
        sample = receiver.push_serial_record(encode_serial_record(frame))
        assert sample is not None
        self.assertEqual(sample.joint_name, "right_ankle_roll_joint")
        self.assertAlmostEqual(sample.position_rad, 0.33, places=5)
        self.assertEqual(sample.alert_names, ("encoder",))
        broken = bytearray(encode_serial_record(frame))
        broken[-1] ^= 0xFF
        with self.assertRaises(ValueError):
            receiver.push_serial_record(bytes(broken))
        receiver.stop()

    def test_bridge_node_wires_the_receiver_into_measured_and_the_alert_topic(self):
        path = Path(__file__).resolve().parents[1] / "seldun_smartbot_bridge" / "bridge_node.py"
        tree = ast.parse(path.read_text(encoding="utf-8"))
        imported = False
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom) and node.module == "seldun_smartbot_bridge.bus_telemetry":
                names = {alias.name for alias in node.names}
                imported = {"LimbBusReceiver", "measured_from_positions"} <= names
        self.assertTrue(imported)
        text = path.read_text(encoding="utf-8")
        self.assertIn("def apply_measured_positions", text)
        self.assertIn("self._measured = updated", text)
        self.assertIn("def latch_hardware_alert", text)
        self.assertIn("smartbot/system_alert", text)
        self.assertIn("self._software_estop = True", text)


if __name__ == "__main__":
    unittest.main()
