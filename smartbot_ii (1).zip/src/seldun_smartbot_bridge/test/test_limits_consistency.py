"""Cross-check simulated limits, geometry, controllers, and the SRDF."""

import re
import sys
import unittest
from pathlib import Path

import yaml


def _workspace_root() -> Path:
    here = Path(__file__).resolve()
    for parent in here.parents:
        candidate = parent / "src" / "smartbot_ii_description" / "config" / "safety_limits.yaml"
        if candidate.exists():
            return parent
    raise RuntimeError("SmartBot II workspace root was not found from the test file.")


ROOT = _workspace_root()
sys.path.insert(0, str(ROOT / "src" / "seldun_smartbot_bridge"))

from seldun_smartbot_bridge.validator import (  # noqa: E402
    ACTUATED_JOINTS,
    PHYSICAL_ACK_TOKEN,
    load_policy,
)

DESC = ROOT / "src" / "smartbot_ii_description"
CONTROL = ROOT / "src" / "smartbot_ii_control"
PROP_RE = re.compile(r'<xacro:property\s+name="([^"]+)"\s+value="([^"]+)"\s*/>')
SPAWN_RE = re.compile(r"FREE_STANDING_SPAWN_Z = ([0-9.]+)")


def _properties(*relative_paths: str) -> dict[str, float]:
    values = {}
    for relative in relative_paths:
        text = (DESC / relative).read_text(encoding="utf-8")
        for name, raw in PROP_RE.findall(text):
            if name == "pi":
                continue
            values[name] = float(raw)
    return values


class LimitConsistencyTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.props = _properties(
            "urdf/smartbot_ii.constants.xacro",
            "urdf/smartbot_ii.limits.xacro",
            "urdf/smartbot_ii.gazebo.xacro",
        )
        cls.joint_limits = yaml.safe_load(
            (DESC / "config/joint_limits.yaml").read_text(encoding="utf-8")
        )["joint_limits"]
        cls.catalog = yaml.safe_load(
            (DESC / "config/simulated_parameters.yaml").read_text(encoding="utf-8")
        )
        cls.policy = load_policy(DESC / "config/safety_limits.yaml")
        cls.controllers = yaml.safe_load(
            (CONTROL / "config/ros2_controllers.yaml").read_text(encoding="utf-8")
        )
        cls.description = "\n".join(
            path.read_text(encoding="utf-8") for path in (DESC / "urdf").glob("*.xacro")
        )
        cls.srdf = (DESC / "srdf/smartbot_ii.srdf").read_text(encoding="utf-8")

    def test_every_actuated_joint_is_in_the_model_and_limits(self):
        self.assertEqual(set(self.joint_limits), set(ACTUATED_JOINTS))
        self.assertEqual(set(self.policy.joints), set(ACTUATED_JOINTS))
        for name in ACTUATED_JOINTS:
            self.assertIn(f'name="{name}"', self.description)

    def test_urdf_yaml_and_xacro_limits_match(self):
        for name in ACTUATED_JOINTS:
            stem = name.removesuffix("_joint")
            entry = self.joint_limits[name]
            self.assertAlmostEqual(entry["min_position"], self.props[f"{stem}_lower"])
            self.assertAlmostEqual(entry["max_position"], self.props[f"{stem}_upper"])
            self.assertAlmostEqual(entry["max_velocity"], self.props[f"{stem}_velocity"])
            self.assertAlmostEqual(entry["max_effort"], self.props[f"{stem}_effort"])
            self.assertGreater(self.props[f"{stem}_damping"], 0.0)
            self.assertGreater(self.props[f"{stem}_friction"], 0.0)
            self.assertTrue(entry["has_position_limits"])
            self.assertTrue(entry["has_velocity_limits"])
            self.assertTrue(entry["has_acceleration_limits"])
            self.assertTrue(entry["has_effort_limits"])
            self.assertGreater(entry["max_acceleration"], 0.0)

    def test_safety_limits_are_inside_urdf_limits_and_include_zero(self):
        for name in ACTUATED_JOINTS:
            urdf = self.joint_limits[name]
            safety = self.policy.joints[name]
            self.assertGreaterEqual(safety.min_position, urdf["min_position"] - 1e-9)
            self.assertLessEqual(safety.max_position, urdf["max_position"] + 1e-9)
            self.assertLess(
                safety.max_position - safety.min_position,
                urdf["max_position"] - urdf["min_position"] - 1e-6,
            )
            self.assertLessEqual(safety.max_velocity, urdf["max_velocity"])
            self.assertLessEqual(safety.max_effort, urdf["max_effort"])
            self.assertLessEqual(safety.min_position, 0.0 + 1e-9)
            self.assertGreaterEqual(safety.max_position, 0.0 - 1e-9)
            self.assertLessEqual(urdf["min_position"], 0.0 + 1e-9)
            self.assertGreaterEqual(urdf["max_position"], 0.0 - 1e-9)

    def test_left_and_right_limits_match_except_mirrored_rolls(self):
        shared = [
            "shoulder_pitch",
            "elbow",
            "wrist",
            "hip_yaw",
            "hip_pitch",
            "knee",
            "ankle_pitch",
            "ankle_roll",
        ]
        for stem in shared:
            for field in ("lower", "upper", "velocity", "effort", "damping", "friction"):
                self.assertAlmostEqual(
                    self.props[f"left_{stem}_{field}"],
                    self.props[f"right_{stem}_{field}"],
                )
        for stem in ("shoulder_roll", "hip_roll"):
            self.assertAlmostEqual(
                self.props[f"left_{stem}_lower"], -self.props[f"right_{stem}_upper"]
            )
            self.assertAlmostEqual(
                self.props[f"left_{stem}_upper"], -self.props[f"right_{stem}_lower"]
            )

    def test_catalog_marks_every_simulated_xacro_value(self):
        parameters = self.catalog["parameters"]
        self.assertEqual(set(parameters), set(self.props))
        for name, value in self.props.items():
            entry = parameters[name]
            self.assertAlmostEqual(float(entry["value"]), value)
            self.assertIn(entry["replace_with_physical_measurement"], (True, False))
            self.assertTrue(entry["unit"])
            self.assertTrue(entry["notes"])
        for name in (
            "mass_pelvis",
            "thigh_length",
            "neck_yaw_lower",
            "mechanical_reduction",
            "left_knee_effort",
        ):
            self.assertTrue(parameters[name]["replace_with_physical_measurement"])
        for name in ("position_proportional_gain", "ground_clearance", "foot_kp"):
            self.assertFalse(parameters[name]["replace_with_physical_measurement"])

    def test_pelvis_height_matches_the_leg_stack_and_the_gazebo_spawn(self):
        stacked = (
            abs(self.props["hip_z_offset"])
            + self.props["hip_length"]
            + self.props["hip_roll_drop"]
            + self.props["thigh_length"]
            + self.props["shank_length"]
            + self.props["ankle_length"]
            + self.props["foot_z"]
            + self.props["ground_clearance"]
        )
        self.assertAlmostEqual(stacked, self.props["pelvis_height_above_ground"])
        launch = (
            ROOT / "src/smartbot_ii_gazebo/launch/simulation.launch.py"
        ).read_text(encoding="utf-8")
        found = float(SPAWN_RE.search(launch).group(1))
        self.assertAlmostEqual(found, self.props["pelvis_height_above_ground"])

    def test_simulated_mass_is_the_sum_of_the_link_masses(self):
        single = ("pelvis", "torso", "neck", "head")
        paired = (
            "shoulder",
            "upper_arm",
            "forearm",
            "wrist",
            "hand",
            "hip",
            "hip_roll",
            "thigh",
            "shank",
            "ankle",
            "foot",
        )
        total = sum(self.props[f"mass_{name}"] for name in single)
        total += 2.0 * sum(self.props[f"mass_{name}"] for name in paired)
        self.assertAlmostEqual(total, 47.5)

    def test_controllers_partition_the_actuated_joints(self):
        whole = self.controllers["smartbot_joint_trajectory_controller"]["ros__parameters"]["joints"]
        self.assertEqual(whole, list(ACTUATED_JOINTS))
        groups = [
            "head_controller",
            "left_arm_controller",
            "right_arm_controller",
            "left_leg_controller",
            "right_leg_controller",
        ]
        combined = []
        for name in groups:
            combined.extend(self.controllers[name]["ros__parameters"]["joints"])
        self.assertEqual(sorted(combined), sorted(ACTUATED_JOINTS))
        self.assertEqual(len(combined), len(set(combined)))
        self.assertEqual(
            self.controllers["controller_manager"]["ros__parameters"]["update_rate"],
            250,
        )
        self.assertFalse(
            self.controllers["smartbot_joint_trajectory_controller"]["ros__parameters"][
                "open_loop_control"
            ]
        )

    def test_srdf_names_exist_on_the_robot(self):
        self.assertIn('group name="whole_body"', self.srdf)
        self.assertNotIn("virtual_joint", self.srdf)
        for name in ACTUATED_JOINTS:
            self.assertIn(f'<joint name="{name}" value="0"/>', self.srdf)
        for link in (
            "pelvis_link",
            "torso_link",
            "head_link",
            "left_hand_link",
            "right_foot_link",
            "left_hip_roll_link",
        ):
            self.assertIn(link, self.description)

    def test_hardware_codec_joint_ids_match_actuated_joints(self):
        header = (
            CONTROL
            / "include/smartbot_ii_control/joint_target_codec.hpp"
        ).read_text(encoding="utf-8")
        start = header.index("kActuatedJoints = {{")
        end = header.index("}};", start)
        names = tuple(re.findall(r'"([^"]+_joint)"', header[start:end]))
        self.assertEqual(names, ACTUATED_JOINTS)
        self.assertIn(f'kPhysicalAckToken = "{PHYSICAL_ACK_TOKEN}"', header)
        self.assertIn("sizeof(JointTargetPacket) == 5", header)
        plugin = (CONTROL / "smartbot_ii_hardware_plugin.xml").read_text(encoding="utf-8")
        self.assertIn("smartbot_ii_control/SmartBotIIHardware", plugin)
        self.assertIn("hardware_interface::SystemInterface", plugin)

    def test_joint_node_stops_match_safety_limits(self):
        header = (
            ROOT
            / "firmware/smartbot_ii_joint_node/include/smartbot_joint/joint_node.hpp"
        ).read_text(encoding="utf-8")
        start = header.index("kSimulatedStops[kNodeCount] = {")
        end = header.index("};", start)
        rows = re.findall(
            r'\{"([^"]+)",\s*([-0-9.]+)f,\s*([-0-9.]+)f,\s*([-0-9.]+)f\}',
            header[start:end],
        )
        self.assertEqual(tuple(name for name, *_ in rows), ACTUATED_JOINTS)
        for name, low, high, velocity in rows:
            safety = self.policy.joints[name]
            self.assertAlmostEqual(float(low), safety.min_position)
            self.assertAlmostEqual(float(high), safety.max_position)
            self.assertAlmostEqual(float(velocity), safety.max_velocity)
        protocol = (
            ROOT / "firmware/smartbot_ii_joint_node/include/smartbot_joint/can_protocol.hpp"
        ).read_text(encoding="utf-8")
        self.assertIn("kHeartbeatTimeoutUs = 100000", protocol)
        self.assertIn("kNodeCount = 22", protocol)

    def test_inertia_formulas_are_present(self):
        macros = (DESC / "urdf/smartbot_ii.macros.xacro").read_text(encoding="utf-8")
        self.assertIn("mass * (y * y + z * z) / 12.0", macros)
        self.assertIn("mass * (3.0 * radius * radius + length * length) / 12.0", macros)
        self.assertIn("0.5 * mass * radius * radius", macros)
        self.assertIn("(2.0 / 5.0) * mass * radius * radius", macros)


if __name__ == "__main__":
    unittest.main()
