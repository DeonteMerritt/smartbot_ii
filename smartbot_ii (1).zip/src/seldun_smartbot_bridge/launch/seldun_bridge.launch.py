"""Start the Seldun bridge. Simulation mode is the shipped configuration."""

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, LogInfo
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    bridge_share = FindPackageShare("seldun_smartbot_bridge")
    safety_file = PathJoinSubstitution(
        [
            FindPackageShare("smartbot_ii_description"),
            "config",
            "safety_limits.yaml",
        ]
    )
    params = PathJoinSubstitution([bridge_share, "config", "bridge_params.yaml"])
    return LaunchDescription(
        [
            DeclareLaunchArgument(
                "use_sim_time",
                default_value="false",
                description="Set true when the bridge is used with Gazebo.",
            ),
            LogInfo(
                msg=(
                    "Seldun bridge starting in its parameter-file mode. "
                    "The shipped file is simulation. "
                    "Physical mode does not enable motors."
                )
            ),
            Node(
                package="seldun_smartbot_bridge",
                executable="seldun_bridge",
                name="seldun_smartbot_bridge",
                output="screen",
                parameters=[
                    params,
                    {
                        "safety_limits_file": safety_file,
                        "use_sim_time": LaunchConfiguration("use_sim_time"),
                    },
                ],
            ),
        ]
    )
