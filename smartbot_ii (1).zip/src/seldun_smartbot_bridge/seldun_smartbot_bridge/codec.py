"""Translate a validated Seldun command into plain message fields.

ROS message objects are built in the node. These dicts are what the tests check.
"""

from __future__ import annotations

from seldun_smartbot_bridge.validator import SeldunCommandData


def split_duration(seconds: float) -> tuple[int, int]:
    """Split a non-negative duration into seconds and nanoseconds."""
    if seconds < 0.0:
        raise ValueError("time_from_start_sec must be non-negative.")
    sec = int(seconds)
    nanosec = int(round((seconds - sec) * 1_000_000_000))
    if nanosec >= 1_000_000_000:
        sec += 1
        nanosec -= 1_000_000_000
    return sec, nanosec


def build_joint_trajectory(cmd: SeldunCommandData) -> dict:
    """Return the fields of one single-point JointTrajectory."""
    sec, nanosec = split_duration(cmd.time_from_start_sec)
    point = {
        "positions": [float(value) for value in cmd.positions],
        "time_from_start_sec": sec,
        "time_from_start_nanosec": nanosec,
    }
    if cmd.velocities:
        point["velocities"] = [float(value) for value in cmd.velocities]
    if cmd.efforts:
        point["effort"] = [float(value) for value in cmd.efforts]
    return {
        "joint_names": list(cmd.joint_names),
        "points": [point],
    }


def build_follow_joint_trajectory_goal(cmd: SeldunCommandData) -> dict:
    """Return the fields of a FollowJointTrajectory goal."""
    return {
        "trajectory": build_joint_trajectory(cmd),
        "goal_time_tolerance_sec": 1,
        "goal_time_tolerance_nanosec": 0,
    }


def build_twist(cmd: SeldunCommandData) -> dict:
    """Return the fields of a geometry_msgs/Twist."""
    return {
        "linear": {"x": cmd.linear_x, "y": cmd.linear_y, "z": cmd.linear_z},
        "angular": {"x": cmd.angular_x, "y": cmd.angular_y, "z": cmd.angular_z},
    }


def zero_twist() -> dict:
    """A Twist that commands no motion."""
    return {
        "linear": {"x": 0.0, "y": 0.0, "z": 0.0},
        "angular": {"x": 0.0, "y": 0.0, "z": 0.0},
    }
