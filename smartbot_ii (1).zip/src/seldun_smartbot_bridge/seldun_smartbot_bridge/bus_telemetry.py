"""Raspberry Pi receiver for SmartBot II limb-bus status frames.

The parser has no ROS dependency. The default transport is an in-process queue.
socketcan and serial open only when that transport is requested. Listening does
not enable motors, and a latched software stop is not a hardware emergency stop.

Status ID is 0x300 + node_id. Node 1 is the first ACTUATED_JOINTS entry.
DLC 8 layout, little-endian:
  bytes 0-3  position radians, float32
  bytes 4-5  velocity, int16 counts of 0.001 rad/s
  byte  6    temperature, int8 Celsius; -128 means the sensor is not fitted
  byte  7    fault flags

A legacy DLC 6 frame is still accepted: float32 position, fault enum, unused flags.
"""

from __future__ import annotations

import math
import queue
import struct
import threading
from dataclasses import dataclass

from seldun_smartbot_bridge.validator import ACTUATED_JOINTS

STATUS_ID_BASE = 0x300
NODE_COUNT = 22
VELOCITY_SCALE = 0.001
TEMPERATURE_UNAVAILABLE = -128
# REPLACE_WITH_PHYSICAL_MEASUREMENT. This is not a characterized motor limit.
OVERTEMPERATURE_CELSIUS = 80.0

FLAG_ENCODER = 0x01
FLAG_OVERTEMPERATURE = 0x02
FLAG_OVERCURRENT = 0x04
FLAG_HEARTBEAT = 0x08

LEGACY_HEARTBEAT = 1
LEGACY_ENCODER = {2, 3, 4}
LEGACY_DISARMED = 5

_ALERT_FLAGS = (
    (FLAG_ENCODER, "encoder"),
    (FLAG_OVERTEMPERATURE, "overtemperature"),
    (FLAG_OVERCURRENT, "overcurrent"),
    (FLAG_HEARTBEAT, "heartbeat_timeout"),
)

SERIAL_SYNC = 0xA5
SERIAL_RECORD_LEN = 13


@dataclass(frozen=True)
class BusFrame:
    arbitration_id: int
    data: bytes


@dataclass(frozen=True)
class JointSample:
    joint_name: str
    node_id: int
    position_rad: float
    velocity_rad_s: float | None
    temperature_c: float | None
    fault_flags: int
    alert_names: tuple[str, ...]


def joint_name_for_node(node_id: int) -> str:
    if node_id < 1 or node_id > NODE_COUNT:
        raise ValueError(f"Node id {node_id} is outside 1..{NODE_COUNT}.")
    return ACTUATED_JOINTS[node_id - 1]


def status_id(node_id: int) -> int:
    return STATUS_ID_BASE + node_id


def _finite_f32(data: bytes) -> float | None:
    bits = int.from_bytes(data[:4], "little")
    if ((bits >> 23) & 0xFF) == 0xFF:
        return None
    value = struct.unpack("<f", data[:4])[0]
    if not math.isfinite(value):
        return None
    return float(value)


def _int16_le(data: bytes) -> int:
    value = int.from_bytes(data, "little", signed=False)
    if value & 0x8000:
        value -= 0x10000
    return value


def _int8(value: int) -> int:
    return value - 256 if value >= 128 else value


def _alert_names(flags: int, temperature_c: float | None) -> tuple[str, ...]:
    names = [name for bit, name in _ALERT_FLAGS if flags & bit]
    if (
        temperature_c is not None
        and temperature_c >= OVERTEMPERATURE_CELSIUS
        and "overtemperature" not in names
    ):
        names.append("overtemperature")
    return tuple(names)


def parse_status_frame(frame: BusFrame) -> JointSample | None:
    """Return one joint sample, or None when the frame is not status telemetry."""
    node_id = frame.arbitration_id - STATUS_ID_BASE
    if node_id < 1 or node_id > NODE_COUNT:
        return None
    data = bytes(frame.data)
    if len(data) >= 8:
        position = _finite_f32(data)
        if position is None:
            return None
        velocity = _int16_le(data[4:6]) * VELOCITY_SCALE
        raw_temp = _int8(data[6])
        temperature = None if raw_temp == TEMPERATURE_UNAVAILABLE else float(raw_temp)
        flags = data[7]
        return JointSample(
            joint_name_for_node(node_id),
            node_id,
            position,
            velocity,
            temperature,
            flags,
            _alert_names(flags, temperature),
        )
    if len(data) == 6:
        position = _finite_f32(data)
        if position is None:
            return None
        code = data[4]
        flags = 0
        if code in LEGACY_ENCODER:
            flags |= FLAG_ENCODER
        elif code == LEGACY_HEARTBEAT:
            flags |= FLAG_HEARTBEAT
        elif code == LEGACY_DISARMED or code == 0:
            flags = 0
        return JointSample(
            joint_name_for_node(node_id),
            node_id,
            position,
            None,
            None,
            flags,
            _alert_names(flags, None),
        )
    return None


def measured_from_positions(positions: dict[str, float]) -> dict[str, float]:
    """Build the dictionary stored on SeldunBridge._measured.

    The keys are exactly ACTUATED_JOINTS, in that order.
    """
    names = set(positions)
    expected = set(ACTUATED_JOINTS)
    if names != expected:
        missing = sorted(expected - names)
        extra = sorted(names - expected)
        raise ValueError(
            "Measured positions must contain exactly the 22 actuated joints. "
            f"Missing: {missing}. Extra: {extra}."
        )
    measured: dict[str, float] = {}
    for name in ACTUATED_JOINTS:
        value = float(positions[name])
        if not math.isfinite(value):
            raise ValueError(f"Measured position for '{name}' is not finite.")
        measured[name] = value
    return measured


def encode_serial_record(frame: BusFrame) -> bytes:
    payload = bytes(
        [
            SERIAL_SYNC,
            frame.arbitration_id & 0xFF,
            (frame.arbitration_id >> 8) & 0xFF,
            min(len(frame.data), 8),
        ]
    )
    data = bytes(frame.data[:8]).ljust(8, b"\x00")
    body = payload + data
    checksum = 0
    for byte in body:
        checksum ^= byte
    return body + bytes((checksum,))


def _mock_frame_from_serial(record: bytes) -> BusFrame | None:
    if len(record) != SERIAL_RECORD_LEN or record[0] != SERIAL_SYNC:
        return None
    checksum = 0
    for byte in record[:-1]:
        checksum ^= byte
    if checksum != record[-1]:
        return None
    arbitration_id = record[1] | (record[2] << 8)
    dlc = record[3]
    if dlc > 8:
        return None
    return BusFrame(arbitration_id, record[4 : 4 + dlc])


class _MockSource:
    def __init__(self) -> None:
        self._queue: queue.Queue[BusFrame] = queue.Queue()

    def inject(self, frame: BusFrame) -> None:
        self._queue.put(frame)

    def read(self, timeout: float) -> BusFrame | None:
        try:
            return self._queue.get(timeout=timeout)
        except queue.Empty:
            return None

    def close(self) -> None:
        return None


class _SocketCanSource:
    def __init__(self, channel: str, bitrate: int) -> None:
        try:
            import can
        except ImportError as exc:
            raise RuntimeError(
                "python-can is not installed. Install it before transport 'socketcan'."
            ) from exc
        self._bitrate = bitrate
        try:
            self._bus = can.Bus(channel=channel, interface="socketcan")
        except TypeError:
            self._bus = can.Bus(channel=channel, bustype="socketcan")

    def read(self, timeout: float) -> BusFrame | None:
        message = self._bus.recv(timeout=timeout)
        if message is None:
            return None
        return BusFrame(int(message.arbitration_id), bytes(message.data))

    def close(self) -> None:
        self._bus.shutdown()


class _SerialSource:
    def __init__(self, port: str, baudrate: int) -> None:
        try:
            import serial
        except ImportError as exc:
            raise RuntimeError(
                "pyserial is not installed. Install it before transport 'serial'."
            ) from exc
        self._serial = serial.Serial(port, baudrate=baudrate, timeout=0.05)
        self._buffer = bytearray()

    def read(self, timeout: float) -> BusFrame | None:
        del timeout
        chunk = self._serial.read(64)
        if chunk:
            self._buffer.extend(chunk)
        while len(self._buffer) >= SERIAL_RECORD_LEN:
            if self._buffer[0] != SERIAL_SYNC:
                del self._buffer[0]
                continue
            record = bytes(self._buffer[:SERIAL_RECORD_LEN])
            del self._buffer[:SERIAL_RECORD_LEN]
            frame = _mock_frame_from_serial(record)
            if frame is not None:
                return frame
        return None

    def close(self) -> None:
        self._serial.close()


class LimbBusReceiver:
    """Background listener for limb-bus status frames.

    transport 'mock' reads an in-process queue. 'socketcan' uses python-can.
    'serial' uses pyserial and the fixed 13-byte record. Call feed_bridge to
    copy a complete 22-joint position dictionary into SeldunBridge._measured.
    """

    def __init__(
        self,
        transport: str = "mock",
        channel: str = "can0",
        bitrate: int = 500_000,
        serial_port: str = "",
        serial_baud: int = 1_000_000,
        bridge: object | None = None,
    ) -> None:
        if transport not in ("mock", "socketcan", "serial"):
            raise ValueError(
                f"Unknown limb-bus transport '{transport}'. Use mock, socketcan, or serial."
            )
        self.transport = transport
        self.channel = channel
        self.bitrate = bitrate
        self._bridge = bridge
        self._source: _MockSource | _SocketCanSource | _SerialSource
        if transport == "mock":
            self._source = _MockSource()
        elif transport == "socketcan":
            self._source = _SocketCanSource(channel, bitrate)
        else:
            if not serial_port:
                raise ValueError("serial transport requires serial_port.")
            self._source = _SerialSource(serial_port, serial_baud)
        self._lock = threading.Lock()
        self._samples: dict[str, JointSample] = {}
        self._latched_alerts: dict[str, int] = {}
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        if self._thread is not None:
            return
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._loop, name="smartbot_limb_bus", daemon=True
        )
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=1.0)
            self._thread = None
        self._source.close()

    def rearm_fault_latch(self) -> None:
        """Forget which fault bits have already raised an alert.

        reset_stop clears the bridge software latch. The next status frame that
        still carries a fault flag raises the alert again.
        """
        with self._lock:
            self._latched_alerts.clear()

    def inject_frame(self, frame: BusFrame) -> JointSample | None:
        if not isinstance(self._source, _MockSource):
            raise RuntimeError("inject_frame is only available on the mock transport.")
        return self.ingest(frame)

    def ingest(self, frame: BusFrame) -> JointSample | None:
        sample = parse_status_frame(frame)
        if sample is None:
            return None
        with self._lock:
            self._samples[sample.joint_name] = sample
            previous = self._latched_alerts.get(sample.joint_name, 0)
            rising = 0
            for bit, _name in _ALERT_FLAGS:
                if sample.fault_flags & bit and not previous & bit:
                    rising |= bit
            if sample.temperature_c is not None and sample.temperature_c >= OVERTEMPERATURE_CELSIUS:
                if not previous & FLAG_OVERTEMPERATURE:
                    rising |= FLAG_OVERTEMPERATURE
            self._latched_alerts[sample.joint_name] = sample.fault_flags
            if sample.temperature_c is not None and sample.temperature_c >= OVERTEMPERATURE_CELSIUS:
                self._latched_alerts[sample.joint_name] |= FLAG_OVERTEMPERATURE
        if rising and self._bridge is not None and hasattr(self._bridge, "latch_hardware_alert"):
            names = tuple(name for bit, name in _ALERT_FLAGS if rising & bit)
            self._bridge.latch_hardware_alert(sample.joint_name, names, sample)
        self.feed_bridge()
        return sample

    def feed_bridge(self) -> dict[str, float] | None:
        positions = self.measured_positions()
        if positions is None or self._bridge is None:
            return positions
        if hasattr(self._bridge, "apply_measured_positions"):
            self._bridge.apply_measured_positions(positions)
        return positions

    def measured_positions(self) -> dict[str, float] | None:
        with self._lock:
            if set(self._samples) != set(ACTUATED_JOINTS):
                return None
            raw = {name: self._samples[name].position_rad for name in ACTUATED_JOINTS}
        return measured_from_positions(raw)

    def position_vector(self) -> list[float]:
        with self._lock:
            return [self._value(name, "position_rad") for name in ACTUATED_JOINTS]

    def velocity_vector(self) -> list[float]:
        with self._lock:
            return [self._optional(name, "velocity_rad_s") for name in ACTUATED_JOINTS]

    def temperature_vector(self) -> list[float]:
        with self._lock:
            return [self._optional(name, "temperature_c") for name in ACTUATED_JOINTS]

    def _value(self, name: str, field: str) -> float:
        sample = self._samples.get(name)
        if sample is None:
            return math.nan
        value = getattr(sample, field)
        return math.nan if value is None else float(value)

    def _optional(self, name: str, field: str) -> float:
        return self._value(name, field)

    def _loop(self) -> None:
        while not self._stop.is_set():
            frame = self._source.read(0.05)
            if frame is not None:
                self.ingest(frame)

    def push_serial_record(self, record: bytes) -> JointSample | None:
        frame = _mock_frame_from_serial(record)
        if frame is None:
            raise ValueError("Serial limb-bus record is malformed.")
        return self.ingest(frame)
