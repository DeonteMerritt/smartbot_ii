"""ROS 2 node that validates Seldun commands and publishes simulation commands.

Default mode is simulation. Physical mode rejects motion unless the process
was started with an explicit three-part configuration change. Even then, this
node only publishes ROS messages. It does not drive motors, and it is not a
hardware emergency stop.
"""

from __future__ import annotations

import os
import threading

import rclpy
from rclpy.action import ActionClient
from rclpy.node import Node
from builtin_interfaces.msg import Duration
from control_msgs.action import FollowJointTrajectory
from diagnostic_msgs.msg import DiagnosticArray, DiagnosticStatus, KeyValue
from geometry_msgs.msg import Twist
from sensor_msgs.msg import JointState
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint

from seldun_smartbot_bridge.bus_telemetry import (
    LimbBusReceiver,
    measured_from_positions,
)
from seldun_smartbot_bridge.codec import (
    build_follow_joint_trajectory_goal,
    build_twist,
    zero_twist,
)
from seldun_smartbot_bridge.msg import SeldunCommand, SeldunCommandResult
from seldun_smartbot_bridge.validator import (
    HardwareAssessment,
    SafetyPolicy,
    ValidationResult,
    assess_hardware_mode,
    command_from_mapping,
    load_policy,
    select_joint_transport,
    twist_timeout_expired,
    validate_command,
)


class SeldunBridge(Node):
    def __init__(self) -> None:
        super().__init__("seldun_smartbot_bridge")
        self.declare_parameter("hardware_mode", "simulation")
        self.declare_parameter("allow_physical_hardware", False)
        self.declare_parameter("physical_hardware_ack", "")
        self.declare_parameter("safety_limits_file", "")
        self.declare_parameter(
            "trajectory_controller_name", "smartbot_joint_trajectory_controller"
        )
        self.declare_parameter("command_transport", "action")
        self.declare_parameter("cmd_vel_topic", "/cmd_vel")
        self.declare_parameter("command_topic", "seldun/command")
        self.declare_parameter("result_topic", "seldun/command_result")
        self.declare_parameter("joint_states_topic", "/joint_states")
        self.declare_parameter("diagnostics_period_sec", 1.0)
        self.declare_parameter("bus_telemetry_transport", "off")
        self.declare_parameter("bus_telemetry_channel", "can0")
        self.declare_parameter("bus_telemetry_bitrate", 500000)
        self.declare_parameter("bus_serial_port", "")
        self.declare_parameter("bus_serial_baud", 1000000)
        self.declare_parameter("system_alert_topic", "smartbot/system_alert")

        mode = self.get_parameter("hardware_mode").get_parameter_value().string_value
        allow = (
            self.get_parameter("allow_physical_hardware")
            .get_parameter_value()
            .bool_value
        )
        ack = (
            self.get_parameter("physical_hardware_ack").get_parameter_value().string_value
        )
        self._hardware: HardwareAssessment = assess_hardware_mode(mode, allow, ack)
        self._command_transport = (
            self.get_parameter("command_transport").get_parameter_value().string_value
        )
        controller = (
            self.get_parameter("trajectory_controller_name")
            .get_parameter_value()
            .string_value
        )
        self._policy: SafetyPolicy | None = None
        self._configuration_fault = ""
        self._load_policy()

        self._state_lock = threading.Lock()
        self._software_estop = False
        self._measured: dict[str, float] | None = None
        self._bus: LimbBusReceiver | None = None
        self._accepted_count = 0
        self._rejected_count = 0
        self._last_command_id = ""
        self._last_error_code = "NONE"
        self._last_cmd_vel_time: float | None = None
        self._nonzero_twist_active = False

        cmd_vel_topic = self.get_parameter("cmd_vel_topic").get_parameter_value().string_value
        command_topic = self.get_parameter("command_topic").get_parameter_value().string_value
        result_topic = self.get_parameter("result_topic").get_parameter_value().string_value
        joint_states_topic = (
            self.get_parameter("joint_states_topic").get_parameter_value().string_value
        )
        period = (
            self.get_parameter("diagnostics_period_sec").get_parameter_value().double_value
        )
        if period <= 0.0:
            period = 1.0

        self._result_pub = self.create_publisher(SeldunCommandResult, result_topic, 10)
        self._twist_pub = self.create_publisher(Twist, cmd_vel_topic, 10)
        self._trajectory_pub = self.create_publisher(
            JointTrajectory, f"/{controller}/joint_trajectory", 10
        )
        self._diag_pub = self.create_publisher(DiagnosticArray, "/diagnostics", 10)
        alert_topic = (
            self.get_parameter("system_alert_topic").get_parameter_value().string_value
        )
        self._alert_pub = self.create_publisher(DiagnosticArray, alert_topic, 10)
        self._start_bus_receiver()
        self.create_subscription(SeldunCommand, command_topic, self._on_command, 10)
        self.create_subscription(JointState, joint_states_topic, self._on_joint_state, 20)
        self._action = ActionClient(
            self,
            FollowJointTrajectory,
            f"/{controller}/follow_joint_trajectory",
        )
        self.create_timer(period, self._on_timer)
        self.get_logger().info(self._hardware.message)
        if self._configuration_fault:
            self.get_logger().error(self._configuration_fault)

    def destroy_node(self):
        if self._bus is not None:
            self._bus.stop()
            self._bus = None
        return super().destroy_node()

    def _start_bus_receiver(self) -> None:
        transport = (
            self.get_parameter("bus_telemetry_transport").get_parameter_value().string_value
        )
        if transport in ("", "off"):
            self.get_logger().info(
                "Limb-bus telemetry is off. Set bus_telemetry_transport to "
                "socketcan or serial to listen. The software stop is not a hardware e-stop."
            )
            return
        try:
            self._bus = LimbBusReceiver(
                transport=transport,
                channel=self.get_parameter("bus_telemetry_channel")
                .get_parameter_value()
                .string_value,
                bitrate=self.get_parameter("bus_telemetry_bitrate")
                .get_parameter_value()
                .integer_value,
                serial_port=self.get_parameter("bus_serial_port")
                .get_parameter_value()
                .string_value,
                serial_baud=self.get_parameter("bus_serial_baud")
                .get_parameter_value()
                .integer_value,
                bridge=self,
            )
            self._bus.start()
        except Exception as exc:  # noqa: BLE001 - keep the command bridge alive
            self._bus = None
            self.get_logger().error(
                f"Limb-bus receiver did not start: {exc}. Motion commands stay available "
                "only under the existing software limits."
            )
            return
        self.get_logger().info(
            f"Limb-bus receiver listening with transport '{transport}'. "
            "A fault flag latches the software stop. It does not cut motor power."
        )

    def apply_measured_positions(self, positions: dict[str, float]) -> None:
        """Store a complete 22-joint position dictionary on _measured."""
        updated = measured_from_positions(positions)
        with self._state_lock:
            self._measured = updated

    def latch_hardware_alert(self, joint_name: str, alert_names: tuple[str, ...], sample) -> None:
        """Latch the software e-stop and publish a master alert.

        This does not open a contactor and it does not disable a motor driver.
        """
        names = ", ".join(alert_names) if alert_names else "unspecified"
        detail = (
            f"Limb bus fault on {joint_name}: {names}. "
            f"position={sample.position_rad:.4f} rad. "
            "Software stop is latched. This is not a hardware emergency stop."
        )
        with self._state_lock:
            self._software_estop = True
        self._publish_twist_dict(zero_twist())
        self._nonzero_twist_active = False
        self.get_logger().error(detail)
        self._publish_system_alert(joint_name, names, detail)

    def _publish_system_alert(self, joint_name: str, names: str, detail: str) -> None:
        status = DiagnosticStatus()
        status.level = DiagnosticStatus.ERROR
        status.name = "smartbot_limb_bus"
        status.hardware_id = joint_name
        status.message = detail
        status.values = [
            KeyValue(key="joint", value=joint_name),
            KeyValue(key="faults", value=names),
            KeyValue(key="software_estop_latched", value="true"),
            KeyValue(key="hardware_emergency_stop_shipped", value="false"),
        ]
        array = DiagnosticArray()
        array.header.stamp = self.get_clock().now().to_msg()
        array.status = [status]
        self._alert_pub.publish(array)
        self._diag_pub.publish(array)

    def _load_policy(self) -> None:
        path = self.get_parameter("safety_limits_file").get_parameter_value().string_value
        if not path:
            try:
                from ament_index_python.packages import get_package_share_directory

                path = os.path.join(
                    get_package_share_directory("smartbot_ii_description"),
                    "config",
                    "safety_limits.yaml",
                )
            except Exception as exc:  # noqa: BLE001 - report the lookup failure
                self._configuration_fault = (
                    "Could not locate safety_limits.yaml. Set safety_limits_file. "
                    f"Detail: {exc}"
                )
                return
        try:
            self._policy = load_policy(path)
            self.get_logger().info(f"Loaded safety limits from {path}.")
        except Exception as exc:  # noqa: BLE001 - keep the node alive and rejecting
            self._configuration_fault = (
                f"Failed to load safety limits from '{path}': {exc}. "
                "All motion commands will be rejected."
            )

    def _on_joint_state(self, msg: JointState) -> None:
        if self._bus is not None:
            return
        with self._state_lock:
            if self._measured is None:
                self._measured = {}
            for name, position in zip(msg.name, msg.position):
                self._measured[name] = float(position)

    def _on_timer(self) -> None:
        now = self.get_clock().now().nanoseconds / 1e9
        timeout = 1.0 if self._policy is None else self._policy.command_timeout_sec
        if twist_timeout_expired(
            self._last_cmd_vel_time, now, timeout, self._nonzero_twist_active
        ):
            self._publish_twist_dict(zero_twist())
            self._nonzero_twist_active = False
            self.get_logger().warn(
                "cmd_vel timed out. Published a zero Twist. "
                "No locomotion controller is loaded."
            )
        self._publish_diagnostics()

    def _on_command(self, msg: SeldunCommand) -> None:
        try:
            self._handle_command(msg)
        except Exception as exc:  # noqa: BLE001 - one bad command must not stop the node
            self._rejected_count += 1
            self._last_error_code = "MALFORMED"
            self._publish_result(
                msg.command_id,
                False,
                "MALFORMED",
                f"Command could not be processed: {exc}",
                False,
                False,
                False,
            )

    def _handle_command(self, msg: SeldunCommand) -> None:
        parsed = command_from_mapping(
            {
                "command_id": msg.command_id,
                "command_type": msg.command_type,
                "joint_names": list(msg.joint_names),
                "positions": list(msg.positions),
                "velocities": list(msg.velocities),
                "efforts": list(msg.efforts),
                "time_from_start_sec": msg.time_from_start_sec,
                "linear_x": msg.linear_x,
                "linear_y": msg.linear_y,
                "linear_z": msg.linear_z,
                "angular_x": msg.angular_x,
                "angular_y": msg.angular_y,
                "angular_z": msg.angular_z,
            }
        )
        if not hasattr(parsed, "command_type"):
            self._reject_result(msg.command_id, parsed)
            return
        if self._policy is None:
            self._reject_result(
                parsed.command_id,
                ValidationResult(
                    False,
                    "MALFORMED",
                    self._configuration_fault or "Safety limits are not loaded.",
                ),
            )
            return
        with self._state_lock:
            software_estop_latched = self._software_estop
            measured_positions = (
                None if self._measured is None else dict(self._measured)
            )
        result = validate_command(
            parsed,
            self._policy,
            hardware=self._hardware,
            software_estop_latched=software_estop_latched,
            measured_positions=measured_positions,
        )
        if not result.accepted:
            self._reject_result(parsed.command_id, result)
            return

        if parsed.command_type == "stop":
            with self._state_lock:
                self._software_estop = True
            self._publish_twist_dict(zero_twist())
            self._nonzero_twist_active = False
            self._accept_result(parsed.command_id, result.message, True, False, False)
            return
        if parsed.command_type == "reset_stop":
            with self._state_lock:
                self._software_estop = False
            if self._bus is not None:
                self._bus.rearm_fault_latch()
            self._accept_result(parsed.command_id, result.message, False, False, False)
            return
        if parsed.command_type == "cmd_vel":
            twist = build_twist(parsed)
            self._publish_twist_dict(twist)
            self._last_cmd_vel_time = self.get_clock().now().nanoseconds / 1e9
            self._nonzero_twist_active = any(
                abs(value) > 0.0
                for axis in (twist["linear"], twist["angular"])
                for value in axis.values()
            )
            self._accept_result(parsed.command_id, result.message, True, False, False)
            return

        code, transport_message, transport = select_joint_transport(
            self._command_transport, self._action.server_is_ready()
        )
        if transport == "":
            self._reject_result(
                parsed.command_id,
                ValidationResult(False, code, transport_message),
            )
            return
        published_topic = False
        dispatched_action = False
        if transport == "topic":
            self._publish_trajectory(parsed)
            published_topic = True
        else:
            self._send_action(parsed)
            dispatched_action = True
        self._accept_result(
            parsed.command_id,
            f"{result.message} {transport_message}",
            False,
            published_topic,
            dispatched_action,
        )

    def _publish_trajectory(self, cmd) -> None:
        from seldun_smartbot_bridge.codec import build_joint_trajectory

        fields = build_joint_trajectory(cmd)
        message = JointTrajectory()
        message.header.stamp = self.get_clock().now().to_msg()
        message.joint_names = fields["joint_names"]
        point_fields = fields["points"][0]
        point = JointTrajectoryPoint()
        point.positions = point_fields["positions"]
        if "velocities" in point_fields:
            point.velocities = point_fields["velocities"]
        if "effort" in point_fields:
            point.effort = point_fields["effort"]
        point.time_from_start = Duration(
            sec=point_fields["time_from_start_sec"],
            nanosec=point_fields["time_from_start_nanosec"],
        )
        message.points = [point]
        self._trajectory_pub.publish(message)

    def _send_action(self, cmd) -> None:
        fields = build_follow_joint_trajectory_goal(cmd)
        goal = FollowJointTrajectory.Goal()
        goal.trajectory.joint_names = fields["trajectory"]["joint_names"]
        goal.trajectory.header.stamp = self.get_clock().now().to_msg()
        point_fields = fields["trajectory"]["points"][0]
        point = JointTrajectoryPoint()
        point.positions = point_fields["positions"]
        if "velocities" in point_fields:
            point.velocities = point_fields["velocities"]
        if "effort" in point_fields:
            point.effort = point_fields["effort"]
        point.time_from_start = Duration(
            sec=point_fields["time_from_start_sec"],
            nanosec=point_fields["time_from_start_nanosec"],
        )
        goal.trajectory.points = [point]
        goal.goal_time_tolerance = Duration(
            sec=fields["goal_time_tolerance_sec"],
            nanosec=fields["goal_time_tolerance_nanosec"],
        )
        self._action.send_goal_async(goal)

    def _publish_twist_dict(self, fields: dict) -> None:
        message = Twist()
        message.linear.x = float(fields["linear"]["x"])
        message.linear.y = float(fields["linear"]["y"])
        message.linear.z = float(fields["linear"]["z"])
        message.angular.x = float(fields["angular"]["x"])
        message.angular.y = float(fields["angular"]["y"])
        message.angular.z = float(fields["angular"]["z"])
        self._twist_pub.publish(message)

    def _reject_result(self, command_id: str, result) -> None:
        self._rejected_count += 1
        self._last_command_id = command_id
        self._last_error_code = result.error_code
        self.get_logger().warn(result.message)
        self._publish_result(
            command_id,
            False,
            result.error_code,
            result.message,
            False,
            False,
            False,
        )

    def _accept_result(
        self,
        command_id: str,
        message: str,
        published_twist: bool,
        published_topic: bool,
        dispatched_action: bool,
    ) -> None:
        self._accepted_count += 1
        self._last_command_id = command_id
        self._last_error_code = "OK"
        self.get_logger().info(message)
        self._publish_result(
            command_id,
            True,
            "OK",
            message,
            published_twist,
            published_topic,
            dispatched_action,
        )

    def _publish_result(
        self,
        command_id: str,
        accepted: bool,
        error_code: str,
        message: str,
        published_twist: bool,
        published_topic: bool,
        dispatched_action: bool,
    ) -> None:
        result = SeldunCommandResult()
        result.command_id = command_id
        result.accepted = accepted
        result.error_code = error_code
        result.message = message
        result.hardware_mode = self._hardware.mode
        with self._state_lock:
            result.software_estop_latched = self._software_estop
        result.published_twist = published_twist
        result.published_joint_trajectory = published_topic
        result.dispatched_follow_joint_trajectory = dispatched_action
        self._result_pub.publish(result)

    def _publish_diagnostics(self) -> None:
        status = DiagnosticStatus()
        status.name = "seldun_smartbot_bridge"
        status.hardware_id = "smartbot_ii"
        with self._state_lock:
            software_estop = self._software_estop
        if self._configuration_fault or not self._hardware.motion_allowed:
            status.level = DiagnosticStatus.ERROR
        elif software_estop:
            status.level = DiagnosticStatus.WARN
        else:
            status.level = DiagnosticStatus.OK
        status.message = self._configuration_fault or self._hardware.message
        values = {
            "hardware_mode": self._hardware.mode,
            "motion_allowed": str(self._hardware.motion_allowed).lower(),
            "configuration_fault": self._configuration_fault,
            "software_estop_latched": str(software_estop).lower(),
            "command_transport": self._command_transport,
            "action_server_ready": str(self._action.server_is_ready()).lower(),
            "last_command_id": self._last_command_id,
            "last_error_code": self._last_error_code,
            "accepted_count": str(self._accepted_count),
            "rejected_count": str(self._rejected_count),
            "locomotion_implemented": "false",
            "physical_motor_driver_shipped": "false",
            "hardware_emergency_stop_shipped": "false",
        }
        status.values = [KeyValue(key=key, value=value) for key, value in values.items()]
        array = DiagnosticArray()
        array.header.stamp = self.get_clock().now().to_msg()
        array.status = [status]
        self._diag_pub.publish(array)


def main(args=None) -> None:
    rclpy.init(args=args)
    node = SeldunBridge()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()
