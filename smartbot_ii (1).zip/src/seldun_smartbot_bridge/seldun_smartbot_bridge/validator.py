"""Pure validation for Seldun commands.

This module does not import ROS. Unit tests run it without a ROS install.
Limits come from safety_limits.yaml and are simulated until replaced.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from pathlib import Path
from typing import Mapping

import yaml


PHYSICAL_ACK_TOKEN = "ENABLE_UNVALIDATED_PHYSICAL_HARDWARE"

ACTUATED_JOINTS = (
    "neck_yaw_joint",
    "neck_pitch_joint",
    "left_shoulder_pitch_joint",
    "left_shoulder_roll_joint",
    "left_elbow_joint",
    "left_wrist_joint",
    "right_shoulder_pitch_joint",
    "right_shoulder_roll_joint",
    "right_elbow_joint",
    "right_wrist_joint",
    "left_hip_yaw_joint",
    "left_hip_roll_joint",
    "left_hip_pitch_joint",
    "left_knee_joint",
    "left_ankle_pitch_joint",
    "left_ankle_roll_joint",
    "right_hip_yaw_joint",
    "right_hip_roll_joint",
    "right_hip_pitch_joint",
    "right_knee_joint",
    "right_ankle_pitch_joint",
    "right_ankle_roll_joint",
)

_LIMIT_EPS = 1e-9
_COMMAND_TYPES = ("joint_trajectory", "cmd_vel", "stop", "reset_stop")
_TWIST_FIELDS = (
    "linear_x",
    "linear_y",
    "linear_z",
    "angular_x",
    "angular_y",
    "angular_z",
)


@dataclass(frozen=True)
class JointLimit:
    name: str
    min_position: float
    max_position: float
    max_velocity: float
    max_effort: float


@dataclass(frozen=True)
class SafetyPolicy:
    joints: dict[str, JointLimit]
    max_position_delta_rad: float
    max_trajectory_duration_sec: float
    command_timeout_sec: float
    cmd_vel_linear_x_max: float
    cmd_vel_linear_y_max: float
    cmd_vel_linear_z_max: float
    cmd_vel_angular_x_max: float
    cmd_vel_angular_y_max: float
    cmd_vel_angular_z_max: float
    physical_ack_token: str


@dataclass(frozen=True)
class SeldunCommandData:
    command_id: str
    command_type: str
    joint_names: list[str] = field(default_factory=list)
    positions: list[float] = field(default_factory=list)
    velocities: list[float] = field(default_factory=list)
    efforts: list[float] = field(default_factory=list)
    time_from_start_sec: float = 0.0
    linear_x: float = 0.0
    linear_y: float = 0.0
    linear_z: float = 0.0
    angular_x: float = 0.0
    angular_y: float = 0.0
    angular_z: float = 0.0


@dataclass(frozen=True)
class ValidationResult:
    accepted: bool
    error_code: str
    message: str


@dataclass(frozen=True)
class HardwareAssessment:
    mode: str
    motion_allowed: bool
    error_code: str
    message: str


def _finite_number(value: object) -> bool:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return False
    return math.isfinite(float(value))


def _as_float_list(values: object, field_name: str) -> list[float] | ValidationResult:
    if values is None:
        return []
    if not isinstance(values, (list, tuple)):
        return ValidationResult(
            False,
            "MALFORMED",
            f"{field_name} must be a list of finite numbers. Command rejected.",
        )
    numbers: list[float] = []
    for index, value in enumerate(values):
        if not _finite_number(value):
            return ValidationResult(
                False,
                "NON_FINITE_VALUE",
                f"{field_name}[{index}] is not a finite number. Command rejected.",
            )
        numbers.append(float(value))
    return numbers


def command_from_mapping(data: Mapping[str, object]) -> SeldunCommandData | ValidationResult:
    """Build a command or return a rejection if the mapping is malformed."""
    try:
        command_id = data["command_id"]
        command_type = data["command_type"]
    except KeyError as exc:
        missing = exc.args[0]
        return ValidationResult(
            False,
            "MALFORMED",
            f"Missing field '{missing}'. Command rejected.",
        )
    if not isinstance(command_id, str) or not isinstance(command_type, str):
        return ValidationResult(
            False,
            "MALFORMED",
            "command_id and command_type must be strings. Command rejected.",
        )
    joint_names = data.get("joint_names", [])
    if not isinstance(joint_names, (list, tuple)) or not all(
        isinstance(name, str) for name in joint_names
    ):
        return ValidationResult(
            False,
            "MALFORMED",
            "joint_names must be a list of strings. Command rejected.",
        )
    parsed = {}
    for field_name in (
        "positions",
        "velocities",
        "efforts",
        "time_from_start_sec",
        *_TWIST_FIELDS,
    ):
        if field_name in ("positions", "velocities", "efforts"):
            value = _as_float_list(data.get(field_name, []), field_name)
            if isinstance(value, ValidationResult):
                return value
            parsed[field_name] = value
        else:
            raw = data.get(field_name, 0.0)
            if not _finite_number(raw):
                return ValidationResult(
                    False,
                    "NON_FINITE_VALUE",
                    f"{field_name} is not a finite number. Command rejected.",
                )
            parsed[field_name] = float(raw)
    return SeldunCommandData(
        command_id=command_id,
        command_type=command_type,
        joint_names=list(joint_names),
        positions=parsed["positions"],
        velocities=parsed["velocities"],
        efforts=parsed["efforts"],
        time_from_start_sec=parsed["time_from_start_sec"],
        linear_x=parsed["linear_x"],
        linear_y=parsed["linear_y"],
        linear_z=parsed["linear_z"],
        angular_x=parsed["angular_x"],
        angular_y=parsed["angular_y"],
        angular_z=parsed["angular_z"],
    )


def load_policy(path: str | Path) -> SafetyPolicy:
    """Load the software safety policy. Raises ValueError on a bad file."""
    file_path = Path(path)
    with file_path.open("r", encoding="utf-8") as handle:
        raw = yaml.safe_load(handle)
    if not isinstance(raw, dict):
        raise ValueError(f"{file_path} does not contain a YAML mapping.")
    metadata = raw.get("metadata")
    policy = raw.get("policy")
    joints_raw = raw.get("joints")
    if not isinstance(metadata, dict) or not isinstance(policy, dict) or not isinstance(joints_raw, dict):
        raise ValueError(f"{file_path} is missing metadata, policy, or joints.")
    token = metadata.get("physical_ack_token")
    if token != PHYSICAL_ACK_TOKEN:
        raise ValueError(
            "safety_limits.yaml physical_ack_token does not match the bridge token. "
            "The shipped token is the only string that can unlock physical mode."
        )
    names = set(joints_raw)
    expected = set(ACTUATED_JOINTS)
    if names != expected:
        missing = sorted(expected - names)
        extra = sorted(names - expected)
        raise ValueError(
            "safety_limits.yaml joint set does not match the actuated joints. "
            f"Missing: {missing}. Extra: {extra}."
        )
    joints: dict[str, JointLimit] = {}
    for name, entry in joints_raw.items():
        if not isinstance(entry, dict):
            raise ValueError(f"Joint '{name}' limits are not a mapping.")
        try:
            limit = JointLimit(
                name=name,
                min_position=float(entry["min_position_rad"]),
                max_position=float(entry["max_position_rad"]),
                max_velocity=float(entry["max_velocity_rad_s"]),
                max_effort=float(entry["max_effort_nm"]),
            )
        except (KeyError, TypeError, ValueError) as exc:
            raise ValueError(f"Joint '{name}' has incomplete limits: {exc}") from exc
        for value in (
            limit.min_position,
            limit.max_position,
            limit.max_velocity,
            limit.max_effort,
        ):
            if not math.isfinite(value):
                raise ValueError(f"Joint '{name}' contains a non-finite limit.")
        if limit.min_position > limit.max_position:
            raise ValueError(f"Joint '{name}' has min_position above max_position.")
        if limit.max_velocity <= 0.0 or limit.max_effort <= 0.0:
            raise ValueError(f"Joint '{name}' velocity and effort limits must be positive.")
        joints[name] = limit

    def required(key: str) -> float:
        if key not in policy:
            raise ValueError(f"safety policy is missing '{key}'.")
        value = float(policy[key])
        if not math.isfinite(value) or value < 0.0:
            raise ValueError(f"safety policy '{key}' must be a non-negative finite number.")
        return value

    return SafetyPolicy(
        joints=joints,
        max_position_delta_rad=required("max_position_delta_rad"),
        max_trajectory_duration_sec=required("max_trajectory_duration_sec"),
        command_timeout_sec=required("command_timeout_sec"),
        cmd_vel_linear_x_max=required("cmd_vel_linear_x_max_m_s"),
        cmd_vel_linear_y_max=required("cmd_vel_linear_y_max_m_s"),
        cmd_vel_linear_z_max=required("cmd_vel_linear_z_max_m_s"),
        cmd_vel_angular_x_max=required("cmd_vel_angular_x_max_rad_s"),
        cmd_vel_angular_y_max=required("cmd_vel_angular_y_max_rad_s"),
        cmd_vel_angular_z_max=required("cmd_vel_angular_z_max_rad_s"),
        physical_ack_token=PHYSICAL_ACK_TOKEN,
    )


def assess_hardware_mode(
    hardware_mode: str,
    allow_physical_hardware: bool,
    physical_hardware_ack: str,
) -> HardwareAssessment:
    """Decide whether motion commands may leave the bridge.

    Physical mode stays locked unless all three configuration values match.
    Unlocking the bridge still does not enable motors. No motor driver is shipped.
    """
    if hardware_mode == "simulation":
        return HardwareAssessment(
            mode="simulation",
            motion_allowed=True,
            error_code="OK",
            message=(
                "Simulation mode. Commands can be published on ROS topics. "
                "They do not drive physical motors."
            ),
        )
    if hardware_mode != "physical":
        return HardwareAssessment(
            mode="invalid",
            motion_allowed=False,
            error_code="HARDWARE_MODE_REJECTED",
            message=(
                f"hardware_mode '{hardware_mode}' is unknown. "
                "Use 'simulation' or, only after a deliberate configuration change, 'physical'."
            ),
        )
    ack_ok = physical_hardware_ack == PHYSICAL_ACK_TOKEN
    if not allow_physical_hardware or not ack_ok:
        return HardwareAssessment(
            mode="physical",
            motion_allowed=False,
            error_code="PHYSICAL_MODE_LOCKED",
            message=(
                "Physical hardware mode is locked. Motion commands are rejected. "
                "Unlocking requires hardware_mode=physical, allow_physical_hardware=true, "
                f"and physical_hardware_ack='{PHYSICAL_ACK_TOKEN}' at process start. "
                "That change does not add a motor driver or a hardware emergency stop, "
                "and it does not make walking safe."
            ),
        )
    return HardwareAssessment(
        mode="physical",
        motion_allowed=True,
        error_code="OK",
        message=(
            "Physical mode is unlocked in software only. The model, controllers, "
            "limits, and emergency stop are NOT validated. This bridge still only "
            "publishes ROS messages. No physical motor driver is included. "
            "Do not treat this as permission to walk or enable motors."
        ),
    )


def select_joint_transport(
    command_transport: str, action_server_ready: bool
) -> tuple[str, str, str]:
    """Choose one joint-command output so the controller is not commanded twice.

    Returns (error_code, message, transport). transport is 'action', 'topic', or ''.
    """
    if command_transport == "action":
        if not action_server_ready:
            return (
                "CONTROLLER_UNAVAILABLE",
                "FollowJointTrajectory action server is not ready. "
                "Start smartbot_joint_trajectory_controller, or set command_transport "
                "to 'topic'. No joint command was sent.",
                "",
            )
        return ("OK", "Dispatching FollowJointTrajectory action goal.", "action")
    if command_transport == "topic":
        return ("OK", "Publishing trajectory_msgs/JointTrajectory.", "topic")
    return (
        "MALFORMED",
        f"command_transport '{command_transport}' is unknown. Use 'action' or 'topic'.",
        "",
    )


def _reject(code: str, message: str) -> ValidationResult:
    return ValidationResult(False, code, message)


def _twist_values(cmd: SeldunCommandData) -> dict[str, float]:
    return {
        "linear_x": cmd.linear_x,
        "linear_y": cmd.linear_y,
        "linear_z": cmd.linear_z,
        "angular_x": cmd.angular_x,
        "angular_y": cmd.angular_y,
        "angular_z": cmd.angular_z,
    }


def _check_command_id(command_id: str) -> ValidationResult | None:
    if not isinstance(command_id, str):
        return _reject("MALFORMED", "command_id must be a string. Command rejected.")
    stripped = command_id.strip()
    if stripped == "" or stripped != command_id:
        return _reject(
            "EMPTY_COMMAND_ID",
            "command_id is empty or has surrounding whitespace. Command rejected.",
        )
    if len(command_id) > 128 or any(char in command_id for char in "\r\n\t"):
        return _reject(
            "MALFORMED",
            "command_id must be 1 to 128 characters without whitespace control codes. "
            "Command rejected.",
        )
    return None


def _joint_arrays_empty(cmd: SeldunCommandData) -> bool:
    return not (cmd.joint_names or cmd.positions or cmd.velocities or cmd.efforts)


def _twist_is_zero(cmd: SeldunCommandData) -> bool:
    return all(abs(value) <= _LIMIT_EPS for value in _twist_values(cmd).values())


def validate_command(
    cmd: SeldunCommandData,
    policy: SafetyPolicy,
    *,
    hardware: HardwareAssessment,
    software_estop_latched: bool,
    measured_positions: Mapping[str, float] | None,
) -> ValidationResult:
    """Validate one command. Accepted motion still needs a transport check."""
    id_error = _check_command_id(cmd.command_id)
    if id_error is not None:
        return id_error
    if cmd.command_type not in _COMMAND_TYPES:
        return _reject(
            "UNKNOWN_COMMAND_TYPE",
            f"command_type '{cmd.command_type}' is unknown. "
            "Use joint_trajectory, cmd_vel, stop, or reset_stop. Command rejected.",
        )

    if cmd.command_type == "stop":
        if not _joint_arrays_empty(cmd) or not _twist_is_zero(cmd) or abs(cmd.time_from_start_sec) > _LIMIT_EPS:
            return _reject(
                "MALFORMED",
                "stop must not include joint arrays, a twist, or a time. Command rejected.",
            )
        return ValidationResult(
            True,
            "OK",
            "Software e-stop latched. This is a software latch in the bridge, "
            "not a hardware emergency stop. Joint and cmd_vel commands stay rejected "
            "until reset_stop.",
        )

    if cmd.command_type == "reset_stop":
        if not _joint_arrays_empty(cmd) or not _twist_is_zero(cmd) or abs(cmd.time_from_start_sec) > _LIMIT_EPS:
            return _reject(
                "MALFORMED",
                "reset_stop must not include joint arrays, a twist, or a time. Command rejected.",
            )
        if not hardware.motion_allowed:
            return _reject(hardware.error_code, hardware.message)
        return ValidationResult(
            True,
            "OK",
            "Software e-stop latch cleared. This does not reset a hardware emergency stop, "
            "and it does not make the robot safe to walk or to drive motors.",
        )

    if not hardware.motion_allowed:
        return _reject(hardware.error_code, hardware.message)
    if software_estop_latched:
        return _reject(
            "SOFTWARE_ESTOP",
            "Software e-stop is latched. Motion command rejected. "
            "Send reset_stop after the cause is understood. "
            "This latch is not a hardware emergency stop.",
        )

    if cmd.command_type == "cmd_vel":
        return _validate_cmd_vel(cmd, policy)
    return _validate_trajectory(cmd, policy, measured_positions)


def _validate_cmd_vel(cmd: SeldunCommandData, policy: SafetyPolicy) -> ValidationResult:
    if not _joint_arrays_empty(cmd) or abs(cmd.time_from_start_sec) > _LIMIT_EPS:
        return _reject(
            "MALFORMED",
            "cmd_vel must not include joint names, positions, velocities, efforts, "
            "or time_from_start_sec. Send joint motion as joint_trajectory. Command rejected.",
        )
    limits = {
        "linear_x": policy.cmd_vel_linear_x_max,
        "linear_y": policy.cmd_vel_linear_y_max,
        "linear_z": policy.cmd_vel_linear_z_max,
        "angular_x": policy.cmd_vel_angular_x_max,
        "angular_y": policy.cmd_vel_angular_y_max,
        "angular_z": policy.cmd_vel_angular_z_max,
    }
    for name, limit in limits.items():
        value = _twist_values(cmd)[name]
        if abs(value) > limit + _LIMIT_EPS:
            return _reject(
                "CMD_VEL_LIMIT",
                f"cmd_vel {name}={value} exceeds the safety cap {limit}. "
                "Command rejected. No Twist was published. "
                "cmd_vel does not make SmartBot II walk.",
            )
    return ValidationResult(
        True,
        "OK",
        "cmd_vel accepted for forwarding on /cmd_vel. "
        "No locomotion controller is loaded, so the robot will not walk.",
    )


def _validate_trajectory(
    cmd: SeldunCommandData,
    policy: SafetyPolicy,
    measured_positions: Mapping[str, float] | None,
) -> ValidationResult:
    if not _twist_is_zero(cmd):
        return _reject(
            "MALFORMED",
            "joint_trajectory must leave every twist field at 0. "
            "Send base velocity as a separate cmd_vel command. Command rejected.",
        )
    if not cmd.joint_names:
        return _reject(
            "MALFORMED",
            "joint_trajectory requires at least one joint. Command rejected.",
        )
    if len(cmd.positions) != len(cmd.joint_names):
        return _reject(
            "LENGTH_MISMATCH",
            "positions length "
            f"{len(cmd.positions)} does not match joint_names length {len(cmd.joint_names)}. "
            "Command rejected.",
        )
    if cmd.velocities and len(cmd.velocities) != len(cmd.joint_names):
        return _reject(
            "LENGTH_MISMATCH",
            "velocities length "
            f"{len(cmd.velocities)} does not match joint_names length {len(cmd.joint_names)}. "
            "Omit velocities or provide one finite value per joint. Command rejected.",
        )
    if cmd.efforts and len(cmd.efforts) != len(cmd.joint_names):
        return _reject(
            "LENGTH_MISMATCH",
            "efforts length "
            f"{len(cmd.efforts)} does not match joint_names length {len(cmd.joint_names)}. "
            "Omit efforts or provide one finite value per joint. Command rejected.",
        )
    if cmd.time_from_start_sec <= 0.0:
        return _reject(
            "TIME_NON_POSITIVE",
            "time_from_start_sec must be greater than 0. Command rejected.",
        )
    if cmd.time_from_start_sec > policy.max_trajectory_duration_sec + _LIMIT_EPS:
        return _reject(
            "TIME_LIMIT",
            "time_from_start_sec "
            f"{cmd.time_from_start_sec} exceeds the safety cap "
            f"{policy.max_trajectory_duration_sec} s. Command rejected.",
        )

    seen: set[str] = set()
    for index, name in enumerate(cmd.joint_names):
        if name in seen:
            return _reject(
                "DUPLICATE_JOINT",
                f"joint '{name}' is repeated. Command rejected.",
            )
        seen.add(name)
        if name not in policy.joints:
            return _reject(
                "UNKNOWN_JOINT",
                f"joint '{name}' is not an actuated SmartBot II joint. Command rejected.",
            )
        limit = policy.joints[name]
        position = cmd.positions[index]
        if position < limit.min_position - _LIMIT_EPS or position > limit.max_position + _LIMIT_EPS:
            return _reject(
                "POSITION_LIMIT",
                f"joint '{name}' position {position} rad is outside the safety range "
                f"[{limit.min_position}, {limit.max_position}] rad. Command rejected.",
            )
        if measured_positions is None:
            reference = 0.0
            reference_note = "the simulated zero pose"
        else:
            if name not in measured_positions or not _finite_number(measured_positions[name]):
                return _reject(
                    "MISSING_JOINT_STATE",
                    f"joint '{name}' has no finite measured position yet. Command rejected.",
                )
            reference = float(measured_positions[name])
            reference_note = "the measured joint position"
        delta = abs(position - reference)
        if delta > policy.max_position_delta_rad + _LIMIT_EPS:
            return _reject(
                "POSITION_DELTA",
                f"joint '{name}' position step {delta} rad from {reference_note} "
                f"exceeds {policy.max_position_delta_rad} rad. Command rejected.",
            )
        if cmd.velocities:
            velocity = cmd.velocities[index]
            if abs(velocity) > limit.max_velocity + _LIMIT_EPS:
                return _reject(
                    "VELOCITY_LIMIT",
                    f"joint '{name}' velocity {velocity} rad/s exceeds the safety cap "
                    f"{limit.max_velocity} rad/s. Command rejected.",
                )
        if cmd.efforts:
            effort = cmd.efforts[index]
            if abs(effort) > limit.max_effort + _LIMIT_EPS:
                return _reject(
                    "EFFORT_LIMIT",
                    f"joint '{name}' effort {effort} N*m exceeds the safety cap "
                    f"{limit.max_effort} N*m. Command rejected.",
                )
    return ValidationResult(
        True,
        "OK",
        "joint_trajectory passed safety checks. "
        "This does not validate walking or physical motor operation.",
    )


def twist_timeout_expired(
    last_command_time_sec: float | None,
    now_sec: float,
    timeout_sec: float,
    nonzero_twist_active: bool,
) -> bool:
    """Return true when a forwarded nonzero cmd_vel should be replaced by zero."""
    if not nonzero_twist_active or last_command_time_sec is None:
        return False
    if timeout_sec < 0.0 or not math.isfinite(now_sec) or not math.isfinite(last_command_time_sec):
        return False
    return (now_sec - last_command_time_sec) > timeout_sec
