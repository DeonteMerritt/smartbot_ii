#!/usr/bin/env python3
"""Parse workspace sources and run the Seldun bridge unit tests.

This script does not need a ROS install. It checks that XML, Xacro, SDF,
SRDF, and YAML files parse, that Python files compile, and that source
files do not contain unfinished-work markers.
"""

from __future__ import annotations

import py_compile
import subprocess
import sys
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
MARKERS = ("TO" + "DO", "FIX" + "ME", "add code " + "here", "lorem ipsum")
SOURCE_SUFFIXES = {
    ".py",
    ".xml",
    ".xacro",
    ".yaml",
    ".yml",
    ".msg",
    ".sdf",
    ".srdf",
    ".cpp",
    ".hpp",
    ".h",
}
XML_SUFFIXES = {".xml", ".xacro", ".sdf", ".srdf"}
YAML_SUFFIXES = {".yaml", ".yml"}


def _iter_sources() -> list[Path]:
    found: list[Path] = []
    roots = [SRC, ROOT / "firmware"]
    for root in roots:
        if not root.exists():
            continue
        for path in root.rglob("*"):
            if not path.is_file():
                continue
            if "__pycache__" in path.parts or path.suffix == ".pyc":
                continue
            if path.name == "CMakeLists.txt" or path.suffix in SOURCE_SUFFIXES:
                found.append(path)
    return found


def _reject_markers(paths: list[Path]) -> None:
    for path in paths:
        text = path.read_text(encoding="utf-8")
        lowered = text.lower()
        for marker in MARKERS:
            if marker.lower() in lowered:
                raise SystemExit(f"{path} contains unfinished marker {marker!r}")


def _parse_xml(paths: list[Path]) -> None:
    for path in paths:
        if path.suffix not in XML_SUFFIXES:
            continue
        try:
            ET.parse(path)
        except ET.ParseError as exc:
            raise SystemExit(f"{path} is not well-formed XML: {exc}") from exc


def _parse_yaml(paths: list[Path]) -> None:
    for path in paths:
        if path.suffix not in YAML_SUFFIXES:
            continue
        yaml.safe_load(path.read_text(encoding="utf-8"))


def _compile_python() -> None:
    for path in SRC.rglob("*.py"):
        if "__pycache__" in path.parts:
            continue
        py_compile.compile(str(path), doraise=True)
    for path in (ROOT / "scripts").glob("*.py"):
        py_compile.compile(str(path), doraise=True)


def _compile_codec() -> None:
    control = SRC / "smartbot_ii_control"
    binary = Path("/tmp/smartbot_ii_test_joint_target_codec")
    compile_cmd = [
        "g++",
        "-std=c++17",
        "-Wall",
        "-Wextra",
        "-Wpedantic",
        f"-I{control / 'include'}",
        str(control / "test" / "test_joint_target_codec.cpp"),
        "-o",
        str(binary),
    ]
    compiled = subprocess.run(compile_cmd, check=False, capture_output=True, text=True)
    if compiled.returncode != 0:
        raise SystemExit(compiled.stderr or compiled.stdout)
    ran = subprocess.run([str(binary)], check=False, capture_output=True, text=True)
    if ran.returncode != 0:
        raise SystemExit(ran.stderr or ran.stdout)
    print(ran.stdout.strip())


def _compile_joint_node() -> None:
    node = ROOT / "firmware" / "smartbot_ii_joint_node"
    binary = Path("/tmp/smartbot_ii_test_joint_node")
    compile_cmd = [
        "g++",
        "-std=c++17",
        "-Wall",
        "-Wextra",
        "-Wpedantic",
        f"-I{node / 'include'}",
        str(node / "src" / "joint_node.cpp"),
        str(node / "test" / "test_joint_node.cpp"),
        "-o",
        str(binary),
    ]
    compiled = subprocess.run(compile_cmd, check=False, capture_output=True, text=True)
    if compiled.returncode != 0:
        raise SystemExit(compiled.stderr or compiled.stdout)
    ran = subprocess.run([str(binary)], check=False, capture_output=True, text=True)
    if ran.returncode != 0:
        raise SystemExit(ran.stderr or ran.stdout)
    print(ran.stdout.strip())


def main() -> None:
    paths = _iter_sources()
    if not paths:
        raise SystemExit(f"No sources found under {SRC}")
    _reject_markers(paths)
    _parse_xml(paths)
    _parse_yaml(paths)
    _compile_python()
    _compile_codec()
    _compile_joint_node()
    suite = unittest.TestSuite()
    for package in sorted(SRC.iterdir()):
        tests = package / "test"
        if tests.is_dir() and any(tests.glob("test_*.py")):
            suite.addTests(unittest.TestLoader().discover(str(tests)))
    result = unittest.TextTestRunner(verbosity=1).run(suite)
    if not result.wasSuccessful():
        raise SystemExit(1)
    print(f"Workspace check passed for {len(paths)} source files.")


if __name__ == "__main__":
    main()
