#!/usr/bin/env python3
"""Refresh config/simulated_parameters.yaml from the Xacro properties.

Run this after changing a simulated number in the Xacro files.
The unit tests fail if the catalog drifts from the Xacro.
"""

from __future__ import annotations

import re
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
DESC = ROOT / "src" / "smartbot_ii_description"
PROP_RE = re.compile(r'<xacro:property\s+name="([^"]+)"\s+value="([^"]+)"\s*/>')

NOT_A_CALIPER_MEASUREMENT = {
    "position_proportional_gain": (
        "1",
        "Untuned Gazebo position-loop gain. It is not a measured motor gain. "
        "Keep it at or below 1 until the simulator is identified.",
    ),
    "ground_clearance": (
        "m",
        "Extra sole clearance used only so the welded-pelvis spawn does not start in the ground. "
        "It is not a measured robot dimension.",
    ),
    "pelvis_height_above_ground": (
        "m",
        "Derived spawn height: leg stack plus ground_clearance. Recompute it when lengths change. "
        "It is not an independent measurement.",
    ),
    "foot_kp": (
        "N/m",
        "Untuned contact stiffness guess for the primitive feet. Replace it only after contact tests.",
    ),
    "foot_kd": (
        "N*s/m",
        "Untuned contact damping guess for the primitive feet. Replace it only after contact tests.",
    ),
}

LIMIT_UNITS = {
    "_lower": "rad",
    "_upper": "rad",
    "_velocity": "rad/s",
    "_effort": "N*m",
    "_damping": "N*m*s/rad",
    "_friction": "N*m",
}


def _classify(name: str) -> tuple[bool, str, str]:
    if name.startswith("head_visor") or name.startswith("pelvis_marker"):
        return (
            False,
            "m",
            "Primitive visual stand-in. Remove it when the link mesh is installed. "
            "It is not a part measurement.",
        )
    if name in NOT_A_CALIPER_MEASUREMENT:
        unit, notes = NOT_A_CALIPER_MEASUREMENT[name]
        return False, unit, notes
    if name.startswith("mass_"):
        return (
            True,
            "kg",
            "Simulated link mass. REPLACE_WITH_PHYSICAL_MEASUREMENT.",
        )
    if name == "mechanical_reduction":
        return (
            True,
            "1",
            "Simulated gearbox ratio. 1.0 means joint angle equals motor angle. "
            "REPLACE_WITH_PHYSICAL_MEASUREMENT.",
        )
    if name == "foot_mu":
        return (
            True,
            "1",
            "Simulated foot friction coefficient. REPLACE_WITH_PHYSICAL_MEASUREMENT.",
        )
    for suffix, unit in LIMIT_UNITS.items():
        if name.endswith(suffix):
            return (
                True,
                unit,
                f"Simulated joint {suffix[1:]}. REPLACE_WITH_PHYSICAL_MEASUREMENT.",
            )
    geometry_suffixes = (
        "_radius",
        "_length",
        "_offset",
        "_drop",
        "_outboard",
        "_x",
        "_y",
        "_z",
    )
    for suffix in geometry_suffixes:
        if name.endswith(suffix):
            return (
                True,
                "m",
                "Simulated length. REPLACE_WITH_PHYSICAL_MEASUREMENT.",
            )
    raise SystemExit(f"No catalog rule for Xacro property '{name}'.")


def main() -> None:
    values: dict[str, str] = {}
    for path in (
        DESC / "urdf/smartbot_ii.constants.xacro",
        DESC / "urdf/smartbot_ii.limits.xacro",
        DESC / "urdf/smartbot_ii.gazebo.xacro",
    ):
        for name, raw in PROP_RE.findall(path.read_text(encoding="utf-8")):
            if name == "pi":
                continue
            values[name] = raw
    parameters = {}
    for name in sorted(values):
        replace, unit, notes = _classify(name)
        parameters[name] = {
            "value": float(values[name]),
            "unit": unit,
            "replace_with_physical_measurement": replace,
            "notes": notes,
        }
    document = {
        "robot": "smartbot_ii",
        "purpose": (
            "Catalog of every simulated Xacro numeric property. "
            "True on replace_with_physical_measurement means the number must be "
            "replaced by a measurement or a hardware datasheet value before "
            "physical use. False means the number is a simulator setting or a "
            "primitive drawing aid, and it still must not be treated as measured."
        ),
        "parameters": parameters,
    }
    target = DESC / "config/simulated_parameters.yaml"
    header = (
        "# Simulated SmartBot II parameters extracted from the Xacro files.\n"
        "# Regenerate with: python3 scripts/render_simulated_catalog.py\n"
        "# Do not hand-edit values here without editing the Xacro property too.\n\n"
    )
    body = yaml.safe_dump(document, sort_keys=False, width=100)
    target.write_text(header + body, encoding="utf-8")
    print(f"Wrote {len(parameters)} parameters to {target}")


if __name__ == "__main__":
    main()
