// Copyright 2026 SmartBot II Maintainers
// Licensed under the Apache License, Version 2.0.

#ifndef SMARTBOT_JOINT__CAN_PROTOCOL_HPP_
#define SMARTBOT_JOINT__CAN_PROTOCOL_HPP_

#include <cstdint>
#include <cstring>

// Limb-bus CAN map for one SmartBot II joint node.
// Node 1 is neck_yaw_joint. Node 22 is right_ankle_roll_joint.
// node_id = joint_id + 1, where joint_id is the index in
// smartbot_ii_control::kActuatedJoints.
//
// Standard 11-bit frames, little-endian IEEE-754 binary32, same byte order
// as JointTargetPacket on the Pi. Bitrate is a bus decision and is not
// validated here. 500 kbit/s is the compiled default.
//
// This protocol does not remove motor power. A hardware contactor is still
// required before a person is in reach of the limb.

namespace smartbot_joint
{

inline constexpr uint8_t kNodeCount = 22;
inline constexpr uint8_t kNodeIdMin = 1;
inline constexpr uint8_t kNodeIdMax = 22;

inline constexpr uint16_t kHeartbeatId = 0x080;
inline constexpr uint16_t kResetIdBase = 0x180;
inline constexpr uint16_t kPositionIdBase = 0x200;
inline constexpr uint16_t kStatusIdBase = 0x300;

inline constexpr uint32_t kHeartbeatTimeoutUs = 100000;
inline constexpr uint32_t kDefaultCanBitrate = 500000;

inline constexpr uint8_t kResetMagic = 0xA5;

// Status ID 0x300 + node_id, DLC 8.
// [0..3] position radians, float32 little-endian
// [4..5] velocity, int16 little-endian, 0.001 rad/s per count
// [6]    temperature, int8 Celsius. -128 means no sensor is fitted.
// [7]    fault flags. Encoder, overtemperature, and overcurrent latch the Pi shield.
inline constexpr uint8_t kStatusDlc = 8;
inline constexpr float kVelocityScale = 0.001f;
inline constexpr int8_t kTemperatureUnavailable = -128;
inline constexpr uint8_t kFaultEncoder = 0x01;
inline constexpr uint8_t kFaultOvertemperature = 0x02;
inline constexpr uint8_t kFaultOvercurrent = 0x04;
inline constexpr uint8_t kFaultHeartbeat = 0x08;

struct CanFrame
{
  uint16_t id;
  uint8_t dlc;
  uint8_t data[8];
};

inline constexpr uint16_t position_id(uint8_t node_id) noexcept
{
  return static_cast<uint16_t>(kPositionIdBase + node_id);
}

inline constexpr uint16_t reset_id(uint8_t node_id) noexcept
{
  return static_cast<uint16_t>(kResetIdBase + node_id);
}

inline constexpr uint16_t status_id(uint8_t node_id) noexcept
{
  return static_cast<uint16_t>(kStatusIdBase + node_id);
}

inline bool node_id_valid(uint8_t node_id) noexcept
{
  return node_id >= kNodeIdMin && node_id <= kNodeIdMax;
}

// Hardware acceptance list for this node: heartbeat, its position frame, its reset frame.
inline void hardware_filter_ids(uint8_t node_id, uint16_t out[3]) noexcept
{
  out[0] = kHeartbeatId;
  out[1] = position_id(node_id);
  out[2] = reset_id(node_id);
}

inline bool finite_f32_bits(uint32_t bits) noexcept
{
  return ((bits >> 23) & 0xFFu) != 0xFFu;
}

inline float f32_from_le(const uint8_t data[4]) noexcept
{
  uint32_t bits = static_cast<uint32_t>(data[0]) |
    (static_cast<uint32_t>(data[1]) << 8) |
    (static_cast<uint32_t>(data[2]) << 16) |
    (static_cast<uint32_t>(data[3]) << 24);
  float value = 0.0f;
  std::memcpy(&value, &bits, sizeof(value));
  return value;
}

inline void f32_to_le(float value, uint8_t data[4]) noexcept
{
  uint32_t bits = 0;
  std::memcpy(&bits, &value, sizeof(bits));
  data[0] = static_cast<uint8_t>(bits);
  data[1] = static_cast<uint8_t>(bits >> 8);
  data[2] = static_cast<uint8_t>(bits >> 16);
  data[3] = static_cast<uint8_t>(bits >> 24);
}

enum class CanParse : uint8_t
{
  Ignore = 0,
  Heartbeat,
  Position,
  Reset
};

// ISR-safe. No allocation. Rejects every id except the three filter ids.
inline CanParse parse_can_frame(
  const CanFrame & frame, uint8_t node_id, float & position_rad) noexcept
{
  if (!node_id_valid(node_id) || frame.id > 0x7FF) {
    return CanParse::Ignore;
  }
  if (frame.id == kHeartbeatId && frame.dlc >= 1) {
    return CanParse::Heartbeat;
  }
  if (frame.id == reset_id(node_id) && frame.dlc >= 2 && frame.data[0] == node_id &&
    frame.data[1] == kResetMagic)
  {
    return CanParse::Reset;
  }
  if (frame.id == position_id(node_id) && frame.dlc >= 4) {
    uint32_t bits = static_cast<uint32_t>(frame.data[0]) |
      (static_cast<uint32_t>(frame.data[1]) << 8) |
      (static_cast<uint32_t>(frame.data[2]) << 16) |
      (static_cast<uint32_t>(frame.data[3]) << 24);
    if (!finite_f32_bits(bits)) {
      return CanParse::Ignore;
    }
    position_rad = f32_from_le(frame.data);
    return CanParse::Position;
  }
  return CanParse::Ignore;
}

}  // namespace smartbot_joint

#endif  // SMARTBOT_JOINT__CAN_PROTOCOL_HPP_
