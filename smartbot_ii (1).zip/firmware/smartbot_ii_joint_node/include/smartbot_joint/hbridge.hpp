// Copyright 2026 SmartBot II Maintainers
// Licensed under the Apache License, Version 2.0.

#ifndef SMARTBOT_JOINT__HBRIDGE_HPP_
#define SMARTBOT_JOINT__HBRIDGE_HPP_

#include <cstdint>

// DRV8870 / DRV8871 / DRV8873 style dual inputs.
// in1 PWM and in2 low: one direction.
// in1 low and in2 PWM: the other direction.
// both high: slow-decay brake, used inside the deadband while enabled.
// both low and driver_enabled false: inputs off and nSLEEP low (shutdown).
// nSLEEP low isolates the gate driver. It is not a safety contactor. A FET
// that fails short can still apply torque.

namespace smartbot_joint
{

struct BridgeCommand
{
  uint16_t in1_compare;
  uint16_t in2_compare;
  bool driver_enabled;
  float signed_duty;
};

inline constexpr float kPwmDeadband = 0.02f;

inline BridgeCommand bridge_safe_off() noexcept
{
  BridgeCommand command{};
  command.in1_compare = 0;
  command.in2_compare = 0;
  command.driver_enabled = false;
  command.signed_duty = 0.0f;
  return command;
}

inline BridgeCommand bridge_from_duty(float duty, uint16_t pwm_period, bool enable) noexcept
{
  if (!enable || pwm_period == 0) {
    return bridge_safe_off();
  }
  BridgeCommand command{};
  command.driver_enabled = true;
  float magnitude = duty >= 0.0f ? duty : -duty;
  if (magnitude < kPwmDeadband) {
    command.in1_compare = pwm_period;
    command.in2_compare = pwm_period;
    command.signed_duty = 0.0f;
    return command;
  }
  if (magnitude > 1.0f) {
    magnitude = 1.0f;
  }
  const uint16_t compare = static_cast<uint16_t>(magnitude * static_cast<float>(pwm_period));
  if (duty > 0.0f) {
    command.in1_compare = compare;
    command.in2_compare = 0;
    command.signed_duty = magnitude;
  } else {
    command.in1_compare = 0;
    command.in2_compare = compare;
    command.signed_duty = -magnitude;
  }
  return command;
}

}  // namespace smartbot_joint

#endif  // SMARTBOT_JOINT__HBRIDGE_HPP_
