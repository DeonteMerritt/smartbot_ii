// Copyright 2026 SmartBot II Maintainers
// Licensed under the Apache License, Version 2.0.

#ifndef SMARTBOT_JOINT__JOINT_NODE_HPP_
#define SMARTBOT_JOINT__JOINT_NODE_HPP_

#include <cstdint>

#include "smartbot_joint/as5600.hpp"
#include "smartbot_joint/can_protocol.hpp"
#include "smartbot_joint/hbridge.hpp"
#include "smartbot_joint/pid.hpp"

// Interrupt-driven joint actuator.
// CAN RX ISR only latches a frame. The 1 kHz hardware-timer ISR runs the PID
// and writes the bridge command. I2C completion ISR latches an AS5600 sample.
// None of those paths allocate.
//
// Stops and gains are the simulated safety table. REPLACE_WITH_PHYSICAL_MEASUREMENT.
// A latched fault forces both PWM compares to 0 and driver_enabled false.
// Clearing a fault does not validate the motor, the gearbox, or the wiring.

namespace smartbot_joint
{

enum class FaultCode : uint8_t
{
  None = 0,
  HeartbeatTimeout = 1,
  EncoderBoundary = 2,
  EncoderMagnet = 3,
  EncoderTimeout = 4,
  Disarmed = 5
};

struct JointStop
{
  const char * name;
  float min_rad;
  float max_rad;
  float max_velocity_rad_s;
};

// Copied from safety_limits.yaml. Simulated. Not mechanical end stops.
inline constexpr JointStop kSimulatedStops[kNodeCount] = {
  {"neck_yaw_joint", -0.9f, 0.9f, 0.96f},
  {"neck_pitch_joint", -0.36f, 0.54f, 0.96f},
  {"left_shoulder_pitch_joint", -0.36f, 1.35f, 1.2f},
  {"left_shoulder_roll_joint", -0.18f, 1.26f, 1.2f},
  {"left_elbow_joint", 0.0f, 1.89f, 1.2f},
  {"left_wrist_joint", -0.72f, 0.72f, 1.2f},
  {"right_shoulder_pitch_joint", -0.36f, 1.35f, 1.2f},
  {"right_shoulder_roll_joint", -1.26f, 0.18f, 1.2f},
  {"right_elbow_joint", 0.0f, 1.89f, 1.2f},
  {"right_wrist_joint", -0.72f, 0.72f, 1.2f},
  {"left_hip_yaw_joint", -0.45f, 0.45f, 0.96f},
  {"left_hip_roll_joint", -0.22f, 0.40f, 0.96f},
  {"left_hip_pitch_joint", -0.63f, 0.99f, 0.96f},
  {"left_knee_joint", 0.0f, 1.8f, 0.96f},
  {"left_ankle_pitch_joint", -0.45f, 0.45f, 0.96f},
  {"left_ankle_roll_joint", -0.27f, 0.27f, 0.96f},
  {"right_hip_yaw_joint", -0.45f, 0.45f, 0.96f},
  {"right_hip_roll_joint", -0.40f, 0.22f, 0.96f},
  {"right_hip_pitch_joint", -0.63f, 0.99f, 0.96f},
  {"right_knee_joint", 0.0f, 1.8f, 0.96f},
  {"right_ankle_pitch_joint", -0.45f, 0.45f, 0.96f},
  {"right_ankle_roll_joint", -0.27f, 0.27f, 0.96f},
};

struct JointConfig
{
  uint8_t node_id;
  // REPLACE_WITH_PHYSICAL_MEASUREMENT.
  float zero_offset_rad;
  int8_t direction;
  // REPLACE_WITH_PHYSICAL_MEASUREMENT. 1.0 means the magnet is on the joint, not the motor shaft.
  float output_radians_per_encoder_radian;
  uint16_t pwm_period_counts;
  PidGains gains;
};

struct TickResult
{
  BridgeCommand bridge;
  FaultCode fault;
  float measured_rad;
  float target_rad;
  bool start_encoder_read;
  bool send_status;
  CanFrame status;
};

class JointNode
{
public:
  JointNode() = default;

  bool init(const JointConfig & config, uint32_t now_us) noexcept;
  void on_can_rx_isr(const CanFrame & frame, uint32_t now_us) noexcept;
  void on_encoder_sample_isr(const EncoderSample & sample) noexcept;
  TickResult on_control_timer_isr(uint32_t now_us) noexcept;

  uint8_t node_id() const noexcept { return node_id_; }
  FaultCode fault() const noexcept { return fault_; }
  const JointStop & stop() const noexcept { return kSimulatedStops[node_id_ - 1]; }

private:
  void latch(FaultCode code) noexcept;
  bool try_clear_latch(uint32_t now_us) noexcept;
  void write_status(TickResult & result) noexcept;
  float clamped_target() const noexcept;

  uint8_t node_id_{1};
  float zero_offset_rad_{0.0f};
  int8_t direction_{1};
  float output_scale_{1.0f};
  uint16_t pwm_period_{1000};
  PidGains gains_{kUnvalidatedPidGains};
  PidState pid_{};

  float commanded_rad_{0.0f};
  float slewed_rad_{0.0f};
  bool have_command_{false};
  bool heartbeat_seen_{false};
  uint32_t last_heartbeat_us_{0};
  uint32_t boot_us_{0};
  bool clear_request_{false};

  EncoderSample sample_{};
  bool have_sample_{false};
  float measured_rad_{0.0f};
  float velocity_rad_s_{0.0f};
  float previous_measured_rad_{0.0f};
  bool have_velocity_sample_{false};
  int8_t temperature_c_{kTemperatureUnavailable};
  bool measurement_valid_{false};

  FaultCode fault_{FaultCode::Disarmed};
  uint32_t last_tick_us_{0};
  uint16_t tick_count_{0};
  bool encoder_read_open_{false};
};

}  // namespace smartbot_joint

#endif  // SMARTBOT_JOINT__JOINT_NODE_HPP_
