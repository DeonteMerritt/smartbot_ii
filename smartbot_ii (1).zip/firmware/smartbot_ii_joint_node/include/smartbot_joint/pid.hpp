// Copyright 2026 SmartBot II Maintainers
// Licensed under the Apache License, Version 2.0.

#ifndef SMARTBOT_JOINT__PID_HPP_
#define SMARTBOT_JOINT__PID_HPP_

#include <cstdint>

// Discrete position PID. Derivative is taken on the measurement so a step
// in the CAN target does not dump the full D term into the bridge.
// Gains below are unvalidated stand-ins. REPLACE_WITH_PHYSICAL_MEASUREMENT
// after a current-limited bench test. They are not safe motor tunings.

namespace smartbot_joint
{

struct PidGains
{
  float kp;
  float ki;
  float kd;
  float integrator_limit;
  float output_limit;
};

// Output limit 0.25 means 25% of the PWM period until the drive is identified.
inline constexpr PidGains kUnvalidatedPidGains{1.5f, 0.2f, 0.02f, 0.15f, 0.25f};

struct PidState
{
  float integrator;
  float previous_measurement;
  bool has_previous;
};

inline void pid_reset(PidState & state) noexcept
{
  state.integrator = 0.0f;
  state.previous_measurement = 0.0f;
  state.has_previous = false;
}

inline float pid_step(
  PidState & state, const PidGains & gains, float target, float measurement, float dt_s) noexcept
{
  if (!(dt_s > 0.0f) || dt_s > 0.05f) {
    return 0.0f;
  }
  const float error = target - measurement;
  state.integrator += gains.ki * error * dt_s;
  if (state.integrator > gains.integrator_limit) {
    state.integrator = gains.integrator_limit;
  } else if (state.integrator < -gains.integrator_limit) {
    state.integrator = -gains.integrator_limit;
  }
  float derivative = 0.0f;
  if (state.has_previous) {
    derivative = -gains.kd * (measurement - state.previous_measurement) / dt_s;
  }
  state.previous_measurement = measurement;
  state.has_previous = true;
  float output = (gains.kp * error) + state.integrator + derivative;
  if (output > gains.output_limit) {
    output = gains.output_limit;
  } else if (output < -gains.output_limit) {
    output = -gains.output_limit;
  }
  return output;
}

}  // namespace smartbot_joint

#endif  // SMARTBOT_JOINT__PID_HPP_
