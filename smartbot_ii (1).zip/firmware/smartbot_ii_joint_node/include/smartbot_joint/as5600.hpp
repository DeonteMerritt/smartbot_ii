// Copyright 2026 SmartBot II Maintainers
// Licensed under the Apache License, Version 2.0.

#ifndef SMARTBOT_JOINT__AS5600_HPP_
#define SMARTBOT_JOINT__AS5600_HPP_

#include <cstdint>

// AMS AS5600 12-bit magnetic rotary encoder.
// I2C address 0x36. RAW ANGLE is registers 0x0C (high) then 0x0D (low).
// STATUS 0x0B bit MD (0x20) is set when a magnet is detected.
// MH/ML report the magnet field strength. A missing magnet is treated as a
// sensing breakdown. The zero offset and the sign are physical calibrations.

namespace smartbot_joint
{

inline constexpr uint8_t kAs5600Address = 0x36;
inline constexpr uint8_t kAs5600RegStatus = 0x0B;
inline constexpr uint8_t kAs5600RegRawAngle = 0x0C;
inline constexpr uint8_t kAs5600StatusMagnetHigh = 0x08;
inline constexpr uint8_t kAs5600StatusMagnetLow = 0x10;
inline constexpr uint8_t kAs5600StatusMagnetDetected = 0x20;
inline constexpr uint16_t kAs5600Counts = 4096;
inline constexpr float kTwoPi = 6.28318530718f;
inline constexpr float kPi = 3.14159265359f;

// A sample older than this is not usable for PWM. Firmware policy, not a datasheet limit.
inline constexpr uint32_t kEncoderMaxAgeUs = 10000;

struct EncoderSample
{
  uint16_t raw_counts;
  uint8_t status;
  uint32_t timestamp_us;
  bool i2c_ok;
};

inline uint16_t as5600_raw_from_registers(uint8_t high, uint8_t low) noexcept
{
  return static_cast<uint16_t>(((static_cast<uint16_t>(high) << 8) | low) & 0x0FFF);
}

inline float as5600_counts_to_rad(uint16_t raw_counts) noexcept
{
  const uint16_t counts = static_cast<uint16_t>(raw_counts & 0x0FFF);
  return (static_cast<float>(counts) * kTwoPi) / static_cast<float>(kAs5600Counts);
}

// Map the magnet angle into the joint frame. direction is +1 or -1.
// zero_offset_rad is the magnet angle, in 0..2π, at the joint zero pose.
// REPLACE_WITH_PHYSICAL_MEASUREMENT: both arguments.
inline float as5600_joint_rad(uint16_t raw_counts, float zero_offset_rad, int8_t direction) noexcept
{
  float delta = as5600_counts_to_rad(raw_counts) - zero_offset_rad;
  if (delta > kPi) {
    delta -= kTwoPi;
  } else if (delta < -kPi) {
    delta += kTwoPi;
  }
  const float sign = direction < 0 ? -1.0f : 1.0f;
  return sign * delta;
}

inline bool as5600_magnet_detected(uint8_t status) noexcept
{
  return (status & kAs5600StatusMagnetDetected) != 0;
}

}  // namespace smartbot_joint

#endif  // SMARTBOT_JOINT__AS5600_HPP_
