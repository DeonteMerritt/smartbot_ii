// Copyright 2026 SmartBot II Maintainers
// Licensed under the Apache License, Version 2.0.

// ESP-IDF port for one SmartBot II joint node.
// Build with SMARTBOT_II_ESP32. Pins are the unvalidated dev-module map.
// REPLACE_WITH_BOARD_PINOUT. TWAI is the ESP32 CAN controller.
// LEDC produces the two PWM gate lines. A GPTimer is the 1 kHz control ISR
// and the microsecond time base.

#include "smartbot_joint/joint_node.hpp"
#include "board_pins.hpp"

#if defined(SMARTBOT_II_ESP32)

#include "driver/gpio.h"
#include "driver/i2c.h"
#include "driver/ledc.h"
#include "driver/twai.h"
#include "esp_timer.h"

namespace smartbot_joint
{
namespace
{

JointNode g_node;
bool g_started = false;

uint32_t time_us()
{
  return static_cast<uint32_t>(esp_timer_get_time());
}

void apply_bridge(const BridgeCommand & command)
{
  const Esp32PinMap & pins = kUnvalidatedEsp32Pins;
  const uint32_t duty_max = (1u << 10) - 1u;
  const uint32_t in1 = (static_cast<uint32_t>(command.in1_compare) * duty_max) / kPwmPeriodCounts;
  const uint32_t in2 = (static_cast<uint32_t>(command.in2_compare) * duty_max) / kPwmPeriodCounts;
  ledc_set_duty(LEDC_HIGH_SPEED_MODE, LEDC_CHANNEL_0, command.driver_enabled ? in1 : 0);
  ledc_set_duty(LEDC_HIGH_SPEED_MODE, LEDC_CHANNEL_1, command.driver_enabled ? in2 : 0);
  ledc_update_duty(LEDC_HIGH_SPEED_MODE, LEDC_CHANNEL_0);
  ledc_update_duty(LEDC_HIGH_SPEED_MODE, LEDC_CHANNEL_1);
  gpio_set_level(static_cast<gpio_num_t>(pins.sleep_gpio), command.driver_enabled ? 1 : 0);
}

void IRAM_ATTR on_control_timer(void *)
{
  if (!g_started) {
    apply_bridge(bridge_safe_off());
    return;
  }
  const TickResult tick = g_node.on_control_timer_isr(time_us());
  apply_bridge(tick.bridge);
  if (tick.send_status) {
    twai_message_t message{};
    message.identifier = tick.status.id;
    message.data_length_code = tick.status.dlc;
    for (uint8_t i = 0; i < tick.status.dlc; ++i) {
      message.data[i] = tick.status.data[i];
    }
    twai_transmit(&message, 0);
  }
}

}  // namespace

bool esp32_joint_start(uint8_t node_id)
{
  const Esp32PinMap & pins = kUnvalidatedEsp32Pins;
  gpio_config_t sleep_pin{};
  sleep_pin.pin_bit_mask = 1ULL << pins.sleep_gpio;
  sleep_pin.mode = GPIO_MODE_OUTPUT;
  gpio_config(&sleep_pin);
  gpio_set_level(static_cast<gpio_num_t>(pins.sleep_gpio), 0);

  ledc_timer_config_t timer{};
  timer.speed_mode = LEDC_HIGH_SPEED_MODE;
  timer.timer_num = LEDC_TIMER_0;
  timer.duty_resolution = LEDC_TIMER_10_BIT;
  timer.freq_hz = kPwmCarrierHz;
  timer.clk_cfg = LEDC_AUTO_CLK;
  ledc_timer_config(&timer);
  ledc_channel_config_t in1{};
  in1.gpio_num = pins.in1_gpio;
  in1.speed_mode = LEDC_HIGH_SPEED_MODE;
  in1.channel = LEDC_CHANNEL_0;
  in1.timer_sel = LEDC_TIMER_0;
  in1.duty = 0;
  ledc_channel_config(&in1);
  ledc_channel_config_t in2 = in1;
  in2.gpio_num = pins.in2_gpio;
  in2.channel = LEDC_CHANNEL_1;
  ledc_channel_config(&in2);

  i2c_config_t i2c{};
  i2c.mode = I2C_MODE_MASTER;
  i2c.sda_io_num = pins.i2c_sda_gpio;
  i2c.scl_io_num = pins.i2c_scl_gpio;
  i2c.sda_pullup_en = GPIO_PULLUP_ENABLE;
  i2c.scl_pullup_en = GPIO_PULLUP_ENABLE;
  i2c.master.clk_speed = kI2cHz;
  i2c_param_config(I2C_NUM_0, &i2c);
  i2c_driver_install(I2C_NUM_0, I2C_MODE_MASTER, 0, 0, 0);

  twai_general_config_t general = TWAI_GENERAL_CONFIG_DEFAULT(
    static_cast<gpio_num_t>(pins.can_tx_gpio), static_cast<gpio_num_t>(pins.can_rx_gpio),
    TWAI_MODE_NORMAL);
  twai_timing_config_t timing = TWAI_TIMING_CONFIG_500KBITS();
  twai_filter_config_t filter = TWAI_FILTER_CONFIG_ACCEPT_ALL();
  twai_driver_install(&general, &timing, &filter);
  twai_start();

  JointConfig config{};
  config.node_id = node_id;
  config.zero_offset_rad = 0.0f;
  config.direction = 1;
  config.output_radians_per_encoder_radian = 1.0f;
  config.pwm_period_counts = kPwmPeriodCounts;
  config.gains = kUnvalidatedPidGains;
  if (!g_node.init(config, time_us())) {
    apply_bridge(bridge_safe_off());
    return false;
  }
  apply_bridge(bridge_safe_off());
  g_started = true;

  const esp_timer_create_args_t args = {
    &on_control_timer, nullptr, ESP_TIMER_TASK, "smartbot_joint"};
  esp_timer_handle_t timer = nullptr;
  esp_timer_create(&args, &timer);
  esp_timer_start_periodic(timer, 1000000 / kControlLoopHz);
  return true;
}

void esp32_poll_can_and_encoder()
{
  // Called from a high-priority task. The control timer stays the PWM writer.
  twai_message_t message{};
  while (twai_receive(&message, 0) == ESP_OK) {
    CanFrame frame{};
    frame.id = static_cast<uint16_t>(message.identifier);
    frame.dlc = message.data_length_code > 8 ? 8 : message.data_length_code;
    for (uint8_t i = 0; i < frame.dlc; ++i) {
      frame.data[i] = message.data[i];
    }
    g_node.on_can_rx_isr(frame, time_us());
  }

  uint8_t angle_reg = kAs5600RegStatus;
  uint8_t raw[3] = {0, 0, 0};
  const esp_err_t angle = i2c_master_write_read_device(
    I2C_NUM_0, kAs5600Address, &angle_reg, 1, raw, 3, 2);
  const uint8_t status = raw[0];
  const esp_err_t status_result = angle;
  EncoderSample sample{};
  sample.raw_counts = as5600_raw_from_registers(raw[1], raw[2]);
  sample.status = status;
  sample.timestamp_us = time_us();
  sample.i2c_ok = angle == ESP_OK && status_result == ESP_OK;
  g_node.on_encoder_sample_isr(sample);
}

}  // namespace smartbot_joint

#endif  // SMARTBOT_II_ESP32
