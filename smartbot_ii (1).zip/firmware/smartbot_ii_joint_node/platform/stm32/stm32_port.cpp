// Copyright 2026 SmartBot II Maintainers
// Licensed under the Apache License, Version 2.0.

// STM32Cube HAL port for one SmartBot II joint node.
// Compile this file in the CubeIDE project with SMARTBOT_II_STM32 defined,
// after CubeMX has created the CAN, I2C, and timer handles named below.
// Pins are the unvalidated map in board_pins.hpp. REPLACE_WITH_BOARD_PINOUT.
//
// Timer roles:
//   htim_pwm       20 kHz carrier, two channels, IN1 and IN2 compares
//   htim_control   1 kHz update interrupt, runs the PID
//   htim_timebase  free-running 1 MHz counter, the microsecond clock

#include "smartbot_joint/joint_node.hpp"
#include "board_pins.hpp"

#if defined(SMARTBOT_II_STM32)

#include "main.h"

extern CAN_HandleTypeDef hcan;
extern I2C_HandleTypeDef hi2c1;
extern TIM_HandleTypeDef htim_pwm;
extern TIM_HandleTypeDef htim_control;
extern TIM_HandleTypeDef htim_timebase;

namespace smartbot_joint
{
namespace
{

JointNode g_node;
uint8_t g_i2c_raw[3] = {0, 0, 0};
bool g_started = false;

GPIO_TypeDef * gpio_port(char letter)
{
  if (letter == 'A') {
    return GPIOA;
  }
  if (letter == 'B') {
    return GPIOB;
  }
  if (letter == 'C') {
    return GPIOC;
  }
  return GPIOA;
}

uint32_t time_us()
{
  return __HAL_TIM_GET_COUNTER(&htim_timebase);
}

void apply_bridge(const BridgeCommand & command)
{
  __HAL_TIM_SET_COMPARE(&htim_pwm, TIM_CHANNEL_1, command.in1_compare);
  __HAL_TIM_SET_COMPARE(&htim_pwm, TIM_CHANNEL_2, command.in2_compare);
  const Stm32PinMap & pins = kUnvalidatedStm32Pins;
  HAL_GPIO_WritePin(
    gpio_port(pins.sleep_port), static_cast<uint16_t>(1u << pins.sleep_pin),
    command.driver_enabled ? GPIO_PIN_SET : GPIO_PIN_RESET);
}

void configure_can_filter(uint8_t node_id)
{
  uint16_t ids[3] = {0, 0, 0};
  hardware_filter_ids(node_id, ids);
  CAN_FilterTypeDef filter{};
  filter.FilterBank = 0;
  filter.FilterMode = CAN_FILTERMODE_IDLIST;
  filter.FilterScale = CAN_FILTERSCALE_16BIT;
  filter.FilterFIFOAssignment = CAN_FILTER_FIFO0;
  filter.FilterActivation = ENABLE;
  filter.FilterIdHigh = static_cast<uint16_t>(ids[0] << 5);
  filter.FilterIdLow = static_cast<uint16_t>(ids[1] << 5);
  filter.FilterMaskIdHigh = static_cast<uint16_t>(ids[2] << 5);
  filter.FilterMaskIdLow = 0;
  HAL_CAN_ConfigFilter(&hcan, &filter);
}

}  // namespace

bool stm32_joint_start(uint8_t node_id)
{
  JointConfig config{};
  config.node_id = node_id;
  config.zero_offset_rad = 0.0f;
  config.direction = 1;
  config.output_radians_per_encoder_radian = 1.0f;
  config.pwm_period_counts = kPwmPeriodCounts;
  config.gains = kUnvalidatedPidGains;
  if (!g_node.init(config, time_us())) {
    apply_bridge(bridge_safe_off());
    return false;
  }
  configure_can_filter(node_id);
  HAL_CAN_Start(&hcan);
  HAL_CAN_ActivateNotification(&hcan, CAN_IT_RX_FIFO0_MSG_PENDING);
  HAL_TIM_PWM_Start(&htim_pwm, TIM_CHANNEL_1);
  HAL_TIM_PWM_Start(&htim_pwm, TIM_CHANNEL_2);
  HAL_TIM_Base_Start(&htim_timebase);
  apply_bridge(bridge_safe_off());
  g_started = true;
  HAL_TIM_Base_Start_IT(&htim_control);
  return true;
}

void stm32_on_can_rx()
{
  CAN_RxHeaderTypeDef header{};
  uint8_t data[8] = {0, 0, 0, 0, 0, 0, 0, 0};
  if (HAL_CAN_GetRxMessage(&hcan, CAN_RX_FIFO0, &header, data) != HAL_OK) {
    return;
  }
  if (header.IDE != CAN_ID_STD) {
    return;
  }
  CanFrame frame{};
  frame.id = static_cast<uint16_t>(header.StdId);
  frame.dlc = static_cast<uint8_t>(header.DLC > 8 ? 8 : header.DLC);
  for (uint8_t i = 0; i < frame.dlc; ++i) {
    frame.data[i] = data[i];
  }
  g_node.on_can_rx_isr(frame, time_us());
}

void stm32_on_control_timer()
{
  if (!g_started) {
    apply_bridge(bridge_safe_off());
    return;
  }
  const TickResult tick = g_node.on_control_timer_isr(time_us());
  apply_bridge(tick.bridge);
  if (tick.start_encoder_read) {
    HAL_I2C_Mem_Read_IT(
      &hi2c1, static_cast<uint16_t>(kAs5600Address << 1), kAs5600RegStatus,
      I2C_MEMADD_SIZE_8BIT, g_i2c_raw, 3);
  }
  if (tick.send_status) {
    CAN_TxHeaderTypeDef tx{};
    tx.StdId = tick.status.id;
    tx.IDE = CAN_ID_STD;
    tx.RTR = CAN_RTR_DATA;
    tx.DLC = tick.status.dlc;
    uint32_t mailbox = 0;
    HAL_CAN_AddTxMessage(&hcan, &tx, const_cast<uint8_t *>(tick.status.data), &mailbox);
  }
}

void stm32_on_i2c_rx_done()
{
  EncoderSample sample{};
  sample.status = g_i2c_raw[0];
  sample.raw_counts = as5600_raw_from_registers(g_i2c_raw[1], g_i2c_raw[2]);
  sample.timestamp_us = time_us();
  sample.i2c_ok = true;
  g_node.on_encoder_sample_isr(sample);
}

void stm32_on_i2c_error()
{
  EncoderSample sample{};
  sample.timestamp_us = time_us();
  sample.i2c_ok = false;
  g_node.on_encoder_sample_isr(sample);
}

}  // namespace smartbot_joint

extern "C" void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef * hcan_cb)
{
  if (hcan_cb->Instance == CAN1) {
    smartbot_joint::stm32_on_can_rx();
  }
}

extern "C" void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef * htim)
{
  if (htim->Instance == TIM6) {
    smartbot_joint::stm32_on_control_timer();
  }
}

extern "C" void HAL_I2C_MemRxCpltCallback(I2C_HandleTypeDef * hi2c)
{
  if (hi2c->Instance == I2C1) {
    smartbot_joint::stm32_on_i2c_rx_done();
  }
}

extern "C" void HAL_I2C_ErrorCallback(I2C_HandleTypeDef * hi2c)
{
  if (hi2c->Instance == I2C1) {
    smartbot_joint::stm32_on_i2c_error();
  }
}

#endif  // SMARTBOT_II_STM32
