// Copyright 2026 SmartBot II Maintainers
// Licensed under the Apache License, Version 2.0.

#ifndef SMARTBOT_JOINT__BOARD_PINS_HPP_
#define SMARTBOT_JOINT__BOARD_PINS_HPP_

#include <cstdint>

// Every pin and timer below is a stand-in for a dev board, not the SmartBot II limb PCB.
// REPLACE_WITH_BOARD_PINOUT before flashing a joint node.
// PWM carrier and the 1 kHz control tick both come from hardware timers.
// The microsecond time base is a free-running hardware timer, not a software delay.

namespace smartbot_joint
{

inline constexpr uint32_t kPwmCarrierHz = 20000;
inline constexpr uint32_t kControlLoopHz = 1000;
inline constexpr uint16_t kPwmPeriodCounts = 1000;
inline constexpr uint32_t kI2cHz = 400000;

struct Stm32PinMap
{
  // GPIO port letter and pin number. Port 'A' pin 0 is PA0.
  char in1_port;
  uint8_t in1_pin;
  char in2_port;
  uint8_t in2_pin;
  char sleep_port;
  uint8_t sleep_pin;
  char can_rx_port;
  uint8_t can_rx_pin;
  char can_tx_port;
  uint8_t can_tx_pin;
  char i2c_scl_port;
  uint8_t i2c_scl_pin;
  char i2c_sda_port;
  uint8_t i2c_sda_pin;
  uint8_t pwm_timer_index;
  uint8_t control_timer_index;
  uint8_t timebase_timer_index;
};

// Nucleo-class example only. Do not treat this as the robot harness.
inline constexpr Stm32PinMap kUnvalidatedStm32Pins{
  'A', 8,
  'A', 9,
  'A', 10,
  'A', 11,
  'A', 12,
  'B', 8,
  'B', 9,
  1, 6, 2};

struct Esp32PinMap
{
  int in1_gpio;
  int in2_gpio;
  int sleep_gpio;
  int can_tx_gpio;
  int can_rx_gpio;
  int i2c_scl_gpio;
  int i2c_sda_gpio;
};

// Dev-module example only. Do not treat this as the robot harness.
inline constexpr Esp32PinMap kUnvalidatedEsp32Pins{
  25, 26, 27, 5, 4, 22, 21};

}  // namespace smartbot_joint

#endif  // SMARTBOT_JOINT__BOARD_PINS_HPP_
