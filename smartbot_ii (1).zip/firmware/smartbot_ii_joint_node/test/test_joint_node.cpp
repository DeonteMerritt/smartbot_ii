// Host test for the joint-node core. It does not flash a microcontroller.

#include "smartbot_joint/joint_node.hpp"

#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iostream>

namespace
{

int failures = 0;

void expect(bool condition, const char * message)
{
  if (!condition) {
    std::cerr << message << '\n';
    ++failures;
  }
}

smartbot_joint::JointConfig config_for(uint8_t node_id)
{
  smartbot_joint::JointConfig config{};
  config.node_id = node_id;
  config.zero_offset_rad = 0.0f;
  config.direction = 1;
  config.output_radians_per_encoder_radian = 1.0f;
  config.pwm_period_counts = 1000;
  config.gains = smartbot_joint::kUnvalidatedPidGains;
  return config;
}

smartbot_joint::EncoderSample sample_at(float joint_rad, uint32_t time_us)
{
  float raw_rad = joint_rad;
  if (raw_rad < 0.0f) {
    raw_rad += smartbot_joint::kTwoPi;
  }
  const auto counts = static_cast<uint16_t>(
    (raw_rad / smartbot_joint::kTwoPi) * static_cast<float>(smartbot_joint::kAs5600Counts));
  smartbot_joint::EncoderSample sample{};
  sample.raw_counts = counts;
  sample.status = smartbot_joint::kAs5600StatusMagnetDetected;
  sample.timestamp_us = time_us;
  sample.i2c_ok = true;
  return sample;
}

smartbot_joint::CanFrame position_frame(uint8_t node_id, float radians)
{
  smartbot_joint::CanFrame frame{};
  frame.id = smartbot_joint::position_id(node_id);
  frame.dlc = 4;
  smartbot_joint::f32_to_le(radians, frame.data);
  return frame;
}

smartbot_joint::CanFrame heartbeat_frame()
{
  smartbot_joint::CanFrame frame{};
  frame.id = smartbot_joint::kHeartbeatId;
  frame.dlc = 1;
  frame.data[0] = 1;
  return frame;
}

void arm(smartbot_joint::JointNode & node, uint32_t time_us, float measured)
{
  node.on_encoder_sample_isr(sample_at(measured, time_us));
  node.on_can_rx_isr(heartbeat_frame(), time_us);
}

}  // namespace

int main()
{
  using smartbot_joint::FaultCode;
  using smartbot_joint::JointNode;
  using smartbot_joint::kHeartbeatTimeoutUs;

  JointNode bad;
  expect(!bad.init(config_for(0), 0), "node 0 is rejected");
  expect(!bad.init(config_for(23), 0), "node 23 is rejected");

  JointNode node;
  expect(node.init(config_for(1), 0), "node 1 initializes");
  expect(node.stop().name[0] == 'n', "node 1 is the neck yaw stop");

  const uint32_t t0 = 20000;
  arm(node, t0, 0.0f);
  node.on_can_rx_isr(position_frame(2, 0.5f), t0);
  node.on_can_rx_isr(position_frame(1, 0.2f), t0);
  const auto first = node.on_control_timer_isr(t0);
  expect(first.fault == FaultCode::None, "fresh heartbeat and encoder arm the node");
  expect(first.bridge.driver_enabled, "driver is enabled only while tracking");
  expect(first.bridge.in1_compare > 0, "positive error drives IN1");
  expect(first.bridge.in2_compare == 0, "positive error leaves IN2 off");

  JointNode negative;
  expect(negative.init(config_for(1), 0), "negative case initializes");
  arm(negative, t0, 0.0f);
  negative.on_can_rx_isr(position_frame(1, -0.2f), t0);
  const auto reverse = negative.on_control_timer_isr(t0);
  expect(reverse.bridge.in1_compare == 0, "negative error leaves IN1 off");
  expect(reverse.bridge.in2_compare > 0, "negative error drives IN2");

  JointNode timeout;
  expect(timeout.init(config_for(1), 0), "timeout case initializes");
  arm(timeout, t0, 0.0f);
  timeout.on_can_rx_isr(position_frame(1, 0.2f), t0);
  expect(timeout.on_control_timer_isr(t0).bridge.driver_enabled, "timeout case arms");
  const uint32_t t_late = t0 + kHeartbeatTimeoutUs + 1;
  timeout.on_encoder_sample_isr(sample_at(0.0f, t_late));
  const auto expired = timeout.on_control_timer_isr(t_late);
  expect(expired.fault == FaultCode::HeartbeatTimeout, "100 ms without a heartbeat latches");
  expect(expired.bridge.in1_compare == 0 && expired.bridge.in2_compare == 0, "fault zeros PWM");
  expect(!expired.bridge.driver_enabled, "fault isolates the driver");
  arm(timeout, t0 + kHeartbeatTimeoutUs + 2, 0.0f);
  const auto held = timeout.on_control_timer_isr(t0 + kHeartbeatTimeoutUs + 2);
  expect(held.fault == FaultCode::HeartbeatTimeout, "heartbeat fault stays latched");
  expect(!held.bridge.driver_enabled, "latched fault does not re-enable");

  smartbot_joint::CanFrame reset{};
  reset.id = smartbot_joint::reset_id(1);
  reset.dlc = 2;
  reset.data[0] = 1;
  reset.data[1] = smartbot_joint::kResetMagic;
  timeout.on_can_rx_isr(reset, t0 + kHeartbeatTimeoutUs + 3);
  arm(timeout, t0 + kHeartbeatTimeoutUs + 3, 0.0f);
  const auto cleared = timeout.on_control_timer_isr(t0 + kHeartbeatTimeoutUs + 3);
  expect(cleared.fault == FaultCode::None, "reset is accepted only while telemetry is healthy");

  JointNode boundary;
  expect(boundary.init(config_for(1), 0), "boundary case initializes");
  arm(boundary, t0, 0.0f);
  expect(boundary.on_control_timer_isr(t0).fault == FaultCode::None, "boundary case arms inside the stop");
  boundary.on_encoder_sample_isr(sample_at(1.2f, t0 + 1000));
  boundary.on_can_rx_isr(heartbeat_frame(), t0 + 1000);
  const auto broken = boundary.on_control_timer_isr(t0 + 1000);
  expect(broken.fault == FaultCode::EncoderBoundary, "angle past the stop latches");
  expect(!broken.bridge.driver_enabled, "boundary fault isolates the driver");
  arm(boundary, t0 + 2000, 0.0f);
  const auto still = boundary.on_control_timer_isr(t0 + 2000);
  expect(still.fault == FaultCode::EncoderBoundary, "boundary fault stays latched");

  JointNode magnet;
  expect(magnet.init(config_for(1), 0), "magnet case initializes");
  auto missing = sample_at(0.0f, t0);
  missing.status = 0;
  magnet.on_encoder_sample_isr(missing);
  magnet.on_can_rx_isr(heartbeat_frame(), t0);
  const auto no_magnet = magnet.on_control_timer_isr(t0);
  expect(no_magnet.fault == FaultCode::EncoderMagnet, "missing magnet latches");
  expect(no_magnet.bridge.in1_compare == 0 && !no_magnet.bridge.driver_enabled, "magnet fault is off");

  const auto encoded = position_frame(1, 0.15f);
  float decoded = 0.0f;
  const auto parsed = smartbot_joint::parse_can_frame(encoded, 1, decoded);
  expect(parsed == smartbot_joint::CanParse::Position, "position frame parses");
  expect(std::fabs(decoded - 0.15f) < 1.0e-6f, "little-endian float matches");
  float ignored = 0.0f;
  expect(
    smartbot_joint::parse_can_frame(encoded, 2, ignored) == smartbot_joint::CanParse::Ignore,
    "another node id is filtered out");

  if (failures != 0) {
    std::cerr << failures << " joint node checks failed\n";
    return EXIT_FAILURE;
  }
  std::cout << "joint node checks passed\n";
  return EXIT_SUCCESS;
}
