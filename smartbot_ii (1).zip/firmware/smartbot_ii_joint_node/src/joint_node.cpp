// Copyright 2026 SmartBot II Maintainers
// Licensed under the Apache License, Version 2.0.

#include "smartbot_joint/joint_node.hpp"

#include <cmath>

namespace smartbot_joint
{
namespace
{

inline void compiler_barrier() noexcept
{
  asm volatile("" ::: "memory");
}

inline bool finite_float(float value) noexcept
{
  return std::isfinite(value);
}

inline uint32_t elapsed_us(uint32_t now, uint32_t then) noexcept
{
  return now - then;
}

}  // namespace

bool JointNode::init(const JointConfig & config, uint32_t now_us) noexcept
{
  if (!node_id_valid(config.node_id)) {
    return false;
  }
  if (config.direction != 1 && config.direction != -1) {
    return false;
  }
  if (
    !(config.pwm_period_counts > 0) || !finite_float(config.zero_offset_rad) ||
    !finite_float(config.output_radians_per_encoder_radian) ||
    !(config.output_radians_per_encoder_radian > 0.0f))
  {
    return false;
  }
  const PidGains & gains = config.gains;
  if (
    !finite_float(gains.kp) || !finite_float(gains.ki) || !finite_float(gains.kd) ||
    !finite_float(gains.integrator_limit) || !finite_float(gains.output_limit) ||
    !(gains.output_limit > 0.0f) || gains.output_limit > 1.0f || gains.integrator_limit < 0.0f)
  {
    return false;
  }

  node_id_ = config.node_id;
  zero_offset_rad_ = config.zero_offset_rad;
  direction_ = config.direction;
  output_scale_ = config.output_radians_per_encoder_radian;
  pwm_period_ = config.pwm_period_counts;
  gains_ = gains;
  pid_reset(pid_);
  commanded_rad_ = 0.0f;
  slewed_rad_ = 0.0f;
  have_command_ = false;
  heartbeat_seen_ = false;
  last_heartbeat_us_ = now_us;
  boot_us_ = now_us;
  clear_request_ = false;
  sample_ = EncoderSample{};
  have_sample_ = false;
  measured_rad_ = 0.0f;
  velocity_rad_s_ = 0.0f;
  previous_measured_rad_ = 0.0f;
  have_velocity_sample_ = false;
  temperature_c_ = kTemperatureUnavailable;
  measurement_valid_ = false;
  fault_ = FaultCode::Disarmed;
  last_tick_us_ = now_us;
  tick_count_ = 0;
  encoder_read_open_ = false;
  return true;
}

void JointNode::latch(FaultCode code) noexcept
{
  if (fault_ == FaultCode::None || fault_ == FaultCode::Disarmed) {
    fault_ = code;
  }
  pid_reset(pid_);
}

bool JointNode::try_clear_latch(uint32_t now_us) noexcept
{
  if (!clear_request_) {
    return false;
  }
  clear_request_ = false;
  if (!heartbeat_seen_ || elapsed_us(now_us, last_heartbeat_us_) > kHeartbeatTimeoutUs) {
    return false;
  }
  if (!measurement_valid_) {
    return false;
  }
  fault_ = FaultCode::None;
  pid_reset(pid_);
  slewed_rad_ = measured_rad_;
  return true;
}

float JointNode::clamped_target() const noexcept
{
  const JointStop & stop = this->stop();
  float target = have_command_ ? commanded_rad_ : measured_rad_;
  if (target < stop.min_rad) {
    target = stop.min_rad;
  } else if (target > stop.max_rad) {
    target = stop.max_rad;
  }
  return target;
}

void JointNode::on_can_rx_isr(const CanFrame & frame, uint32_t now_us) noexcept
{
  float position = 0.0f;
  const CanParse parsed = parse_can_frame(frame, node_id_, position);
  if (parsed == CanParse::Heartbeat) {
    last_heartbeat_us_ = now_us;
    compiler_barrier();
    heartbeat_seen_ = true;
    return;
  }
  if (parsed == CanParse::Reset) {
    clear_request_ = true;
    return;
  }
  if (parsed == CanParse::Position) {
    commanded_rad_ = position;
    compiler_barrier();
    have_command_ = true;
  }
}

void JointNode::on_encoder_sample_isr(const EncoderSample & sample) noexcept
{
  sample_ = sample;
  compiler_barrier();
  have_sample_ = true;
  encoder_read_open_ = false;
}

TickResult JointNode::on_control_timer_isr(uint32_t now_us) noexcept
{
  TickResult result{};
  result.bridge = bridge_safe_off();
  result.fault = fault_;
  result.measured_rad = measured_rad_;
  result.target_rad = slewed_rad_;
  result.start_encoder_read = false;
  result.send_status = false;

  const uint32_t dt_us = elapsed_us(now_us, last_tick_us_);
  last_tick_us_ = now_us;
  const float dt_s = static_cast<float>(dt_us) * 1.0e-6f;

  if (!encoder_read_open_ && (tick_count_ % 2u) == 0u) {
    result.start_encoder_read = true;
    encoder_read_open_ = true;
  }
  ++tick_count_;

  measurement_valid_ = false;
  if (have_sample_) {
    const EncoderSample sample = sample_;
    compiler_barrier();
    const uint32_t age = elapsed_us(now_us, sample.timestamp_us);
    if (!sample.i2c_ok || age > kEncoderMaxAgeUs) {
      latch(FaultCode::EncoderTimeout);
    } else if (!as5600_magnet_detected(sample.status)) {
      latch(FaultCode::EncoderMagnet);
    } else {
      const float joint_rad =
        as5600_joint_rad(sample.raw_counts, zero_offset_rad_, direction_) * output_scale_;
      const JointStop & stop = this->stop();
      if (joint_rad < stop.min_rad || joint_rad > stop.max_rad) {
        measured_rad_ = joint_rad;
        latch(FaultCode::EncoderBoundary);
      } else {
        if (have_velocity_sample_ && dt_s > 0.0f) {
          velocity_rad_s_ = (joint_rad - previous_measured_rad_) / dt_s;
        } else {
          velocity_rad_s_ = 0.0f;
        }
        previous_measured_rad_ = joint_rad;
        have_velocity_sample_ = true;
        measured_rad_ = joint_rad;
        measurement_valid_ = true;
      }
    }
  } else if (elapsed_us(now_us, boot_us_) > kEncoderMaxAgeUs) {
    latch(FaultCode::EncoderTimeout);
  }

  const uint32_t heartbeat_age =
    heartbeat_seen_ ? elapsed_us(now_us, last_heartbeat_us_) : elapsed_us(now_us, boot_us_);
  if (heartbeat_age > kHeartbeatTimeoutUs) {
    latch(FaultCode::HeartbeatTimeout);
  }

  if (fault_ != FaultCode::None && fault_ != FaultCode::Disarmed) {
    try_clear_latch(now_us);
  }

  if (fault_ != FaultCode::None && fault_ != FaultCode::Disarmed) {
    result.bridge = bridge_safe_off();
    result.fault = fault_;
    result.measured_rad = measured_rad_;
    result.target_rad = slewed_rad_;
    write_status(result);
    return result;
  }

  if (!heartbeat_seen_ || !measurement_valid_) {
    fault_ = FaultCode::Disarmed;
    result.bridge = bridge_safe_off();
    result.fault = fault_;
    result.measured_rad = measured_rad_;
    write_status(result);
    return result;
  }

  if (fault_ == FaultCode::Disarmed) {
    slewed_rad_ = measured_rad_;
    pid_reset(pid_);
  }
  fault_ = FaultCode::None;
  const JointStop & stop = this->stop();
  const float desired = clamped_target();
  float max_step = stop.max_velocity_rad_s * dt_s;
  if (max_step < 0.0f) {
    max_step = 0.0f;
  }
  float step = desired - slewed_rad_;
  if (step > max_step) {
    step = max_step;
  } else if (step < -max_step) {
    step = -max_step;
  }
  slewed_rad_ += step;
  if (slewed_rad_ < stop.min_rad) {
    slewed_rad_ = stop.min_rad;
  } else if (slewed_rad_ > stop.max_rad) {
    slewed_rad_ = stop.max_rad;
  }

  const float duty = pid_step(pid_, gains_, slewed_rad_, measured_rad_, dt_s);
  result.bridge = bridge_from_duty(duty, pwm_period_, true);
  result.fault = FaultCode::None;
  result.measured_rad = measured_rad_;
  result.target_rad = slewed_rad_;
  write_status(result);
  return result;
}

void JointNode::write_status(TickResult & result) noexcept
{
  if ((tick_count_ % 20u) != 0u) {
    return;
  }
  CanFrame frame{};
  frame.id = status_id(node_id_);
  frame.dlc = kStatusDlc;
  f32_to_le(measured_rad_, frame.data);
  float scaled = velocity_rad_s_ / kVelocityScale;
  if (scaled > 32767.0f) {
    scaled = 32767.0f;
  } else if (scaled < -32768.0f) {
    scaled = -32768.0f;
  }
  const auto velocity_counts = static_cast<int16_t>(scaled);
  frame.data[4] = static_cast<uint8_t>(velocity_counts);
  frame.data[5] = static_cast<uint8_t>(static_cast<uint16_t>(velocity_counts) >> 8);
  frame.data[6] = static_cast<uint8_t>(temperature_c_);
  uint8_t flags = 0;
  if (
    result.fault == FaultCode::EncoderBoundary || result.fault == FaultCode::EncoderMagnet ||
    result.fault == FaultCode::EncoderTimeout)
  {
    flags = static_cast<uint8_t>(flags | kFaultEncoder);
  } else if (result.fault == FaultCode::HeartbeatTimeout) {
    flags = static_cast<uint8_t>(flags | kFaultHeartbeat);
  }
  frame.data[7] = flags;
  result.status = frame;
  result.send_status = true;
}

}  // namespace smartbot_joint
