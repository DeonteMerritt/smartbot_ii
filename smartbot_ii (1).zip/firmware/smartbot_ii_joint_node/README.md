# SmartBot II joint actuator node

Standalone firmware core for one limb-bus joint. It is written to run from hardware interrupts on an STM32, with an ESP32 port for the same core. The host test compiles without a chip.

This firmware is not a validated motor driver. PID gains, encoder zero, pin map, and the simulated joint stops have to be replaced with bench measurements. `nSLEEP` low isolates the gate driver. It does not remove battery power. A FET that fails short can still produce torque. Do not enable a motor, and do not put a person in reach of a limb, until the stops, current limit, encoder direction, and a hardware emergency stop have been checked on that joint.

## What runs where

| Event | Context | Work |
| --- | --- | --- |
| CAN RX | controller interrupt | Accept only this node's frames. Latch a float or a heartbeat. |
| AS5600 I2C done | I2C interrupt | Latch the 12-bit angle and the status byte. |
| 1 kHz timer | timer interrupt | PID, boundary check, heartbeat age, PWM compare update. |

`read()`-style work and the PID are not in the CAN interrupt. The CAN interrupt only stores the command so the 1 kHz tick can apply it on the next sample.

## CAN map

Standard 11-bit frames. Node 1 is `neck_yaw_joint`. Node 22 is `right_ankle_roll_joint`. `node_id = joint_id + 1`.

| ID | Payload | Who sends it |
| --- | --- | --- |
| `0x080` | 1 byte counter | Master heartbeat. Required at least every 100 ms. |
| `0x200 + node_id` | float32 radians, little-endian | Position command for that node only. |
| `0x180 + node_id` | `node_id`, `0xA5` | Fault reset for that node. Ignored unless the encoder and heartbeat are healthy. |
| `0x300 + node_id` | 8 bytes: float32 radians, int16 velocity in 0.001 rad/s, int8 °C or -128 if no sensor, fault flags | Status from the node, about 50 Hz. |

The float byte order matches `JointTargetPacket` in `smartbot_ii_control`. The compiled bitrate default is 500 kbit/s. The STM32 filter is a 16-bit ID list of the heartbeat, the node's position ID, and the node's reset ID. The software parser rejects every other ID even if the hardware filter is wider. ESP32 TWAI has a single mask, so the same software parser is the node filter.

## Encoder

AS5600 at I2C `0x36`. The timer tick starts a read of status `0x0B` plus raw angle `0x0C`/`0x0D`. Angle in radians is `counts / 4096 * 2π`, then shifted by `zero_offset_rad` and signed by `direction`. Both of those are `REPLACE_WITH_PHYSICAL_MEASUREMENT`. A missing magnet (`MD` clear) or a joint angle outside the simulated stop latches a fault. A sample older than 10 ms does too.

## Bridge

DRV8870, DRV8871, and DRV8873 style inputs:

- Positive duty: `IN1` PWM, `IN2` low, `nSLEEP` high.
- Negative duty: `IN1` low, `IN2` PWM, `nSLEEP` high.
- Inside the deadband, while healthy: both inputs high (slow-decay brake).
- Fault: both compares 0 and `nSLEEP` low.

The unvalidated PID will not command more than 25% of the PWM period (`output_limit` 0.25). That cap is not a current limit. The 20 kHz carrier is a timer setting, not a measured electrical requirement.

## Faults

| Code | Meaning |
| --- | --- |
| 0 | Running |
| 1 | No master heartbeat for more than 100 ms |
| 2 | Encoder angle outside the joint stop |
| 3 | AS5600 reports no magnet |
| 4 | Encoder sample missing or older than 10 ms |
| 5 | Disarmed, waiting for the first good heartbeat and sample |

A latched fault forces the safe output and stays latched. A later healthy sample does not clear it. The reset frame clears it only when a heartbeat is fresh and the encoder is inside the stop.

Status byte 7 is a flag mask, not the enum above:

| Bit | Mask | Meaning |
| --- | --- | --- |
| 0 | `0x01` | Encoder boundary, missing magnet, or stale sample |
| 1 | `0x02` | Overtemperature. The node does not measure temperature yet, so this bit stays clear. |
| 2 | `0x04` | Overcurrent. The node does not measure current yet, so this bit stays clear. |
| 3 | `0x08` | Master heartbeat older than 100 ms |

Byte 6 stays `-128` until a temperature sensor is fitted. The Pi receiver still treats bit 1, bit 2, and a temperature at or above 80 °C as faults. Disarmed (code 5) sends flags `0` and does not latch the Pi software stop.

## Files

- `include/smartbot_joint/can_protocol.hpp` — IDs, filter list, little-endian float parse.
- `include/smartbot_joint/as5600.hpp` — register map and radian conversion.
- `include/smartbot_joint/pid.hpp` — position PID. Gains are stand-ins.
- `include/smartbot_joint/hbridge.hpp` — DRV IN1/IN2/`nSLEEP` mapping.
- `include/smartbot_joint/joint_node.hpp` — node, simulated stops, ISR entry points.
- `src/joint_node.cpp` — timer tick, latch, and status frame.
- `platform/board_pins.hpp` — dev-board pin stand-ins. Replace every pin.
- `platform/stm32/stm32_port.cpp` — CAN, I2C, and timer callbacks. Compile with `SMARTBOT_II_STM32`.
- `platform/esp32/esp32_port.cpp` — TWAI, I2C, and LEDC. Compile with `SMARTBOT_II_ESP32`.
- `test/test_joint_node.cpp` — host checks for filter, PID sign, and the fault latch.
- `CMakeLists.txt` — host build of the core and the test.

## Host build

From this directory:

```bash
cmake -S . -B build
cmake --build build
./build/test_joint_node
```

Or from the workspace root:

```bash
g++ -std=c++17 -Wall -Wextra -Wpedantic \
  -I firmware/smartbot_ii_joint_node/include \
  firmware/smartbot_ii_joint_node/src/joint_node.cpp \
  firmware/smartbot_ii_joint_node/test/test_joint_node.cpp \
  -o /tmp/test_joint_node
/tmp/test_joint_node
```

## STM32

In CubeMX, create:

- CAN at 500 kbit/s, RX FIFO0 interrupt on.
- I2C1 at 400 kHz.
- `htim_pwm` at 20 kHz, period 1000, two PWM channels.
- `htim_control` as TIM6 at 1 kHz, update interrupt on.
- `htim_timebase` free-running at 1 MHz.

Name the handles `hcan`, `hi2c1`, `htim_pwm`, `htim_control`, and `htim_timebase`. Compile `stm32_port.cpp` with `SMARTBOT_II_STM32`. Do not also generate empty copies of `HAL_CAN_RxFifo0MsgPendingCallback`, `HAL_TIM_PeriodElapsedCallback`, `HAL_I2C_MemRxCpltCallback`, or `HAL_I2C_ErrorCallback`. Call `smartbot_joint::stm32_joint_start(node_id)` after the clocks are up. `node_id` is 1 through 22.

## ESP32

Build `esp32_port.cpp` with `SMARTBOT_II_ESP32` in an ESP-IDF project. Call `smartbot_joint::esp32_joint_start(node_id)`, then call `smartbot_joint::esp32_poll_can_and_encoder()` from a high-priority task. The 1 kHz `esp_timer` callback runs the PID and writes LEDC. TWAI and LEDC take locks, so that callback is a timer task, not an IRAM CAN interrupt. The STM32 port is the one that writes the PWM compares from the timer ISR.

## Measurements you still have to supply

- Mechanical stop for this joint, in radians, at the magnet's zero pose.
- Magnet zero offset and sign.
- Whether the magnet is on the joint or the motor shaft (`output_radians_per_encoder_radian`).
- PID gains, current limit, and the DRV `VREF` or current-sense resistor.
- CAN bitrate and transceiver wiring.
- The real GPIO, timer, and connector pinout.
- Proof that cutting `nSLEEP` is not the only thing between the motor and a person.
