# SmartBot II

ROS 2 Jazzy description, simulation, and command-bridge workspace for the SmartBot II humanoid.

This is a robotics software project. It is a colcon workspace of five packages. It is not a website, and it does not include a motor driver.

**Simulation only.** The geometry, masses, inertias, joint limits, controller gains, and contact parameters are conservative stand-ins. Every value that must be replaced by a caliper reading, a CAD export, or a hardware datasheet is marked `REPLACE_WITH_PHYSICAL_MEASUREMENT` in the Xacro comments and in `src/smartbot_ii_description/config/simulated_parameters.yaml` (`replace_with_physical_measurement: true`).

This model has not been validated for walking, balancing, or driving physical motors. Do not treat a successful RViz preview or a Gazebo joint test as evidence that the robot can walk or that a motor may be enabled. The software emergency-stop latch in the Seldun bridge is not a hardware emergency stop.

Frames: +X forward, +Y left, +Z up. The zero pose is standing straight with the arms down along -Z. The neck extends along +Z. The foot toe points along +X.

## Packages

| Package | Role |
| --- | --- |
| `smartbot_ii_description` | URDF/Xacro, materials, limits, SRDF, RViz display |
| `smartbot_ii_control` | Controller YAML, mock `ros2_control` launch, safe neck test |
| `smartbot_ii_gazebo` | Gazebo Sim test world and spawn launch |
| `seldun_smartbot_bridge` | Validates Seldun commands and republishes accepted ones |
| `smartbot_ii_voice` | Streams speech from `/smartbot/speech_request` to the local speaker |

Hardware plugins that this workspace will load:

- `mock_components/GenericSystem` from `control.launch.py`
- `gz_ros2_control/GazeboSimSystem` from `simulation.launch.py`
- `smartbot_ii_control/SmartBotIIHardware` from `hardware_interface.launch.py`

`SmartBotIIHardware` packs position frames. Its default transport does not open a device. The launch files do not take a free-form plugin name.

## What is not implemented

- A walking or balance controller. `geometry_msgs/msg/Twist` on `/cmd_vel` is forwarded and capped. Nothing consumes it to move the robot.
- A waist degree of freedom. `torso_link` is fixed to `pelvis_link`.
- Finger degrees of freedom. Each hand is fixed to its wrist.
- A free-floating base controller. The optional `fixed_base_link` weld is a test fixture so joint commands do not require balance. Releasing that weld makes the simulated body fall.
- A hardware emergency-stop circuit. `SmartBotIIHardware` can pack position frames, and it can open a UART or SPI device only after an explicit unlock. Deactivate does not remove motor power.
- MoveIt configuration beyond an SRDF and a controller YAML that MoveIt Setup Assistant can load later.

## Environment

Developed for:

- Windows 11 with WSL2
- Ubuntu 24.04
- ROS 2 Jazzy
- Visual Studio Code or Cursor, with the ROS and Python extensions
- colcon
- Gazebo Sim (Harmonic, through `ros_gz_sim` and `gz_ros2_control`)
- RViz2
- `ros2_control` and a MoveIt 2-ready description

Open the workspace folder from the WSL filesystem (`\\wsl$\Ubuntu\...` or the WSL remote), not from a Windows drive mount. colcon and Gazebo expect a Linux path.

RViz2 and Gazebo need a GUI. On WSL2 that is WSLg, or an X server with `DISPLAY` set. Headless checks are listed below and do not need a display.

## Installation

Run these commands inside Ubuntu 24.04 on WSL2. They follow the [ROS 2 Jazzy Ubuntu install](https://docs.ros.org/en/jazzy/Installation/Ubuntu-Install-Debs.html).

```bash
sudo apt update
sudo apt install -y software-properties-common curl gnupg lsb-release
sudo curl -sSL https://raw.githubusercontent.com/ros/rosdistro/master/ros.key \
  -o /usr/share/keyrings/ros-archive-keyring.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/ros-archive-keyring.gpg] http://packages.ros.org/ros2/ubuntu $(. /etc/os-release && echo $UBUNTU_CODENAME) main" \
  | sudo tee /etc/apt/sources.list.d/ros2.list > /dev/null
sudo apt update
sudo apt install -y \
  ros-jazzy-desktop \
  ros-dev-tools \
  python3-colcon-common-extensions \
  python3-rosdep \
  python3-pytest \
  python3-pip \
  python3-yaml \
  ros-jazzy-xacro \
  ros-jazzy-robot-state-publisher \
  ros-jazzy-joint-state-publisher \
  ros-jazzy-joint-state-publisher-gui \
  ros-jazzy-rviz2 \
  ros-jazzy-ros-gz \
  ros-jazzy-gz-ros2-control \
  ros-jazzy-controller-manager \
  ros-jazzy-joint-state-broadcaster \
  ros-jazzy-joint-trajectory-controller \
  ros-jazzy-control-msgs \
  ros-jazzy-diagnostic-msgs \
  ros-jazzy-ros2-control \
  ros-jazzy-ros2-controllers \
  ros-jazzy-tf2-tools \
  ros-jazzy-rqt-tf-tree \
  liburdfdom-tools \
  libportaudio2 \
  ffmpeg
python3 -m pip install --user -r src/smartbot_ii_voice/requirements.txt
sudo rosdep init
rosdep update
```

`sudo rosdep init` prints an error if rosdep was already initialized. Continue with `rosdep update` in that case.

`ros-jazzy-desktop` already contains many of the packages listed after it. The explicit names are there so a minimal image still gets xacro, RViz, the Gazebo bridge, and the controllers.

## Build

From the workspace root (the directory that contains `src/`):

```bash
source /opt/ros/jazzy/setup.bash
rosdep install --from-paths src --ignore-src -r -y
colcon build --symlink-install
source install/setup.bash
```

Source `install/setup.bash` again in every new terminal before a launch or a `ros2` command. You can append both source lines to `~/.bashrc` after the build succeeds.

## Display SmartBot II in RViz

One terminal:

```bash
source /opt/ros/jazzy/setup.bash
source install/setup.bash
ros2 launch smartbot_ii_description display.launch.py
```

That starts `robot_state_publisher`, `joint_state_publisher_gui`, and RViz2 with `rviz/smartbot_ii.rviz`. Drag the joint sliders. This is a kinematic preview. It does not start `ros2_control` or Gazebo.

Optional arguments:

```bash
ros2 launch smartbot_ii_description display.launch.py gui:=false
ros2 launch smartbot_ii_description display.launch.py rviz:=false
```

`use_meshes:=true` and `use_collision_meshes:=true` are valid only after the DAE and STL files in the mesh section exist. The default is primitive geometry.

Do not run `display.launch.py` in the same ROS graph as `control.launch.py` or `simulation.launch.py`. The display launch publishes `/joint_states` from the joint-state publisher. The other launches publish `/joint_states` from `joint_state_broadcaster`. Two publishers on that topic fight.

If the robot does not appear, set the RobotModel display durability to Transient Local. `robot_state_publisher` latches `/robot_description`. The shipped RViz file already uses Transient Local. Some stock RViz configs use Volatile and then miss the latched message.

## Spawn SmartBot II in Gazebo

One terminal:

```bash
source /opt/ros/jazzy/setup.bash
source install/setup.bash
ros2 launch smartbot_ii_gazebo simulation.launch.py
```

Defaults:

- World `smartbot_ii_test.sdf`, started with `gz sim -r`.
- Pelvis welded to `fixed_base_link` (`fix_pelvis_to_world:=true`). The weld is a joint-test fixture. It is not balance and it is not a claim that the robot can stand.
- Spawn height `auto`: `z=0` while welded, because the fixed joint already places the pelvis 0.92 m above the sole. `FREE_STANDING_SPAWN_Z` in `simulation.launch.py` is 0.92 m and must match `pelvis_height_above_ground`.
- `use_sim_time:=true`.
- RViz2 on.
- Hardware plugin `gz_ros2_control/GazeboSimSystem`.
- After the spawn process exits, the launch starts `joint_state_broadcaster`, then `smartbot_joint_trajectory_controller`.

Other invocations:

```bash
ros2 launch smartbot_ii_gazebo simulation.launch.py rviz:=false
ros2 launch smartbot_ii_gazebo simulation.launch.py start_seldun_bridge:=true
ros2 launch smartbot_ii_gazebo simulation.launch.py fix_pelvis_to_world:=false
```

`fix_pelvis_to_world:=false` spawns a free humanoid with position control and no balance controller. It will fall. That launch is not a walking test.

If Gazebo reports that `libgz_ros2_control-system.so` cannot be found, the plugin path was not exported by `gz_sim.launch.py`. This is a known Jazzy setup issue. In that terminal, before the launch:

```bash
export GZ_SIM_SYSTEM_PLUGIN_PATH=/opt/ros/jazzy/lib
```

Do not run `simulation.launch.py` and `control.launch.py` at the same time. Each one starts a controller manager for the same joint names.

## Mock ros2_control (safest joint test)

This path does not start Gazebo and does not load a physical plugin.

```bash
source /opt/ros/jazzy/setup.bash
source install/setup.bash
ros2 launch smartbot_ii_control control.launch.py
```

`ros2_control_node` uses `mock_components/GenericSystem`. RViz starts by default (`rviz:=false` to skip it). Spawned controllers are `joint_state_broadcaster` and `smartbot_joint_trajectory_controller`.

## SmartBot II hardware interface

`smartbot_ii_control/SmartBotIIHardware` is a `hardware_interface::SystemInterface` for the same 22 joints, in the same order as `ACTUATED_JOINTS`. It exports position and velocity state interfaces and a position command interface. `read()` and `write()` do not allocate. `write()` packs each joint into a 5-byte record, `uint8_t joint_id` plus little-endian `float target_rad`, inside a 114-byte frame (sync bytes, count, 22 records, XOR checksum). The nominal path is written to stay inside the 1 ms budget of the 250 Hz cycle.

```bash
source /opt/ros/jazzy/setup.bash
source install/setup.bash
ros2 launch smartbot_ii_control hardware_interface.launch.py
```

`bus_transport` defaults to `mock`. The frame is published inside the process and no UART or SPI device is opened. Raspberry Pi 5 pin names are logged only as the intended connector for a later bus: GPIO 14/15 for UART, and GPIO 10/9/11/8 for SPI0. Do not run this launch in the same graph as `control.launch.py` or `simulation.launch.py`.

UART or SPI stays closed unless all three of these are set:

- `bus_transport:=uart` or `bus_transport:=spi`
- `allow_unvalidated_bus:=true`
- `physical_hardware_ack:=ENABLE_UNVALIDATED_PHYSICAL_HARDWARE`

Opening the device writes the raw frame from a separate thread. It does not apply current limits, encoder feedback, or a hardware emergency stop, and it does not make walking or motor operation valid. `on_deactivate` holds the last position in the frame. It does not cut power.

## Joint actuator firmware

`firmware/smartbot_ii_joint_node` is the interrupt-driven controller for one STM32 or ESP32 node on the limb bus. CAN node 1 is `neck_yaw_joint` and node 22 is `right_ankle_roll_joint`. A position frame is a little-endian float on ID `0x200 + node_id`. The master heartbeat is ID `0x080`. If that heartbeat is missing for more than 100 ms, or the AS5600 angle leaves the simulated stop, or the magnet is not detected, the node writes both PWM compares to 0, drives the DRV `nSLEEP` line low, and latches the fault.

```bash
g++ -std=c++17 -Wall -Wextra -Wpedantic \
  -I firmware/smartbot_ii_joint_node/include \
  firmware/smartbot_ii_joint_node/src/joint_node.cpp \
  firmware/smartbot_ii_joint_node/test/test_joint_node.cpp \
  -o /tmp/test_joint_node
/tmp/test_joint_node
```

The PID gains, encoder zero, and pin map are stand-ins. `nSLEEP` low is not a battery contactor. Details, CAN IDs, and the CubeMX / ESP-IDF build notes are in `firmware/smartbot_ii_joint_node/README.md`.

## Limb-bus telemetry on the Pi

`seldun_smartbot_bridge/bus_telemetry.py` is the receive side of that bus. `LimbBusReceiver` runs a background thread. `bus_telemetry_transport` is `off` in the shipped parameter file, so the bridge does not open `can0` or a serial port. Set it to `socketcan` (python-can) or `serial` (pyserial) to listen. Listening does not enable a motor.

Status ID `0x300 + node_id`, 8 bytes, little-endian:

- bytes 0–3: position, float32 radians
- bytes 4–5: velocity, int16 counts of 0.001 rad/s
- byte 6: temperature, int8 °C, or `-128` when no sensor is fitted
- byte 7: fault flags. Bit 0 encoder, bit 1 overtemperature, bit 2 overcurrent, bit 3 heartbeat timeout

The joint node does not measure current or temperature yet, so bits 1 and 2 stay clear and byte 6 stays `-128`. The receiver still treats those bits, and a temperature at or above 80 °C, as faults. A legacy 6-byte status frame is accepted. Disarmed does not raise an alert.

`feed_bridge` writes `SeldunBridge._measured` only when all 22 positions are finite. The keys are `ACTUATED_JOINTS` in that order. Velocities and temperatures stay on the receiver vectors. While the receiver is running, `/joint_states` does not overwrite that dictionary.

An encoder, overtemperature, overcurrent, or heartbeat flag publishes `diagnostic_msgs/msg/DiagnosticArray` on `smartbot/system_alert` and `/diagnostics`, publishes a zero `Twist`, and latches the software stop. The same flag does not publish again until `reset_stop`. The next status frame that still carries the flag latches it again. That latch does not open a contactor.

## Safe simulation-only joint movement test

Use this only while `control.launch.py`, `hardware_interface.launch.py`, or `simulation.launch.py` is already running, and only in simulation. It moves `neck_yaw_joint` to 0.15 rad over 2 seconds and back to 0. It refuses to run if `hardware_mode` is not `simulation`, and it refuses an amplitude above 0.20 rad.

Second terminal:

```bash
source /opt/ros/jazzy/setup.bash
source install/setup.bash
ros2 run smartbot_ii_control send_safe_neck_trajectory.py
```

The same motion as raw action goals, still simulation only:

```bash
ros2 action send_goal /smartbot_joint_trajectory_controller/follow_joint_trajectory \
  control_msgs/action/FollowJointTrajectory \
  "{trajectory: {joint_names: ['neck_yaw_joint'], points: [{positions: [0.15], time_from_start: {sec: 2, nanosec: 0}}]}}"

ros2 action send_goal /smartbot_joint_trajectory_controller/follow_joint_trajectory \
  control_msgs/action/FollowJointTrajectory \
  "{trajectory: {joint_names: ['neck_yaw_joint'], points: [{positions: [0.0], time_from_start: {sec: 2, nanosec: 0}}]}}"
```

Do not send a leg trajectory that would unload a supporting foot. Do not run either command against physical hardware. A small neck motion in a welded or mock simulation does not validate the legs, the contact model, or any motor.

## Seldun bridge

The bridge translates a validated `seldun_smartbot_bridge/msg/SeldunCommand` into one of:

- `geometry_msgs/msg/Twist` on `/cmd_vel`
- `trajectory_msgs/msg/JointTrajectory` on `/smartbot_joint_trajectory_controller/joint_trajectory`
- `control_msgs/action/FollowJointTrajectory` on `/smartbot_joint_trajectory_controller/follow_joint_trajectory`

`command_transport` is `action` by default. A joint command uses the action or the topic, never both, so the trajectory controller is not commanded twice. If the action server is down and transport is `action`, the command is rejected with `CONTROLLER_UNAVAILABLE`.

Start it on its own (simulation parameters):

```bash
source /opt/ros/jazzy/setup.bash
source install/setup.bash
ros2 launch seldun_smartbot_bridge seldun_bridge.launch.py
```

With Gazebo, prefer `start_seldun_bridge:=true` on the simulation launch so `use_sim_time` matches. Or:

```bash
ros2 launch seldun_smartbot_bridge seldun_bridge.launch.py use_sim_time:=true
```

The shipped file `config/bridge_params.yaml` sets `hardware_mode: simulation`, `allow_physical_hardware: false`, and an empty acknowledgement. Physical mode is read once at process start. It requires all three of these, then a restart:

- `hardware_mode: physical`
- `allow_physical_hardware: true`
- `physical_hardware_ack: ENABLE_UNVALIDATED_PHYSICAL_HARDWARE`

The acknowledgement string is the Python constant in `validator.py`. Editing only `safety_limits.yaml` cannot unlock the gate, because `load_policy` requires that file's token to equal the same constant. Unlocking still only publishes ROS messages. It does not load a motor driver, a walking controller, or a hardware emergency stop.

Accepted command types: `joint_trajectory`, `cmd_vel`, `stop`, `reset_stop`.

The bridge rejects unknown joints, duplicate joints, length mismatches, non-finite numbers, positions, velocities, or efforts outside the safety limits, a position step larger than `max_position_delta_rad`, a non-positive or too-long trajectory time, `cmd_vel` outside the policy caps, a motion command while the software stop is latched, and a motion command when physical mode was requested but not unlocked. Results are published on `seldun/command_result` with an error code and a message. Diagnostics are published on `/diagnostics` once a second, including `locomotion_implemented: false`, `physical_motor_driver_shipped: false`, and `hardware_emergency_stop_shipped: false`.

`stop` latches a software flag. That latch is not a hardware emergency stop. A limb-bus fault flag uses the same flag and also publishes `smartbot/system_alert`. `cmd_vel` with `linear_z` or `angular_x` / `angular_y` is capped at 0. An accepted `cmd_vel` does not make the robot walk.

Example, after the bridge and a controller are running. This uses the default action transport, so the trajectory controller must be up:

```bash
ros2 topic pub --once /seldun/command seldun_smartbot_bridge/msg/SeldunCommand \
  "{command_id: 'safe-neck-1', command_type: 'joint_trajectory', joint_names: ['neck_yaw_joint'], positions: [0.15], velocities: [0.1], efforts: [0.5], time_from_start_sec: 2.0, linear_x: 0.0, linear_y: 0.0, linear_z: 0.0, angular_x: 0.0, angular_y: 0.0, angular_z: 0.0}"

ros2 topic echo /seldun/command_result
```

An unknown joint must be rejected:

```bash
ros2 topic pub --once /seldun/command seldun_smartbot_bridge/msg/SeldunCommand \
  "{command_id: 'bad-1', command_type: 'joint_trajectory', joint_names: ['not_a_joint'], positions: [0.1], velocities: [], efforts: [], time_from_start_sec: 2.0, linear_x: 0.0, linear_y: 0.0, linear_z: 0.0, angular_x: 0.0, angular_y: 0.0, angular_z: 0.0}"
```

`SeldunCommand.msg` is the schema defined by this package. If the upstream Seldun protocol uses different fields, replace that message and keep the validator checks.

## Voice

`smartbot_voice_node` subscribes to `std_msgs/msg/String` on `/smartbot/speech_request`. The callback only queues the text. A background task calls `AsyncElevenLabs.text_to_speech.stream` with model `eleven_flash_v2_5` and `output_format="mp3_22050_32"`. ffmpeg decodes those MP3 chunks to 16-bit PCM as they arrive, and `sounddevice` (or `pyaudio`) plays that PCM. Playback starts before the sentence has finished generating. The speaker never receives raw MP3.

`eleven_flash_v2_5` is the current low-latency Flash v2.5 model id. `eleven_v4_turbo` is not an ElevenLabs model id. Set `model_id` or `ELEVENLABS_MODEL_ID` if the account is provisioned for a different low-latency model.

The API key and voice id are not in the parameter file. Copy `src/smartbot_ii_voice/config/voice.env.example` to a path outside the repo:

```bash
cp src/smartbot_ii_voice/config/voice.env.example "$HOME/smartbot-voice.env"
# edit ELEVENLABS_API_KEY and VOICE_ID
source /opt/ros/jazzy/setup.bash
source install/setup.bash
ros2 launch smartbot_ii_voice voice.launch.py env_file:="$HOME/smartbot-voice.env"
```

Publish one sentence:

```bash
ros2 topic pub --once /smartbot/speech_request std_msgs/msg/String \
  "{data: 'Battery is nominal.'}"
```

A network drop or a generation timeout is logged at WARN and the node keeps listening. That WARN line is the rclpy counterpart of `RCLCPP_WARN`. The node does not command joints, and it is not a hardware emergency stop. Without a key, a voice id, or a speaker, it logs a warning and drops the audio.

## Validation

These commands do not need a running robot. Run them from the workspace root.

```bash
source /opt/ros/jazzy/setup.bash
xacro src/smartbot_ii_description/urdf/smartbot_ii.urdf.xacro -o /tmp/smartbot_ii.urdf
check_urdf /tmp/smartbot_ii.urdf
python3 scripts/check_workspace.py
python3 -m unittest discover -s src/seldun_smartbot_bridge/test -v
```

`check_urdf` on the default file reports root link `pelvis_link`, 22 revolute joints, and 26 links. A Gazebo expansion with `fix_pelvis_to_world:=true` adds `fixed_base_link` as the root.

After `colcon build --symlink-install` and `source install/setup.bash`:

```bash
colcon test --packages-select seldun_smartbot_bridge
colcon test-result --verbose
```

While a display, control, or simulation launch is running, in another sourced terminal:

```bash
ros2 run tf2_tools view_frames
ros2 run tf2_ros tf2_echo pelvis_link head_link
ros2 run rqt_tf_tree rqt_tf_tree
ros2 topic list
ros2 topic echo /joint_states --once
ros2 topic echo /diagnostics
```

`view_frames` writes `frames.pdf` in the current directory. The TF tree is published by `robot_state_publisher` from the URDF and the current `/joint_states`.

While `control.launch.py` or `simulation.launch.py` is running:

```bash
ros2 control list_controllers
ros2 control list_hardware_interfaces
```

Expect `joint_state_broadcaster` and `smartbot_joint_trajectory_controller` to be active. The group controllers (`head_controller`, `left_arm_controller`, `right_arm_controller`, `left_leg_controller`, `right_leg_controller`) are defined in YAML and are not spawned. Do not activate a group controller while `smartbot_joint_trajectory_controller` is active. They command the same joints.

Joint-trajectory testing is the neck test in the section above.

Regenerate the parameter catalog after any numeric edit in the Xacro, then re-run the unit tests. The tests fail if the catalog drifts.

```bash
python3 scripts/render_simulated_catalog.py
```

## Meshes

Primitive boxes, cylinders, and spheres are the visuals and the collisions until you add meshes.

Visual meshes, one DAE per link, units in meters, scale `1 1 1`:

`src/smartbot_ii_description/meshes/visual/<link_name>.dae`

Collision meshes, one STL per link, same frame, coarse convex geometry:

`src/smartbot_ii_description/meshes/collision/<link_name>.stl`

Author each mesh in that link's coordinate frame. The origin is the proximal joint, not the center of mass and not the center of the current primitive. Axis directions are commented on each link in the Xacro. Arms and legs extend along -Z in the zero pose.

Then launch with:

```bash
ros2 launch smartbot_ii_description display.launch.py use_meshes:=true use_collision_meshes:=true
```

The link names are listed in `meshes/visual/README.md`. Both hip roll links are included (`left_hip_roll_link`, `right_hip_roll_link`). URDF cannot put three hip axes on one child, so the roll joint has its own intermediate body.

## MoveIt 2

MoveIt is not launched by this workspace. The description is ready for a later setup:

```bash
sudo apt install ros-jazzy-moveit
ros2 launch moveit_setup_assistant setup_assistant.launch.py
```

Load `urdf/smartbot_ii.urdf.xacro`, then `srdf/smartbot_ii.srdf`, then `config/moveit_controllers.yaml`.

The SRDF defines chains `head`, `left_arm`, `right_arm`, `left_leg`, `right_leg`, plus group-of-groups `both_arms`, `both_legs`, and `whole_body`. End effectors are `left_hand`, `right_hand`, `left_foot`, `right_foot`, and `head_ee`. The named state `zero_standing` sets every actuated joint to 0. Adjacent and overlapping collisions are disabled. There is no virtual planar joint.

`moveit_controllers.yaml` lists only `smartbot_joint_trajectory_controller` as an active FollowJointTrajectory controller. Planning against that configuration still does not authorize execution on hardware.

## Kinematic structure

Root body: `pelvis_link`.

| Chain | Links | Joints |
| --- | --- | --- |
| Trunk | `torso_link` | `torso_fixed_joint` (fixed) |
| Neck and head | `neck_link`, `head_link` | `neck_yaw_joint`, `neck_pitch_joint` |
| Each arm | shoulder, upper arm, forearm, wrist, hand | shoulder pitch, shoulder roll, elbow, wrist; hand is fixed |
| Each leg | hip, hip roll, thigh, lower leg, ankle, foot | hip yaw, hip roll, hip pitch, knee, ankle pitch, ankle roll |

Arms and legs are Xacro macros instantiated with `side` and a `reflect` sign of `1.0` (left) or `-1.0` (right).

Actuated joints, in the order used by the controller and the bridge:

`neck_yaw_joint`, `neck_pitch_joint`, `left_shoulder_pitch_joint`, `left_shoulder_roll_joint`, `left_elbow_joint`, `left_wrist_joint`, `right_shoulder_pitch_joint`, `right_shoulder_roll_joint`, `right_elbow_joint`, `right_wrist_joint`, `left_hip_yaw_joint`, `left_hip_roll_joint`, `left_hip_pitch_joint`, `left_knee_joint`, `left_ankle_pitch_joint`, `left_ankle_roll_joint`, `right_hip_yaw_joint`, `right_hip_roll_joint`, `right_hip_pitch_joint`, `right_knee_joint`, `right_ankle_pitch_joint`, `right_ankle_roll_joint`.

Each movable joint has a parent, a child, an origin, an axis, lower and upper position limits, a velocity limit, an effort limit, damping, and friction. Safety limits in `safety_limits.yaml` are inside the URDF limits (about 90 percent of each position span, with anatomical stops kept at 0, and about 80 percent of the velocity and effort caps). The bridge enforces the safety file. The URDF limits are what the joint tag and the position command interface advertise.

Axis convention used by the simulated model, all of which still need a hardware sign check:

- Pitch joints (`neck_pitch`, shoulder pitch, elbow, wrist, hip pitch, ankle pitch) use +Y. Positive pitch swings the limb forward. Positive elbow flexes the forearm forward. Elbow and knee lower limits are 0, so the model does not hyperextend.
- Roll joints (shoulder roll, hip roll, ankle roll) use +X. Positive roll moves the limb toward +Y. Right-side roll limits are mirrored.
- Yaw joints (`neck_yaw`, hip yaw) use +Z.
- The knee axis is `0 -1 0`, so a positive command flexes the shank backward.

Inertia macros use the uniform-primitive formulas: box `m/12`, sphere `2/5 m r^2`, and cylinders with the axial and transverse formulas for the axis they are drawn on. Those tensors are not measured.

Simulated mass of the free robot is 47.5 kg. `fixed_base_link`, when present, is a 0.001 kg parser stand-in and is not part of the robot mass.

## Physical measurements and hardware details you must supply

Do not enable physical mode, and do not command a real motor, until the items below exist and the model, controllers, limits, and a hardware emergency stop have been validated on the bench.

Replace every `replace_with_physical_measurement: true` entry in `config/simulated_parameters.yaml`. That file is the index. The same numbers live in the Xacro properties. After you edit a property, run `python3 scripts/render_simulated_catalog.py`.

Geometry and inertia, per link, in the link frame whose origin is the proximal joint:

- Size of every primitive (or the mesh that replaces it) and the joint origin that locates the child.
- Mass.
- Center of mass.
- Full inertia tensor. The current tensors assume a uniform box, sphere, or cylinder.

The current simulated masses, in kilograms, counting both sides where the link is mirrored: pelvis 5.5, torso 11.0, neck 0.6, head 3.2, shoulder 0.70, upper arm 1.6, forearm 1.2, wrist 0.25, hand 0.40, hip 0.80, hip roll 0.60, thigh 4.2, lower leg 2.8, ankle 0.35, foot 0.70.

Joints:

- Confirmation of each axis direction, especially the knee `-Y` axis and the mirrored shoulder-roll and hip-roll limits.
- Mechanical end stops, which replace the simulated lower and upper limits in `smartbot_ii.limits.xacro`, `joint_limits.yaml`, and `safety_limits.yaml`.
- Maximum velocity and continuous and peak effort from the actuator and gearbox datasheet.
- Viscous damping and Coulomb friction.
- Gearbox ratio. `mechanical_reduction` is 1.0, which means joint angle equals motor angle.
- Encoder counts, zero offset, and sign, so position 0 is the straight standing pose.
- Acceleration limits. `joint_limits.yaml` has simulated accelerations for MoveIt. URDF itself has no acceleration field.

Hardware:

- The real `ros2_control` hardware plugin and the bus (EtherCAT, CAN, or another). None is shipped.
- A hardware emergency-stop circuit that removes motor power. The bridge latch does not do that.
- Battery and current limits.
- Foot sole size and a measured friction coefficient. `foot_mu` is 1.0. `foot_kp` and `foot_kd` are untuned contact guesses (`replace_with_physical_measurement: false`) and still must not be copied onto hardware.
- IMU or other sensors, if you add them. None are modeled.
- Whether the torso should have a waist joint. It is fixed today.
- Whether the hands should have finger joints. They are fixed today.
- Whether the real Seldun protocol matches `SeldunCommand.msg`.

Derived values to recompute after the lengths change, not independent measurements:

- `pelvis_height_above_ground` = abs(`hip_z_offset`) + `hip_length` + `hip_roll_drop` + `thigh_length` + `shank_length` + `ankle_length` + `foot_z` + `ground_clearance`. It is 0.92 m with the current numbers.
- `FREE_STANDING_SPAWN_Z` in `simulation.launch.py`, which must stay equal to that height.
- `position_proportional_gain` (0.1) and the 250 Hz controller `update_rate`, after the simulator or the drive is identified. Keep the gain at or below 1 until then. `GazeboSimSystem` integrates position error as `joint_velocity = gain * error * update_rate`.

## Editor setup

`.vscode/extensions.json` recommends `ms-iot.vscode-ros` and `ms-python.python`.

`.vscode/settings.json` adds `/opt/ros/jazzy/lib/python3.12/site-packages` and `src/seldun_smartbot_bridge` to the Python analysis path, and associates Xacro, URDF, SDF, and SRDF with XML.

## Directory tree

```text
.
├── LICENSE
├── README.md
├── .gitignore
├── .vscode/
│   ├── extensions.json
│   └── settings.json
├── scripts/
│   ├── check_workspace.py
│   └── render_simulated_catalog.py
├── firmware/
│   └── smartbot_ii_joint_node/
│       ├── CMakeLists.txt
│       ├── README.md
│       ├── include/smartbot_joint/
│       │   ├── as5600.hpp
│       │   ├── can_protocol.hpp
│       │   ├── hbridge.hpp
│       │   ├── joint_node.hpp
│       │   └── pid.hpp
│       ├── platform/
│       │   ├── board_pins.hpp
│       │   ├── esp32/esp32_port.cpp
│       │   └── stm32/stm32_port.cpp
│       ├── src/joint_node.cpp
│       └── test/test_joint_node.cpp
└── src/
    ├── seldun_smartbot_bridge/
    │   ├── CMakeLists.txt
    │   ├── package.xml
    │   ├── config/bridge_params.yaml
    │   ├── launch/seldun_bridge.launch.py
    │   ├── msg/SeldunCommand.msg
    │   ├── msg/SeldunCommandResult.msg
    │   ├── scripts/seldun_bridge
    │   ├── seldun_smartbot_bridge/
    │   │   ├── __init__.py
    │   │   ├── bridge_node.py
    │   │   ├── bus_telemetry.py
    │   │   ├── codec.py
    │   │   └── validator.py
    │   └── test/
    │       ├── test_bus_telemetry.py
    │       ├── test_codec.py
    │       ├── test_limits_consistency.py
    │       └── test_validator.py
    ├── smartbot_ii_control/
    │   ├── CMakeLists.txt
    │   ├── package.xml
    │   ├── smartbot_ii_hardware_plugin.xml
    │   ├── config/ros2_controllers.yaml
    │   ├── include/smartbot_ii_control/
    │   │   ├── joint_target_codec.hpp
    │   │   ├── rt_logging.hpp
    │   │   └── smartbot_ii_hardware.hpp
    │   ├── launch/
    │   │   ├── control.launch.py
    │   │   └── hardware_interface.launch.py
    │   ├── scripts/send_safe_neck_trajectory.py
    │   ├── src/smartbot_ii_hardware.cpp
    │   └── test/test_joint_target_codec.cpp
    ├── smartbot_ii_description/
    │   ├── CMakeLists.txt
    │   ├── package.xml
    │   ├── config/
    │   │   ├── joint_limits.yaml
    │   │   ├── moveit_controllers.yaml
    │   │   ├── safety_limits.yaml
    │   │   └── simulated_parameters.yaml
    │   ├── launch/display.launch.py
    │   ├── meshes/
    │   │   ├── collision/README.md
    │   │   └── visual/README.md
    │   ├── rviz/smartbot_ii.rviz
    │   ├── srdf/smartbot_ii.srdf
    │   └── urdf/
    │       ├── smartbot_ii.constants.xacro
    │       ├── smartbot_ii.gazebo.xacro
    │       ├── smartbot_ii.limits.xacro
    │       ├── smartbot_ii.macros.xacro
    │       ├── smartbot_ii.materials.xacro
    │       ├── smartbot_ii.ros2_control.xacro
    │       ├── smartbot_ii.transmissions.xacro
    │       └── smartbot_ii.urdf.xacro
    ├── smartbot_ii_gazebo/
    │   ├── CMakeLists.txt
    │   ├── package.xml
    │   ├── launch/simulation.launch.py
    │   └── worlds/smartbot_ii_test.sdf
    └── smartbot_ii_voice/
        ├── CMakeLists.txt
        ├── package.xml
        ├── requirements.txt
        ├── config/
        │   ├── voice.env.example
        │   └── voice_params.yaml
        ├── launch/voice.launch.py
        ├── scripts/smartbot_voice_node
        ├── smartbot_ii_voice/
        │   ├── __init__.py
        │   ├── speech.py
        │   └── voice_node.py
        └── test/test_speech.py
```

`build/`, `install/`, and `log/` appear after `colcon build` and are gitignored.

## Every file

### Workspace root

- `README.md` — this file.
- `LICENSE` — Apache-2.0.
- `.gitignore` — ignores colcon output, Python caches, and editor swap files.
- `.vscode/extensions.json` — recommended ROS and Python extensions.
- `.vscode/settings.json` — Python paths for the Jazzy site-packages and the bridge package, plus XML associations for robot formats.
- `scripts/render_simulated_catalog.py` — rewrites `simulated_parameters.yaml` from the Xacro properties.
- `scripts/check_workspace.py` — parses XML and YAML, compiles Python, rejects unfinished-work markers, compiles the frame codec and the joint-node host test, and runs the bridge unit tests. It does not need ROS.
- `firmware/smartbot_ii_joint_node/` — CAN, AS5600, PID, and DRV bridge core for one joint node, plus STM32 and ESP32 ports. The firmware README lists each file.

### `smartbot_ii_description`

- `package.xml` — package manifest, version 0.1.0, Apache-2.0. Execution dependencies are the publisher, the joint-state GUIs, RViz2, URDF, and xacro.
- `CMakeLists.txt` — installs `config`, `launch`, `meshes`, `rviz`, `srdf`, and `urdf`.
- `urdf/smartbot_ii.urdf.xacro` — robot root. Arguments select ros2_control, Gazebo, the hardware plugin, the pelvis weld, and meshes. Includes the other Xacro files and builds pelvis, torso, neck, head, both arms, and both legs.
- `urdf/smartbot_ii.materials.xacro` — colors: navy, pelvis, steel, dark, bone, visor, rubber, accent.
- `urdf/smartbot_ii.constants.xacro` — simulated sizes and masses. The standing-height comment shows why the pelvis is 0.92 m above the ground.
- `urdf/smartbot_ii.limits.xacro` — position, velocity, effort, damping, and friction for all 22 actuated joints.
- `urdf/smartbot_ii.macros.xacro` — inertia, visual, and collision macros; revolute and fixed joint macros; ros2_control joint and transmission macros; arm and leg macros. Mesh paths point at `package://smartbot_ii_description/meshes/visual/<link>.dae` and `meshes/collision/<link>.stl` when the mesh arguments are true.
- `urdf/smartbot_ii.transmissions.xacro` — one `SimpleTransmission` per actuated joint, included only when `use_ros2_control` is true.
- `urdf/smartbot_ii.ros2_control.xacro` — `SmartBotIISystem` hardware block. Position command plus position and velocity state are always present. The effort state is present unless `export_effort_state` is false, which is required by `SmartBotIIHardware`. `GenericSystem` is given `calculate_dynamics` false. The SmartBot plugin receives the bus parameters.
- `urdf/smartbot_ii.gazebo.xacro` — Gazebo friction on the feet, `position_proportional_gain` 0.1, `hold_joints` true, and the `gz_ros2_control` plugin pointed at the controllers YAML.
- `config/joint_limits.yaml` — MoveIt-style position, velocity, acceleration, and effort limits matching the Xacro. Accelerations are simulated and are not in the URDF.
- `config/safety_limits.yaml` — tighter limits and `cmd_vel` caps enforced by the bridge, plus the physical-mode acknowledgement token.
- `config/simulated_parameters.yaml` — generated catalog of every Xacro numeric property and whether it must be replaced by a measurement.
- `config/moveit_controllers.yaml` — FollowJointTrajectory controller name for a later MoveIt config. Group controllers are documented there and are not active together with the whole-body controller.
- `srdf/smartbot_ii.srdf` — planning groups, end effectors, the zero state, and disabled adjacent collisions. No virtual joint.
- `launch/display.launch.py` — `robot_state_publisher`, joint-state publisher or GUI, and RViz2. Logs that the session is a kinematic preview.
- `rviz/smartbot_ii.rviz` — fixed frame `pelvis_link`, grid, robot model on `/robot_description` with Transient Local durability, TF names on.
- `meshes/visual/README.md` — where each visual DAE goes, and the link-frame rules.
- `meshes/collision/README.md` — where each collision STL goes.

### `smartbot_ii_control`

- `package.xml` — manifest. Depends on the description package, `hardware_interface`, the trajectory controller, and RViz2.
- `CMakeLists.txt` — builds `libsmartbot_ii_hardware.so`, installs headers, `config`, `launch`, and `scripts/send_safe_neck_trajectory.py`.
- `smartbot_ii_hardware_plugin.xml` — pluginlib description for `smartbot_ii_control/SmartBotIIHardware`.
- `include/smartbot_ii_control/joint_target_codec.hpp` — the 22 joint names, the packed `joint_id` / `target_rad` record, and the fixed bus frame. No ROS types.
- `include/smartbot_ii_control/rt_logging.hpp` — `SMARTBOT_II_LOG_INFO` and `SMARTBOT_II_LOG_ERROR` macros, plus the 1 ms budget constant. The 250 Hz loop does not call them unless a fault is latched or `rt_trace` is on.
- `include/smartbot_ii_control/smartbot_ii_hardware.hpp` — `SystemInterface` declaration.
- `src/smartbot_ii_hardware.cpp` — lifecycle hooks, interface export, mock state integration, and the optional UART/SPI writer thread.
- `config/ros2_controllers.yaml` — controller manager at 250 Hz, joint state broadcaster, whole-body trajectory controller, and the five group controllers. Command interface is position. State interfaces are position and velocity. `open_loop_control` is false. Partial joint goals are rejected.
- `launch/control.launch.py` — `mock_components/GenericSystem`, `robot_state_publisher`, `ros2_control_node`, the two spawners, and optional RViz. The plugin name is hardcoded.
- `launch/hardware_interface.launch.py` — the SmartBot II system interface. `bus_transport` defaults to mock.
- `scripts/send_safe_neck_trajectory.py` — simulation-only neck yaw out and back through FollowJointTrajectory.
- `test/test_joint_target_codec.cpp` — frame layout, checksum, NaN rejection, and a pack-loop timing check. It compiles without ROS.

### `smartbot_ii_gazebo`

- `package.xml` — manifest. Depends on description, control, the Seldun bridge, `ros_gz_sim`, `ros_gz_bridge`, and `gz_ros2_control`.
- `CMakeLists.txt` — installs `launch` and `worlds`.
- `launch/simulation.launch.py` — starts Gazebo, the clock bridge, `robot_state_publisher`, optional RViz, the spawn, the two controllers, and the optional Seldun bridge.
- `worlds/smartbot_ii_test.sdf` — SDF 1.8 world, gravity `-9.8` m/s², 1 ms max step, physics, scene, and contact plugins, a 40 m ground plane, and a static orange post at `x=1.4` so the scene has a scale reference. The post is not part of the robot.

### `seldun_smartbot_bridge`

- `package.xml` — ament CMake and Python, message generation, and pytest.
- `CMakeLists.txt` — generates both messages, installs the Python package, the `seldun_bridge` executable, `config`, and `launch`, and registers the pytest files.
- `msg/SeldunCommand.msg` — command id, type, joint arrays, time, and twist fields.
- `msg/SeldunCommandResult.msg` — accept flag, error code, message, hardware mode, software-stop latch, and which ROS interfaces were published.
- `config/bridge_params.yaml` — simulation defaults. Limb-bus telemetry is `off`. The physical keys are comments and are not set.
- `launch/seldun_bridge.launch.py` — starts the node with the parameter file and the installed safety-limits path.
- `scripts/seldun_bridge` — executable entry point.
- `seldun_smartbot_bridge/__init__.py` — exports the validator API.
- `seldun_smartbot_bridge/validator.py` — joint list, limit checks, hardware-mode gate, and transport selection. No ROS imports, so the unit tests run without a ROS install.
- `seldun_smartbot_bridge/codec.py` — builds `JointTrajectory`, `FollowJointTrajectory` goals, and `Twist` messages as plain Python structures. No ROS imports.
- `seldun_smartbot_bridge/bus_telemetry.py` — limb-bus receiver. Parses status frames into position, velocity, and temperature, and has no ROS import.
- `seldun_smartbot_bridge/bridge_node.py` — rclpy node. Subscribes to commands and joint states, publishes the result, twist, trajectory, and diagnostics, and sends the action when that transport is selected. `apply_measured_positions` stores the 22-joint dictionary. `latch_hardware_alert` latches the software stop and publishes `smartbot/system_alert`.
- `test/test_bus_telemetry.py` — status-frame layout, the 22-joint dictionary, serial records, and one-shot fault alerts. No socket is opened.
- `test/test_validator.py` — unknown joints, malformed commands, limit violations, the software stop, and the physical-mode gate.
- `test/test_codec.py` — trajectory and twist encoding.
- `test/test_limits_consistency.py` — URDF, Xacro, safety YAML, catalog flags, pelvis height, mass sum, controller partition, and SRDF names stay in agreement.

### `smartbot_ii_voice`

- `package.xml` — manifest. Depends on `rclpy` and `std_msgs`. Python packages from `requirements.txt` are installed with pip.
- `CMakeLists.txt` — installs the Python package, the `smartbot_voice_node` executable, `config`, and `launch`.
- `requirements.txt` — `elevenlabs`, `python-dotenv`, `miniaudio`, and `sounddevice`.
- `config/voice.env.example` — template for `ELEVENLABS_API_KEY` and `VOICE_ID`. The filled-in file stays outside git.
- `config/voice_params.yaml` — topic, timeout, and the Flash v2.5 model id. No API key.
- `launch/voice.launch.py` — starts `smartbot_voice_node` and takes an `env_file` argument.
- `scripts/smartbot_voice_node` — executable entry point.
- `smartbot_ii_voice/speech.py` — ElevenLabs stream client, ffmpeg MP3-to-PCM decoder, and sounddevice playback. No ROS import.
- `smartbot_ii_voice/voice_node.py` — subscription on `/smartbot/speech_request`. Warnings go through the node logger.
- `test/test_speech.py` — credential loading, chunk playback order, timeout and network warnings, and a local MP3 decode. No network call.

## Verification performed in this repository

`python3 scripts/check_workspace.py` parses the XML and YAML, compiles the Python, compiles and runs the joint-frame codec test and the joint-node host test, and runs the bridge and voice unit tests. The voice tests do not call ElevenLabs. `xacro` plus `check_urdf` were run on the default model, the mock-hardware expansion, and the Gazebo expansion with the pelvis weld.

`colcon build`, Gazebo, and RViz were not executed in the environment that generated these files, because ROS 2 Jazzy is not installed there. The hardware plugin source is written for the Jazzy `SystemInterface`, and it still has to be built with `colcon` on Ubuntu 24.04 before it can be loaded.
